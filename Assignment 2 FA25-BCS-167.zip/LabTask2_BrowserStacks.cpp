#include <iostream>
#include <string>
using namespace std;

const int MAX = 100;

class Stack {
private:
    string arr[MAX];
    int top;

public:
    Stack() {
        top = -1;
    }

    bool isEmpty() {
        return top == -1;
    }

    bool isFull() {
        return top == MAX - 1;
    }

    void push(string page) {
        if (isFull()) {
            cout << "Stack Overflow!\n";
            return;
        }
        arr[++top] = page;
    }

    string pop() {
        if (isEmpty()) {
            return "";
        }
        return arr[top--];
    }

    string peek() {
        if (isEmpty()) return "";
        return arr[top];
    }

    void clear() {
        top = -1;
    }
};

class Browser {
private:
    Stack backStack;
    Stack forwardStack;
    string currentPage;

public:
    Browser() {
        currentPage = "Home";
    }

    void visit(string newPage) {
        if (currentPage != "") {
            backStack.push(currentPage);
        }
        forwardStack.clear();
        currentPage = newPage;
        cout << "Visited: " << currentPage << endl;
    }

    void goBack() {
        if (backStack.isEmpty()) {
            cout << "No previous page!\n";
            return;
        }
        forwardStack.push(currentPage);
        currentPage = backStack.pop();
        cout << "Went Back to: " << currentPage << endl;
    }

    void goForward() {
        if (forwardStack.isEmpty()) {
            cout << "No forward page!\n";
            return;
        }
        backStack.push(currentPage);
        currentPage = forwardStack.pop();
        cout << "Went Forward to: " << currentPage << endl;
    }

    void displayCurrent() {
        cout << "Current Page: " << currentPage << endl;
    }
};

int main() {
    Browser browser;
    int choice;
    string url;

    cout << "=== Browser History Simulator (Two Stacks) ===\n";

    while (true) {
        cout << "\n1. Visit New Page\n";
        cout << "2. Go Back\n";
        cout << "3. Go Forward\n";
        cout << "4. Display Current Page\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            cout << "Enter URL: ";
            getline(cin, url);
            browser.visit(url);
        }
        else if (choice == 2) {
            browser.goBack();
        }
        else if (choice == 3) {
            browser.goForward();
        }
        else if (choice == 4) {
            browser.displayCurrent();
        }
        else if (choice == 5) {
            break;
        }
        else {
            cout << "Invalid choice!\n";
        }
    }

    return 0;
}
