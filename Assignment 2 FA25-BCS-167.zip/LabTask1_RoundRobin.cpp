#include <iostream>
using namespace std;

const int MAX = 100;

struct Process {
    int pid;
    int burst;
    int remaining;
    int completion;
    int waiting;
    int turnaround;
};

class CircularQueue {
private:
    Process arr[MAX];
    int front, rear, size;

public:
    CircularQueue() {
        front = -1;
        rear = -1;
        size = 0;
    }

    bool isEmpty() {
        return size == 0;
    }

    bool isFull() {
        return size == MAX;
    }

    void enqueue(Process p) {
        if (isFull()) {
            cout << "Queue is Full!\n";
            return;
        }
        if (isEmpty()) {
            front = 0;
            rear = 0;
        } else {
            rear = (rear + 1) % MAX;
        }
        arr[rear] = p;
        size++;
    }

    Process dequeue() {
        if (isEmpty()) {
            Process dummy = {-1, 0, 0, 0, 0, 0};
            return dummy;
        }
        Process p = arr[front];
        if (front == rear) {
            front = -1;
            rear = -1;
        } else {
            front = (front + 1) % MAX;
        }
        size--;
        return p;
    }

    Process peek() {
        if (isEmpty()) {
            Process dummy = {-1, 0, 0, 0, 0, 0};
            return dummy;
        }
        return arr[front];
    }
};

int main() {
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    Process processes[MAX];
    CircularQueue cq;

    cout << "Enter Process ID and Burst Time for each process:\n";
    for (int i = 0; i < n; i++) {
        cout << "Process " << i + 1 << " - PID: ";
        cin >> processes[i].pid;
        cout << "Burst Time: ";
        cin >> processes[i].burst;
        processes[i].remaining = processes[i].burst;
        processes[i].completion = 0;
        cq.enqueue(processes[i]);
    }

    int time = 0;
    int quantum = 3;
    cout << "\n=== Execution Order ===\n";

    while (!cq.isEmpty()) {
        Process p = cq.dequeue();

        int execTime = (p.remaining < quantum) ? p.remaining : quantum;
        time += execTime;
        p.remaining -= execTime;

        cout << "P" << p.pid << " executed for " << execTime 
             << " units (Time: " << time << ")\n";

        if (p.remaining > 0) {
            cq.enqueue(p);
        } else {
            // Find original process and update completion
            for (int i = 0; i < n; i++) {
                if (processes[i].pid == p.pid) {
                    processes[i].completion = time;
                    break;
                }
            }
        }
    }

    cout << "\n=== Process Table ===\n";
    cout << "PID\tBurst\tCompletion\tTurnaround\tWaiting\n";
    cout << "------------------------------------------------\n";

    for (int i = 0; i < n; i++) {
        processes[i].turnaround = processes[i].completion; // arrival = 0
        processes[i].waiting = processes[i].turnaround - processes[i].burst;

        cout << processes[i].pid << "\t"
             << processes[i].burst << "\t"
             << processes[i].completion << "\t\t"
             << processes[i].turnaround << "\t\t"
             << processes[i].waiting << endl;
    }

    return 0;
}
