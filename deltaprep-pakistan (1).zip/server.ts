import express, { Request, Response } from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import apiRouter from './server/api';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));

// Mount Records, Questions, Subjects, and Mastery APIs
app.use('/api', apiRouter);

// Lazy AI Client initializer with required headers
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// 1. Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: !!process.env.GEMINI_API_KEY,
    timestamp: new Date().toISOString(),
  });
});

// 2. Study Buddy Chat Endpoint
app.post('/api/study-buddy/chat', async (req: Request, res: Response) => {
  try {
    const { message, history, context } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message is required' });
      return;
    }

    const ai = getGeminiClient();

    const homeBoard = context?.homeBoard || 'Punjab Board';
    const targetExam = context?.targetExam || 'NUST NET';
    const activeSubject = context?.subject || 'All Subjects';

    const systemInstruction = `You are the DeltaPrep AI Study Buddy, Pakistan's premier university entry test (NUST NET, FAST NU-Test, MDCAT PMDC, COMSATS NTS-NAT) and board syllabus gap mentor.
Student's Home Board: ${homeBoard}
Student's Target Exam: ${targetExam}
Active Subject Context: ${activeSubject}

Specialized capabilities and guidelines:
1. Syllabus Divergence (The Delta Engine): You know exact differences between Federal Board (FBISE / National Book Foundation) vs Punjab (PCTB), Sindh (STBB), and KPK boards. Federal is the primary basis for NUST NET and national MDCAT.
2. Speed Tactics: Teach time-saving tricks (Maclaurin series vs L'Hopital, dimensional elimination, Torricelli shortcut, tabular integration, ratio methods) because calculator is banned in NET, FAST, and MDCAT.
3. Negative Marking: For FAST (-0.25 penalty), explain domain restrictions and when to skip traps.
4. Format:
- Use clean Markdown with clear headings and bold highlights.
- Whenever writing mathematical formulas, derivatives, or numerical expressions, use standard KaTeX/LaTeX syntax wrapped in single dollar signs $...$ for inline or double dollar signs $$...$$ for display math (e.g., $$\\lim_{x \\to 0} \\frac{\\sin(5x)-5x}{x^3} = -\\frac{125}{6}$$).
- Provide step-by-step breakdown.
- Always include a "Pro-Exam Speed Tip" or "Board Trap Alert".
Be encouraging, intellectually rigorous, and concise.`;

    // If Gemini client is available, call gemini-3.8-flash
    if (ai) {
      // Build conversation contents
      const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

      if (Array.isArray(history)) {
        for (const msg of history.slice(-8)) {
          if (msg.sender === 'user') {
            contents.push({ role: 'user', parts: [{ text: msg.text }] });
          } else if (msg.sender === 'assistant') {
            contents.push({ role: 'model', parts: [{ text: msg.text }] });
          }
        }
      }

      contents.push({ role: 'user', parts: [{ text: message }] });

      const result = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const replyText = result.text || 'I analyzed your query, but could not produce a response.';

      // Extract LaTeX snippet if display math is present
      const latexMatch = replyText.match(/\$\$([\s\S]+?)\$\$/);
      const latexSnippet = latexMatch ? latexMatch[1].trim() : undefined;

      res.json({
        reply: replyText,
        latexSnippet,
        source: 'gemini',
      });
      return;
    }

    // High quality offline fallback when API key is not configured
    const lower = message.toLowerCase();
    let fallbackText = '';
    let fallbackLatex = '';

    if (lower.includes('bernoulli')) {
      fallbackText = `**Bernoulli's Principle for ${targetExam}:**
Bernoulli's equation represents the conservation of mechanical energy per unit volume for an ideal, incompressible, non-viscous fluid in steady streamline flow:

$$P + \\frac{1}{2}\\rho v^2 + \\rho g h = \\text{Constant}$$

**Key Exam Insights:**
- In horizontal flow ($h_1 = h_2$), where fluid speed $v$ is high, static pressure $P$ must drop.
- **Federal vs Provincial Trap:** Torricelli's theorem efflux speed is $v = \\sqrt{2gh}$, which is strictly **independent** of liquid density $\\rho$. Questions frequently try to trick students by asking if mercury or water drains faster from a pinhole!`;
      fallbackLatex = 'P_1 + \\frac{1}{2}\\rho v_1^2 = P_2 + \\frac{1}{2}\\rho v_2^2';
    } else if (lower.includes('limit') || lower.includes('maclaurin') || lower.includes('calculus')) {
      fallbackText = `**FAST NU & NET Calculus Shortcut:**
Evaluating $\\lim_{x \\to 0} \\frac{\\sin(ax) - ax}{x^3}$:
Instead of applying L'Hôpital's rule 3 times (takes 60-80 seconds in FAST's 45s/question pace), use the **Maclaurin series expansion**:

$$\\sin(ax) = ax - \\frac{(ax)^3}{3!} + \\frac{(ax)^5}{5!} - \\dots$$

Thus:
$$\\frac{(ax - \\frac{a^3 x^3}{6}) - ax}{x^3} = -\\frac{a^3}{6}$$

For $a = 5$, the answer is immediately $-\\frac{125}{6}$. Speed achieved: 12 seconds.`;
      fallbackLatex = '\\lim_{x \\to 0} \\frac{\\sin(ax) - ax}{x^3} = -\\frac{a^3}{6}';
    } else {
      fallbackText = `**DeltaPrep Guidance for ${targetExam}:**
Regarding your query about "${message}":
1. **Core Concept:** Master the underlying definition and formula in the Federal (FBISE) syllabus, as ${targetExam} tests conceptual applications rather than rote textbook derivations.
2. **Elimination Tactic:** Check units and dimensions first. In 30% of engineering numericals, 2 out of 4 options have incorrect dimensional powers.
3. **Pacing:** Allocate no more than 50 seconds to this problem type. If multi-variable integration is required without obvious symmetry, mark and skip to avoid the negative marking trap.`;
    }

    res.json({
      reply: fallbackText,
      latexSnippet: fallbackLatex || undefined,
      source: 'fallback',
    });
  } catch (error: any) {
    console.error('Error in study-buddy chat:', error);
    res.status(500).json({
      error: 'Failed to process chat response',
      details: error.message,
    });
  }
});

// 3. AI Vision / OCR Problem Solver
app.post('/api/study-buddy/vision', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', prompt, homeBoard, targetExam } = req.body;

    if (!imageBase64) {
      res.status(400).json({ error: 'Image base64 data is required' });
      return;
    }

    const ai = getGeminiClient();

    if (ai) {
      // Strip base64 header if included
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');

      const userInstruction = prompt || 'Read this textbook / exam problem image, transcribe the text and math, identify the subject and topic, and provide the complete step-by-step solution with KaTeX math and any syllabus trap.';

      const result = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  data: cleanBase64,
                  mimeType,
                },
              },
              {
                text: `${userInstruction}\nTarget Exam: ${targetExam || 'NUST NET / MDCAT'}\nHome Board: ${homeBoard || 'Punjab Board'}\n\nFormat your response clearly with sections:\n### Transcribed Question\n### Topic & Board Classification\n### Step-by-Step Solution (use $...$ and $$...$$ for math)\n### Exam Speed Tip & Traps`,
              },
            ],
          },
        ],
      });

      const text = result.text || 'Unable to parse image.';
      const latexMatch = text.match(/\$\$([\s\S]+?)\$\$/);

      res.json({
        analysis: text,
        latexSnippet: latexMatch ? latexMatch[1].trim() : undefined,
        source: 'gemini',
      });
      return;
    }

    // Fallback OCR solver when API key is missing
    res.json({
      analysis: `### Transcribed Question
**Physics / Mechanics Problem:**
A particle moves in the xy-plane with parametric equations $x(t) = 3t$ and $y(t) = 4t^2$. Find the radius of curvature $R$ of its trajectory at $t = 0$.

### Topic & Board Classification
- **Subject:** Physics (Kinematics & Curvature)
- **Classification:** Federal FBISE Physics & NUST NET Advanced Numerical Trap

### Step-by-Step Solution
1. **Velocity Vector:**
   $$\\vec{v}(t) = \\frac{d\\vec{r}}{dt} = 3\\hat{i} + 8t\\hat{j} \\implies \\vec{v}(0) = 3\\hat{i}, \\quad |v| = 3\\text{ m/s}$$
2. **Acceleration Vector:**
   $$\\vec{a}(t) = \\frac{d\\vec{v}}{dt} = 8\\hat{j} \\implies \\vec{a}(0) = 8\\hat{j}\\text{ m/s}^2$$
3. **Normal Acceleration & Radius of Curvature:**
   Since velocity is purely along $\\hat{i}$ and acceleration is purely along $\\hat{j}$, they are orthogonal ($v \\perp a$). Therefore, the entire acceleration is normal acceleration $a_n = 8\\text{ m/s}^2$.
   $$R = \\frac{v^2}{a_n} = \\frac{3^2}{8} = \\frac{9}{8} = 1.125\\text{ units}$$

### Exam Speed Tip & Traps
In provincial textbooks (Punjab/Sindh), curvature formulas are rarely derived in FSc Physics. In NUST NET, remember that whenever velocity and acceleration are perpendicular, $R = \\frac{v^2}{a}$ immediately!`,
      latexSnippet: 'R = \\frac{v^2}{a_n} = \\frac{9}{8}',
      source: 'fallback',
    });
  } catch (error: any) {
    console.error('Error in vision solver:', error);
    res.status(500).json({
      error: 'Vision problem solving failed',
      details: error.message,
    });
  }
});

// 4. AI Question Generator Endpoint
app.post('/api/ai/generate-questions', async (req: Request, res: Response) => {
  try {
    const {
      subject = 'Physics',
      chapter = 'General',
      topic = 'Core Concepts',
      board = 'Punjab',
      exam = 'NUST NET',
      difficulty = 'Medium',
      count = 3,
    } = req.body;

    const ai = getGeminiClient();

    if (ai) {
      const prompt = `Generate exactly ${count} multiple choice questions (MCQs) for Pakistani university entry test preparation.
Subject: ${subject}
Chapter: ${chapter}
Topic: ${topic}
Student Board: ${board}
Target Exam: ${exam}
Difficulty: ${difficulty}

Rules:
1. Must have exactly 4 options.
2. Provide a 0-indexed integer for correctAnswer (0 for first option, 1 for second, 2 for third, 3 for fourth).
3. Explanation must be educational, revealing the speed trick or board divergence.
4. Indicate if it is a delta-topic (concept present in Federal/NET but often missed in provincial boards).
5. Output ONLY valid JSON matching this schema:
[
  {
    "id": "gen-1",
    "question": "Question text...",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctAnswer": 0,
    "boardOrigin": "Board or Exam context",
    "explanation": "Detailed explanation with formula...",
    "timeTargetSeconds": 45,
    "subject": "${subject}",
    "topicName": "${topic}",
    "deltaTagged": true,
    "difficulty": "${difficulty}"
  }
]`;

      const result = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.4,
        },
      });

      const responseText = result.text || '[]';
      const parsed = JSON.parse(responseText);

      // Validate question structure
      if (Array.isArray(parsed) && parsed.length > 0) {
        const validated = parsed.map((q, idx) => ({
          id: `ai-gen-${Date.now()}-${idx}`,
          question: q.question || 'Generated MCQ Question',
          options: Array.isArray(q.options) && q.options.length === 4 ? q.options : ['A', 'B', 'C', 'D'],
          correctAnswer: typeof q.correctAnswer === 'number' && q.correctAnswer >= 0 && q.correctAnswer <= 3 ? q.correctAnswer : 0,
          boardOrigin: q.boardOrigin || `${board} / ${exam}`,
          explanation: q.explanation || 'Refer to the standard syllabus derivation.',
          timeTargetSeconds: q.timeTargetSeconds || 45,
          subject: q.subject || subject,
          topicName: q.topicName || topic,
          deltaTagged: !!q.deltaTagged,
          difficulty: q.difficulty || difficulty,
        }));

        res.json({ questions: validated, source: 'gemini' });
        return;
      }
    }

    // Dynamic offline fallback generator
    const fallbackQuestions = [
      {
        id: `ai-gen-${Date.now()}-1`,
        question: `[${topic}] In ${exam} ${subject}, which of the following expressions correctly models the variation under standard conditions?`,
        options: [
          'Directly proportional to the square of the parameter',
          'Inversely proportional to square root of the parameter',
          'Independent of the medium constant',
          'Linearly dependent with zero y-intercept',
        ],
        correctAnswer: 0,
        boardOrigin: `${board} vs ${exam} Delta`,
        explanation: `In the standard Federal FBISE formulation for ${topic}, quadratic scaling applies directly. Notice how options B and C represent common provincial misinterpretations.`,
        timeTargetSeconds: 40,
        subject,
        topicName: topic,
        deltaTagged: true,
        difficulty,
      },
      {
        id: `ai-gen-${Date.now()}-2`,
        question: `For a typical system governed by ${topic} in ${subject}, what is the maximum efficiency or peak value attainable without external work?`,
        options: [
          '1 - (T_c / T_h)',
          '1 + (T_c / T_h)',
          '(T_h - T_c) / T_c',
          'Zero',
        ],
        correctAnswer: 0,
        boardOrigin: `National Curriculum (${exam})`,
        explanation: `By thermodynamic and conservation principles in ${topic}, Carnot boundary limits maximum ratio to 1 - T_c/T_h.`,
        timeTargetSeconds: 35,
        subject,
        topicName: topic,
        deltaTagged: false,
        difficulty,
      },
    ];

    res.json({ questions: fallbackQuestions, source: 'fallback' });
  } catch (error: any) {
    console.error('Error generating questions:', error);
    res.status(500).json({
      error: 'Failed to generate questions',
      details: error.message,
    });
  }
});

// 5. Adaptive AI Study Planner Endpoint
app.post('/api/ai/study-planner', async (req: Request, res: Response) => {
  try {
    const { targetExam = 'NUST NET', homeBoard = 'Punjab', weakTopics = [], dailyHours = 4 } = req.body;
    const ai = getGeminiClient();

    if (ai) {
      const prompt = `Create a high-impact, personalized 7-day revision schedule for a student preparing for ${targetExam} from ${homeBoard} Board.
Weak topics to remediate: ${weakTopics.join(', ') || 'Calculus, Electromagnetism, Organic Reaction Mechanisms'}
Available study time: ${dailyHours} hours/day.

Return ONLY a JSON array of 7 day schedule objects with structure:
[
  {
    "day": "Day 1 (Monday)",
    "focusSubject": "Mathematics",
    "theme": "Definite Integration & Speed Limits",
    "timeSlots": [
      { "time": "09:00 - 10:30", "activity": "Theory Gap Fill: Maclaurin & Walli Formula", "type": "Delta Lesson" },
      { "time": "11:00 - 12:30", "activity": "Timed MCQ Drill (40 questions in 35 mins)", "type": "Speed Practice" },
      { "time": "17:00 - 18:00", "activity": "Spaced Repetition Review & Error Log", "type": "Review" }
    ],
    "highYieldDeltaTip": "Focus on tabular D-I integration to save 45 seconds per question in FAST."
  }
]`;

      const result = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.5,
        },
      });

      const parsed = JSON.parse(result.text || '[]');
      if (Array.isArray(parsed) && parsed.length > 0) {
        res.json({ plan: parsed, source: 'gemini' });
        return;
      }
    }

    // Default 7-day adaptive plan fallback
    res.json({
      plan: [
        {
          day: 'Day 1 (Monday)',
          focusSubject: 'Mathematics',
          theme: 'Calculus Traps & Maclaurin Shortcuts',
          timeSlots: [
            { time: '09:00 - 10:30', activity: 'Limits, Indeterminate Forms & Series Expansions', type: 'Delta Lesson' },
            { time: '11:00 - 12:30', activity: 'FAST NU & NET 40 MCQ Speed Drill', type: 'Speed Practice' },
            { time: '17:00 - 18:00', activity: 'Spaced Repetition Review of Missed Questions', type: 'Review' },
          ],
          highYieldDeltaTip: 'Avoid triple L\'Hopital differentiation; memorise series for sin(x), e^x, and ln(1+x).',
        },
        {
          day: 'Day 2 (Tuesday)',
          focusSubject: 'Physics',
          theme: 'Electromagnetism & Solenoid End-Effects',
          timeSlots: [
            { time: '09:00 - 10:30', activity: 'Federal Biot-Savart vs Ampere Law Delta Formulations', type: 'Delta Lesson' },
            { time: '11:00 - 12:30', activity: 'Magnetic Field & Induction Timed Drill', type: 'Speed Practice' },
            { time: '17:00 - 18:00', activity: 'Formula Vault & Constant memorization', type: 'Review' },
          ],
          highYieldDeltaTip: 'At solenoid edges, field drops to exactly B/2. Test frequently includes this trick.',
        },
        {
          day: 'Day 3 (Wednesday)',
          focusSubject: 'Chemistry',
          theme: 'Organic Mechanisms & Stereochemistry',
          timeSlots: [
            { time: '09:00 - 10:30', activity: 'Chirality, Optical Activity & Aldol/Cannizzaro Gaps', type: 'Delta Lesson' },
            { time: '11:00 - 12:30', activity: '50 MDCAT/NET Chemistry MCQs', type: 'Speed Practice' },
            { time: '17:00 - 18:00', activity: 'Reagent Elimination Card Practice', type: 'Review' },
          ],
          highYieldDeltaTip: 'Alpha-hydrogen absence is the single deciding factor between Aldol and Cannizzaro.',
        },
      ],
      source: 'fallback',
    });
  } catch (error: any) {
    console.error('Error creating study plan:', error);
    res.status(500).json({
      error: 'Failed to generate study plan',
      details: error.message,
    });
  }
});

// Vite Middleware for Development & Static Serving for Production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DeltaPrep Full-Stack Server running on port ${PORT}`);
  });
}

startServer();
