export type BoardId = 'punjab' | 'federal' | 'sindh' | 'kpk' | 'balochistan';

export type ExamId = 'nust_net' | 'mdcat' | 'fast_nu' | 'comsats_nat';

export type Subject = 'Biology' | 'Chemistry' | 'Physics' | 'Mathematics' | 'English & IQ';

export interface BoardInfo {
  id: BoardId;
  name: string;
  shortCode: string;
  province: string;
  textbookAuthority: string;
  knownStrengths: string;
  commonVulnerabilities: string;
}

export interface ExamInfo {
  id: ExamId;
  name: string;
  shortName: string;
  organizer: string;
  totalQuestions: number;
  totalTimeMinutes: number;
  avgTimePerQuestionSeconds: number;
  negativeMarkingRate: number; // e.g., 0.25 or 0
  primarySyllabusBasis: string; // e.g., "National Curriculum / Federal Board (FBISE)"
  calculatorAllowed: boolean;
  accentColor: string;
  description: string;
}

export interface MicroQuizItem {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  boardOrigin: string;
  explanation: string;
  timeTargetSeconds: number;
}

export interface DeltaTopic {
  id: string;
  title: string;
  subject: Subject;
  importance: 'Critical' | 'High' | 'Medium';
  expectedMarks: string;
  applicableHomeBoards: BoardId[];
  targetExams: ExamId[];
  headlineDifference: string;
  whyBoardMissing: string;
  lesson: {
    overview: string;
    textbookComparison: {
      board: string;
      status: 'Missing' | 'Included' | 'Contradictory' | 'Simplified';
      detail: string;
    }[];
    highYieldBulletPoints: string[];
    formulaOrKeyRule?: string;
    proExamTip: string;
    microQuiz: MicroQuizItem[];
  };
}

export interface MCQQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // 0-indexed
  boardOrigin: string;
  explanation: string;
  timeTargetSeconds: number;
  subject: Subject;
  topicName: string;
  deltaTagged: boolean;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Trick';
}

export interface ProgramMerit {
  name: string;
  previousClosingMerit: number; // e.g. 78.5%
  seatsEstimate: number;
  category: 'High Competitive' | 'Competitive' | 'Moderate';
}

export interface UniversityMeritRule {
  id: ExamId;
  universityName: string;
  examName: string;
  matricWeightage: number; // e.g., 0.10 (10%)
  fscWeightage: number; // e.g., 0.15 (15%)
  testWeightage: number; // e.g., 0.75 (75%)
  testTotalMarks: number; // e.g., 200 for NUST, 100 for FAST, 200 for MDCAT
  hasNegativeMarking: boolean;
  negativePenaltyRate: number; // e.g. 0.25
  closingMeritYear: string;
  programs: ProgramMerit[];
  formulaDescription: string;
  cautionNotice?: string;
}

export interface UserProfile {
  homeBoard: BoardId;
  targetExam: ExamId;
  completedDeltaLessons: string[]; // IDs
  bookmarkedQuestions: string[];
  matricTotalMarks: number;
  matricObtainedMarks: number;
  fscPart1TotalMarks: number;
  fscPart1ObtainedMarks: number;
}

export interface UserAnswerRecord {
  questionId: string;
  selectedOption: number | null; // null if skipped
  isCorrect: boolean;
  isSkipped: boolean;
  timeSpentSeconds: number;
  isTimeSink: boolean; // took > 75-90s and failed or skipped
  savedNegativePenalty: boolean;
}

export interface QuizResultSummary {
  examId: ExamId;
  totalQuestions: number;
  attempted: number;
  correct: number;
  incorrect: number;
  skipped: number;
  scoreRaw: number;
  negativeMarkingDeduction: number;
  netScore: number;
  accuracyRate: number;
  totalTimeSpentSeconds: number;
  avgTimePerQuestion: number;
  timeSinkQuestionsCount: number;
  penaltyAvoidedPoints: number;
  projectedAggregate: number;
  userAnswers: UserAnswerRecord[];
}

export type NavTab = 'dashboard' | 'syllabus' | 'formulas' | 'practice' | 'buddy' | 'analytics';

export type FormulaSubject = 'Physics' | 'Mathematics' | 'Chemistry';

export interface SyllabusTopic {
  id: string;
  title: string;
  examWeightagePct: number;
  conceptDifficulty: 'Easy' | 'Medium' | 'Hard' | 'Trick';
  isDelta?: boolean;
  deltaBadge?: string; // e.g. "Federal Only - absent in Punjab/Sindh"
  highYieldNotes?: string;
  practiceTopicId?: string;
  isCompleted?: boolean;
}

export interface SyllabusChapter {
  id: string;
  chapterNumber: number;
  title: string;
  subject: Subject;
  grade: 'Class 11' | 'Class 12';
  totalTopics: number;
  deltaTopicsCount: number;
  topics: SyllabusTopic[];
}

export interface SyllabusBoardData {
  boardId: BoardId;
  boardName: string;
  shortCode: string;
  chapters: SyllabusChapter[];
}

export interface ShorthandChapterCheatSheet {
  id: string;
  subject: FormulaSubject;
  chapter: string;
  chapterNumber: number;
  grade: 'Class 11' | 'Class 12';
  description: string;
  standardConstants: { name: string; symbol: string; value: string; unit?: string }[];
  coreFormulas: {
    title: string;
    latex: string;
    meaning: string;
    variables: string;
    speedTrick?: string;
  }[];
  identitiesAndTransforms: {
    title: string;
    latex: string;
    note: string;
  }[];
  speedTricksAndEliminations: {
    rule: string;
    example: string;
    shortcut: string;
  }[];
  commonTraps: string[];
}

export interface UniversityProgramMerit2025 {
  program: string;
  campus?: string;
  closingMerit2025: number; // percentage
  safeScoreNeeded: number;
  category: string;
  trend: 'Up +0.8%' | 'Up +1.2%' | 'Stable' | 'Up +0.4%' | 'Up +0.6%';
}

export interface UniversityMerit2025Rule {
  id: ExamId;
  universityName: string;
  shortName: string;
  formula: string;
  matricWeightage: number;
  fscWeightage: number;
  testWeightage: number;
  testTotalMarks: number;
  hasNegativeMarking: boolean;
  penaltyPerWrong: number;
  programs: UniversityProgramMerit2025[];
  closingYear: '2025';
  cautionNotice?: string;
}

export interface UserProfileData {
  name: string;
  email: string;
  avatarUrl?: string;
  isAuthenticated: boolean;
  streakDays: number;
  xp: number;
  homeBoard: BoardId;
  targetExam: ExamId;
  matricPercentage: number;
  fscPart1Percentage: number;
  syncStatus: 'synced' | 'syncing' | 'offline';
  lastSyncedAt: string;
}

export interface FormulaItem {
  id: string;
  subject: FormulaSubject;
  chapter: string;
  title: string;
  latex: string;
  variableBreakdown: { symbol: string; meaning: string; units?: string }[];
  shortcutTip: string;
  boardOrigin: string;
  tags: string[];
  isStarred?: boolean;
}

export interface StudyTimetableSlot {
  id: string;
  time: string;
  subject: Subject;
  topic: string;
  duration: string;
  status: 'Completed' | 'In Progress' | 'Upcoming';
  badge: string;
}

export interface StudyBuddyNotification {
  id: string;
  time: string;
  type: 'alert' | 'streak' | 'delta';
  message: string;
}

export interface SubjectReadiness {
  subject: Subject;
  score: number;
  status: 'Strong' | 'Needs Drill' | 'Critical Delta';
  weakTopics: string[];
  totalSolved: number;
}

export interface StudyBuddyData {
  overallReadiness: number;
  weeklyStudyHours: number;
  targetWeeklyHours: number;
  timetable: StudyTimetableSlot[];
  notifications: StudyBuddyNotification[];
  subjectReadiness: SubjectReadiness[];
  weakTopicAlerts: { topic: string; subject: Subject; examRelevance: string; severity: 'High' | 'Medium' }[];
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  latexSnippet?: string;
  hints?: string[];
  steps?: { stepNumber: number; title: string; explanation: string; math?: string }[];
  attachmentUrl?: string;
  attachmentName?: string;
}

export interface AuthUser {
  isAuthenticated: boolean;
  name: string;
  email: string;
  avatarUrl?: string;
  streakDays: number;
  xp: number;
  isSyncing: boolean;
  lastSyncedAt: string;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  board: string;
  targetExam: string;
  aggregate: number;
  percentile: string;
  isCurrentUser?: boolean;
}

export type PracticeMode = 'full_mock' | 'chapter_practice' | 'board_mode';
