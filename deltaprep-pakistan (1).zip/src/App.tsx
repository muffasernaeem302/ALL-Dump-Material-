import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DeltaDashboard } from './components/DeltaDashboard';
import { StudyBuddy } from './components/StudyBuddy';
import { FormulaVault } from './components/FormulaVault';
import { PracticeEngine } from './components/PracticeEngine';
import { AnalyticsView } from './components/AnalyticsView';
import { SyllabusExplorer } from './components/SyllabusExplorer';
import { BookmarksView } from './components/BookmarksView';
import { RecordsPage } from './components/records/RecordsPage';
import { MasteryDashboard } from './components/mastery/MasteryDashboard';
import { AuthModal } from './components/AuthModal';
import { OnboardingModal } from './components/OnboardingModal';
import { DeltaLessonModal } from './components/DeltaLessonModal';
import { BoardId, ExamId, DeltaTopic, NavTab, AuthUser, FormulaItem } from './types';
import { DELTA_TOPICS } from './data';
import { Sparkles, MessageSquare, X } from 'lucide-react';

export default function App() {
  // User Profile state with local storage fallback
  const [homeBoard, setHomeBoard] = useState<BoardId>(() => {
    const saved = localStorage.getItem('deltaprep_home_board');
    return (saved as BoardId) || 'punjab';
  });

  const [targetExam, setTargetExam] = useState<ExamId>(() => {
    const saved = localStorage.getItem('deltaprep_target_exam');
    return (saved as ExamId) || 'nust_net';
  });

  const [completedDeltaLessons, setCompletedDeltaLessons] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('deltaprep_completed_lessons');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [matricPct, setMatricPct] = useState<number>(() => {
    const saved = localStorage.getItem('deltaprep_matric_pct');
    return saved ? parseFloat(saved) : 91.5;
  });

  const [fscPct, setFscPct] = useState<number>(() => {
    const saved = localStorage.getItem('deltaprep_fsc_pct');
    return saved ? parseFloat(saved) : 88.0;
  });

  // Google OAuth & Cloud Sync mock state
  const [authUser, setAuthUser] = useState<AuthUser>(() => {
    try {
      const saved = localStorage.getItem('deltaprep_auth_user');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      isAuthenticated: true,
      name: 'Muffaser Naeem',
      email: 'muffasernaeem302@gmail.com',
      streakDays: 7,
      xp: 1450,
      isSyncing: false,
      lastSyncedAt: '3m ago',
    };
  });

  // UI Navigation & Modals
  const [currentTab, setCurrentTab] = useState<NavTab>('dashboard');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(() => {
    return !localStorage.getItem('deltaprep_has_onboarded');
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [activeLessonTopic, setActiveLessonTopic] = useState<DeltaTopic | null>(null);

  // Floating Study Buddy Drawer state
  const [isBuddyDrawerOpen, setIsBuddyDrawerOpen] = useState<boolean>(false);
  const [buddyPromptContext, setBuddyPromptContext] = useState<string>('');

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('deltaprep_home_board', homeBoard);
  }, [homeBoard]);

  useEffect(() => {
    localStorage.setItem('deltaprep_target_exam', targetExam);
  }, [targetExam]);

  useEffect(() => {
    localStorage.setItem('deltaprep_completed_lessons', JSON.stringify(completedDeltaLessons));
  }, [completedDeltaLessons]);

  useEffect(() => {
    localStorage.setItem('deltaprep_matric_pct', matricPct.toString());
    localStorage.setItem('deltaprep_fsc_pct', fscPct.toString());
  }, [matricPct, fscPct]);

  useEffect(() => {
    localStorage.setItem('deltaprep_auth_user', JSON.stringify(authUser));
  }, [authUser]);

  // Handler for marking lesson completed
  const handleMarkCompleted = (topicId: string) => {
    setCompletedDeltaLessons((prev) => {
      if (!prev.includes(topicId)) {
        // Boost XP on lesson completion
        setAuthUser((u) => ({ ...u, xp: u.xp + 100 }));
        return [...prev, topicId];
      }
      return prev;
    });
  };

  const handleSaveProfile = (newBoard: BoardId, newExam: ExamId) => {
    setHomeBoard(newBoard);
    setTargetExam(newExam);
    localStorage.setItem('deltaprep_has_onboarded', 'true');
  };

  const handleUpdateAcademics = (matric: number, fsc: number) => {
    setMatricPct(matric);
    setFscPct(fsc);
  };

  const handleAskBuddyWithContext = (contextText: string) => {
    setBuddyPromptContext(contextText);
    setIsBuddyDrawerOpen(true);
  };

  const handleAskBuddyForFormula = (formula: FormulaItem) => {
    handleAskBuddyWithContext(
      `Please explain how to derive and apply the formula "${formula.title}" (${formula.latex}) in exam numericals, and highlight why it is tested differently in ${formula.boardOrigin}.`
    );
  };

  return (
    <div className="min-h-screen bg-[#0a0c10] text-[#e6edf3] flex flex-col selection:bg-sky-500/25 selection:text-sky-200">
      {/* Sticky Top Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          // If switching to buddy tab directly, close floating drawer to avoid duplication
          if (tab === 'buddy') {
            setIsBuddyDrawerOpen(false);
          }
        }}
        homeBoard={homeBoard}
        targetExam={targetExam}
        onOpenProfileModal={() => setIsProfileModalOpen(true)}
        completedLessonsCount={completedDeltaLessons.length}
        totalDeltaLessons={DELTA_TOPICS.length}
        authUser={authUser}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main App Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-4 lg:px-6 py-4">
        {/* 1. Dashboard Tab */}
        {currentTab === 'dashboard' && (
          <DeltaDashboard
            homeBoard={homeBoard}
            targetExam={targetExam}
            completedDeltaLessons={completedDeltaLessons}
            onOpenTopicModal={(topic) => setActiveLessonTopic(topic)}
            onOpenProfileModal={() => setIsProfileModalOpen(true)}
            onStartQuizMode={() => setCurrentTab('practice')}
          />
        )}

        {/* 2. Syllabus Explorer Tab */}
        {currentTab === 'syllabus' && (
          <SyllabusExplorer
            homeBoard={homeBoard}
            targetExam={targetExam}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onAskStudyBuddy={handleAskBuddyWithContext}
            onStartTopicPractice={(subject, topicTitle) => {
              setCurrentTab('practice');
            }}
          />
        )}

        {/* 2. AI Study Buddy Tab */}
        {currentTab === 'buddy' && (
          <StudyBuddy
            isDrawerMode={false}
            homeBoard={homeBoard}
            targetExam={targetExam}
            initialQuestionPrompt={buddyPromptContext}
            onSelectPractice={() => setCurrentTab('practice')}
          />
        )}

        {/* 3. Formula Vault Tab */}
        {currentTab === 'formulas' && (
          <FormulaVault
            onAskStudyBuddy={handleAskBuddyForFormula}
            onGoToPractice={() => setCurrentTab('practice')}
          />
        )}

        {/* 4. Practice & Mocks Tab */}
        {currentTab === 'practice' && (
          <PracticeEngine
            targetExam={targetExam}
            homeBoard={homeBoard}
            matricPct={matricPct}
            fscPct={fscPct}
            onReturnToDashboard={() => setCurrentTab('dashboard')}
            onAskStudyBuddy={handleAskBuddyWithContext}
            onOpenTopicById={(topicId) => {
              const found = DELTA_TOPICS.find((t) => t.id === topicId);
              if (found) setActiveLessonTopic(found);
            }}
          />
        )}

        {/* 5. Analytics & Calculator Tab */}
        {currentTab === 'analytics' && (
          <AnalyticsView
            initialExam={targetExam}
            matricPct={matricPct}
            fscPct={fscPct}
            homeBoard={homeBoard}
            onUpdateAcademics={handleUpdateAcademics}
            onGoToPractice={() => setCurrentTab('practice')}
          />
        )}

        {/* 6. Bookmarks & Spaced Review Tab */}
        {currentTab === 'bookmarks' && (
          <BookmarksView
            onStartPractice={() => setCurrentTab('practice')}
            onAskStudyBuddy={handleAskBuddyWithContext}
          />
        )}

        {/* 7. Progressive Topic Mastery & Level Unlocking */}
        {currentTab === 'mastery' && (
          <MasteryDashboard
            onStartLevelPractice={() => {
              setCurrentTab('practice');
            }}
          />
        )}

        {/* 8. Test Records History Archive */}
        {currentTab === 'records' && (
          <RecordsPage
            onStartPractice={() => setCurrentTab('practice')}
            onAskStudyBuddy={handleAskBuddyWithContext}
          />
        )}
      </main>

      {/* Floating AI Study Buddy Launcher Widget (Shown when not on the Buddy tab) */}
      {currentTab !== 'buddy' && (
        <div className="fixed bottom-4 right-4 z-40">
          <button
            id="floating-buddy-launcher-btn"
            onClick={() => setIsBuddyDrawerOpen(!isBuddyDrawerOpen)}
            className="flex items-center space-x-2 px-3.5 py-2.5 rounded-full bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-semibold text-xs shadow-lg shadow-sky-500/20 transition-all hover:scale-105 cursor-pointer border border-sky-400/30"
            title="Ask AI Study Buddy anything"
          >
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span>AI Study Buddy</span>
            <span className="h-2 w-2 rounded-full bg-emerald-400" />
          </button>
        </div>
      )}

      {/* Floating Study Buddy Slide-Over Drawer */}
      {isBuddyDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
          <div
            id="buddy-slideover-drawer"
            className="w-full max-w-xl h-full bg-[#161b22] border-l border-[#30363d] shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200"
          >
            <div className="flex-1 overflow-y-auto p-4">
              <StudyBuddy
                isDrawerMode={true}
                onCloseDrawer={() => setIsBuddyDrawerOpen(false)}
                initialQuestionPrompt={buddyPromptContext}
                onSelectPractice={() => {
                  setIsBuddyDrawerOpen(false);
                  setCurrentTab('practice');
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Google OAuth & Cloud Sync Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        authUser={authUser}
        onUpdateAuthUser={setAuthUser}
      />

      {/* Target Board / Exam Onboarding & Switcher Modal */}
      <OnboardingModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentHomeBoard={homeBoard}
        currentTargetExam={targetExam}
        onSaveProfile={handleSaveProfile}
      />

      {/* 5-Minute Gap Fill Lesson Modal */}
      <DeltaLessonModal
        topic={activeLessonTopic}
        onClose={() => setActiveLessonTopic(null)}
        onMarkCompleted={handleMarkCompleted}
        isAlreadyCompleted={
          activeLessonTopic ? completedDeltaLessons.includes(activeLessonTopic.id) : false
        }
      />

      {/* Footer */}
      <footer className="border-t border-[#30363d] bg-[#0d1117] py-3 text-xs text-gray-400 mt-auto">
        <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2 text-[11px]">
            <span className="font-bold text-gray-200">DeltaPrep Pakistan</span>
            <span className="text-gray-600">|</span>
            <span className="text-gray-400">
              Commercial-Grade Exam Prep & Dual-Syllabus Gap Engine
            </span>
          </div>
          <div className="text-gray-500 font-mono text-[10px]">
            Federal (FBISE) · Punjab · Sindh · KPK → NUST NET · FAST NU · MDCAT · COMSATS
          </div>
        </div>
      </footer>
    </div>
  );
}
