// Re-export full TypeScript dataset and structured JSON
export * from './data.ts';

// Structured exports matching exact prompt keys
import {
  formulasData,
  studyBuddyData,
  mockQuestions,
  meritData,
  meritData2025,
  leaderboardData,
  sampleChatResponses,
  syllabusData,
  shorthandFormulas,
  userProfile,
} from './data.ts';

export {
  formulasData,
  studyBuddyData,
  mockQuestions,
  meritData,
  meritData2025,
  leaderboardData,
  sampleChatResponses,
  syllabusData,
  shorthandFormulas,
  userProfile,
};
