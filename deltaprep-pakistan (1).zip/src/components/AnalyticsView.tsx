import React, { useState } from 'react';
import {
  Calculator,
  Target,
  Award,
  TrendingUp,
  Sparkles,
  Trophy,
  Filter,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
  UserCheck,
  BarChart3,
  Sliders,
  HelpCircle,
  Flame,
} from 'lucide-react';
import { ExamId, LeaderboardEntry, BoardId } from '../types';
import { EXAMS, leaderboardData, meritData2025 } from '../data';

interface AnalyticsViewProps {
  initialExam?: ExamId;
  matricPct: number;
  fscPct: number;
  homeBoard?: BoardId;
  onUpdateAcademics: (matric: number, fsc: number) => void;
  onGoToPractice?: () => void;
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  initialExam = 'nust_net',
  matricPct,
  fscPct,
  homeBoard,
  onUpdateAcademics,
  onGoToPractice,
}) => {
  // Map ExamId to meritData2025 key
  const getExamKey = (id: ExamId): 'nust' | 'fast' | 'comsats' | 'mdcat' => {
    if (id === 'nust_net') return 'nust';
    if (id === 'fast_nu') return 'fast';
    if (id === 'comsats_nat') return 'comsats';
    return 'mdcat';
  };

  const [selectedExamId, setSelectedExamId] = useState<ExamId>(initialExam);
  const [inputMatric, setInputMatric] = useState<string>(matricPct.toString());
  const [inputFsc, setInputFsc] = useState<string>(fscPct.toString());
  const [selectedProgramIndex, setSelectedProgramIndex] = useState<number>(0);
  const [leaderboardBoardFilter, setLeaderboardBoardFilter] = useState<string>('All');
  const [simulatedWrongGuesses, setSimulatedWrongGuesses] = useState<number>(0);

  const activeKey = getExamKey(selectedExamId);
  const currentRule = meritData2025[activeKey] || meritData2025.nust;

  // Parse percentages
  const parsedMatric = Math.min(100, Math.max(0, parseFloat(inputMatric) || 0));
  const parsedFsc = Math.min(100, Math.max(0, parseFloat(inputFsc) || 0));

  // Sensitivity Slider score (default to ~78% of max marks)
  const [simulatedScore, setSimulatedScore] = useState<number>(() => {
    return Math.round(currentRule.testTotalMarks * 0.78);
  });

  const handleSelectExam = (id: ExamId) => {
    setSelectedExamId(id);
    const newKey = getExamKey(id);
    const newRule = meritData2025[newKey];
    setSimulatedScore(Math.round(newRule.testTotalMarks * 0.78));
    setSelectedProgramIndex(0);
    setSimulatedWrongGuesses(0);
  };

  // Academic Base calculation
  const matricContribution = parsedMatric * currentRule.matricWeightage;
  const fscContribution = parsedFsc * currentRule.fscWeightage;
  const academicBase = parseFloat((matricContribution + fscContribution).toFixed(2));

  // Selected program
  const currentProgram = currentRule.programs[selectedProgramIndex] || currentRule.programs[0];
  const targetClosingMerit = currentProgram.closingMerit2025;

  // Raw marks needed for target closing merit
  const requiredAggregateFromTest = targetClosingMerit - academicBase;
  const requiredTestPct = (requiredAggregateFromTest / (currentRule.testWeightage * 100)) * 100;
  const requiredRawMarks = Math.ceil((requiredTestPct / 100) * currentRule.testTotalMarks);

  // Simulated net score with penalty deduction
  const penaltyDeduction = currentRule.hasNegativeMarking
    ? simulatedWrongGuesses * currentRule.penaltyPerWrong
    : 0;
  const simulatedNetMarks = Math.max(0, simulatedScore - penaltyDeduction);
  const simulatedTestPct = (simulatedNetMarks / currentRule.testTotalMarks) * 100;
  const simulatedAggregate = parseFloat(
    (academicBase + simulatedTestPct * currentRule.testWeightage).toFixed(2)
  );

  const aggregateDelta = parseFloat((simulatedAggregate - targetClosingMerit).toFixed(2));
  const isSafe = aggregateDelta >= 1.5;
  const isBorderline = aggregateDelta >= -0.5 && aggregateDelta < 1.5;
  const isReach = aggregateDelta < -0.5;

  const handleUpdate = (m: number, f: number) => {
    onUpdateAcademics(m, f);
  };

  // Filtered leaderboard
  const filteredLeaderboard = leaderboardData.filter((entry) => {
    if (leaderboardBoardFilter === 'All') return true;
    return entry.board.includes(leaderboardBoardFilter) || entry.board === leaderboardBoardFilter;
  });

  return (
    <div className="space-y-4 pb-12">
      {/* Header Banner */}
      <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="h-6 w-6 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">
                %
              </span>
              <h2 className="text-base sm:text-lg font-bold text-[#e6edf3]">
                2025 University Merit Predictor & Aggregate Sensitivity Simulator
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                Official 2025 Benchmarks
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1 max-w-2xl">
              Simulates exact aggregate calculation formulas for NUST (NET), FAST-NUCES (NU-Test), COMSATS (NAT), and PMDC (MDCAT) with negative marking penalties and sensitivity curves.
            </p>
          </div>
        </div>

        {/* University Selector Tabs */}
        <div className="mt-4 pt-4 border-t border-[#30363d] flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'nust_net' as ExamId, key: 'nust', label: 'NUST (NET)', weight: '75% Test' },
            { id: 'fast_nu' as ExamId, key: 'fast', label: 'FAST-NUCES', weight: '50% Test (-0.25)' },
            { id: 'comsats_nat' as ExamId, key: 'comsats', label: 'COMSATS (NAT)', weight: '50% Test' },
            { id: 'mdcat' as ExamId, key: 'mdcat', label: 'PMDC (MDCAT)', weight: '50% MDCAT' },
          ].map((tab) => {
            const isSelected = tab.id === selectedExamId;
            return (
              <button
                key={tab.id}
                id={`univ-tab-${tab.id}`}
                onClick={() => handleSelectExam(tab.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-sky-500 text-white shadow-xs font-bold'
                    : 'text-gray-300 hover:text-white bg-[#0d1117] border border-[#30363d]'
                }`}
              >
                <span>{tab.label}</span>
                <span className="text-[10px] font-mono px-1 rounded bg-[#0d1117]/80 text-gray-300 border border-[#30363d]">
                  {tab.weight}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Inputs on Left, Output & Sensitivity on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Academic Inputs & Program Target */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-xl bg-[#161b22] border border-[#30363d] space-y-4">
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-gray-400 flex items-center justify-between">
              <span>Step 1: Academic Inputs</span>
              <span className="text-sky-400 text-[10px]">
                Weight: {Math.round((currentRule.matricWeightage + currentRule.fscWeightage) * 100)}%
              </span>
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] font-medium text-gray-300 block mb-1">
                  Matriculation Marks (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="40"
                    max="100"
                    step="0.1"
                    value={inputMatric}
                    onChange={(e) => {
                      setInputMatric(e.target.value);
                      const val = parseFloat(e.target.value) || 0;
                      handleUpdate(val, parsedFsc);
                    }}
                    className="w-full bg-[#0d1117] border border-[#30363d] rounded-md px-3 py-1.5 text-xs text-[#e6edf3] font-mono focus:outline-none focus:border-sky-500"
                  />
                  <span className="absolute right-2.5 top-1.5 text-xs text-gray-500 font-mono">%</span>
                </div>
                <span className="text-[10px] text-gray-500 mt-1 block">
                  Weight: {Math.round(currentRule.matricWeightage * 100)}% → {(parsedMatric * currentRule.matricWeightage).toFixed(2)}%
                </span>
              </div>

              <div>
                <label className="text-[11px] font-medium text-gray-300 block mb-1">
                  FSc Part-1 Marks (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="40"
                    max="100"
                    step="0.1"
                    value={inputFsc}
                    onChange={(e) => {
                      setInputFsc(e.target.value);
                      const val = parseFloat(e.target.value) || 0;
                      handleUpdate(parsedMatric, val);
                    }}
                    className="w-full bg-[#0d1117] border border-[#30363d] rounded-md px-3 py-1.5 text-xs text-[#e6edf3] font-mono focus:outline-none focus:border-sky-500"
                  />
                  <span className="absolute right-2.5 top-1.5 text-xs text-gray-500 font-mono">%</span>
                </div>
                <span className="text-[10px] text-gray-500 mt-1 block">
                  Weight: {Math.round(currentRule.fscWeightage * 100)}% → {(parsedFsc * currentRule.fscWeightage).toFixed(2)}%
                </span>
              </div>
            </div>

            {/* Academic Base Score Banner */}
            <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] flex items-center justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono text-gray-400 block">
                  Academic Base (Locked Prior to Test)
                </span>
                <span className="text-xs text-gray-400">
                  {parsedMatric}% × {currentRule.matricWeightage * 100}% + {parsedFsc}% × {currentRule.fscWeightage * 100}%
                </span>
              </div>
              <span className="text-base font-bold font-mono text-sky-400">
                {academicBase.toFixed(2)}%
              </span>
            </div>

            {/* Program Selection */}
            <div className="pt-2 border-t border-[#30363d]">
              <label className="text-[11px] font-mono text-gray-400 uppercase tracking-wider block mb-2">
                Step 2: Select 2025 Target Degree / Program
              </label>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {currentRule.programs.map((prog, idx) => {
                  const isSelected = idx === selectedProgramIndex;
                  return (
                    <div
                      key={idx}
                      onClick={() => setSelectedProgramIndex(idx)}
                      className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-sky-500/10 border-sky-500/40 text-white'
                          : 'bg-[#0d1117] border-[#30363d] text-gray-300 hover:border-slate-600'
                      }`}
                    >
                      <div className="flex flex-col">
                        <span className="text-xs font-semibold leading-tight">{prog.program}</span>
                        <div className="flex items-center space-x-1.5 mt-0.5">
                          <span className="text-[10px] text-gray-400 font-mono">
                            {prog.campus || currentRule.shortName}
                          </span>
                          <span className="text-[10px] text-amber-400 font-mono">
                            {prog.trend}
                          </span>
                        </div>
                      </div>
                      <div className="text-right shrink-0 ml-2">
                        <span className="text-xs font-mono font-bold text-sky-300 block">
                          {prog.closingMerit2025.toFixed(2)}%
                        </span>
                        <span className="text-[9px] text-gray-400 font-mono">
                          2025 Cutoff
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Caution Notice */}
            {currentRule.cautionNotice && (
              <div className="p-3 rounded-lg bg-sky-950/20 border border-sky-800/40 text-xs text-sky-200/90 leading-relaxed">
                <span className="font-semibold text-sky-400">Insight: </span>
                {currentRule.cautionNotice}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Dynamic Simulator & Sensitivity Slider */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-4 sm:p-5 rounded-xl bg-[#161b22] border border-[#30363d] space-y-5">
            <div className="flex items-center justify-between border-b border-[#30363d] pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center space-x-1.5">
                  <Sliders className="w-4 h-4 text-sky-400" />
                  <span>Entry Test Score Simulator & Sensitivity Analysis</span>
                </h3>
                <p className="text-xs text-gray-400 mt-0.5">
                  Drag the slider to test aggregate sensitivity to every individual MCQ mark.
                </p>
              </div>

              <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-gray-300">
                Max Marks: {currentRule.testTotalMarks}
              </span>
            </div>

            {/* Target vs Simulated Comparison Card */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Target Requirement Card */}
              <div className="p-3.5 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-2">
                <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block">
                  Required for 2025 Closing Merit
                </span>
                <div className="flex items-baseline space-x-2">
                  <span className="text-2xl font-bold font-mono text-white">
                    {targetClosingMerit.toFixed(2)}%
                  </span>
                  <span className="text-xs text-gray-400">cutoff</span>
                </div>
                <div className="text-xs text-gray-300 space-y-0.5 pt-1 border-t border-[#30363d]/60 font-mono">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Min Raw Marks:</span>
                    <span className="text-amber-300 font-bold">
                      {Math.max(0, requiredRawMarks)} / {currentRule.testTotalMarks}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Min Test %:</span>
                    <span className="text-sky-300">
                      {Math.max(0, Math.min(100, Math.round(requiredTestPct)))}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Simulated Projected Aggregate */}
              <div
                className={`p-3.5 rounded-lg border space-y-2 transition-colors ${
                  isSafe
                    ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200'
                    : isBorderline
                    ? 'bg-amber-950/20 border-amber-500/40 text-amber-200'
                    : 'bg-red-950/20 border-red-500/40 text-red-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider">
                    Your Simulated Aggregate
                  </span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold font-mono ${
                      isSafe
                        ? 'bg-emerald-500/20 text-emerald-300'
                        : isBorderline
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-red-500/20 text-red-300'
                    }`}
                  >
                    {isSafe ? 'High Chance (Safe)' : isBorderline ? 'Borderline Range' : 'High Reach'}
                  </span>
                </div>
                <div className="flex items-baseline space-x-2">
                  <span className="text-2xl font-bold font-mono text-white">
                    {simulatedAggregate.toFixed(2)}%
                  </span>
                  <span className="text-xs font-mono">
                    ({aggregateDelta >= 0 ? `+${aggregateDelta.toFixed(2)}%` : `${aggregateDelta.toFixed(2)}%`})
                  </span>
                </div>
                <div className="text-xs space-y-0.5 pt-1 border-t border-white/10 font-mono">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Simulated Net Marks:</span>
                    <span className="text-white font-bold">
                      {simulatedNetMarks} / {currentRule.testTotalMarks}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Test Score Slider */}
            <div className="space-y-2 p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-300 font-medium">Simulated Test Score:</span>
                <span className="font-mono text-sm font-bold text-sky-400">
                  {simulatedScore} / {currentRule.testTotalMarks} ({Math.round((simulatedScore / currentRule.testTotalMarks) * 100)}%)
                </span>
              </div>

              <input
                type="range"
                min="0"
                max={currentRule.testTotalMarks}
                step="1"
                value={simulatedScore}
                onChange={(e) => setSimulatedScore(parseInt(e.target.value) || 0)}
                className="w-full accent-sky-500 cursor-pointer h-2 bg-slate-700 rounded-lg"
              />

              <div className="flex justify-between text-[10px] text-gray-500 font-mono">
                <span>0</span>
                <span>50% ({Math.round(currentRule.testTotalMarks * 0.5)})</span>
                <span>Safe Target ({currentRule.programs[selectedProgramIndex]?.safeScoreNeeded || Math.round(currentRule.testTotalMarks * 0.78)})</span>
                <span>{currentRule.testTotalMarks}</span>
              </div>
            </div>

            {/* Negative Marking Simulator (for FAST NU-Test) */}
            {currentRule.hasNegativeMarking && (
              <div className="p-3 rounded-lg bg-red-950/20 border border-red-800/40 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-1.5 text-red-400 font-semibold">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>FAST Negative Marking Penalty Simulator (-0.25 / wrong guess)</span>
                  </div>
                  <span className="font-mono text-red-300 font-bold">
                    -{penaltyDeduction.toFixed(2)} marks
                  </span>
                </div>

                <div className="flex items-center space-x-3">
                  <input
                    type="range"
                    min="0"
                    max="40"
                    step="1"
                    value={simulatedWrongGuesses}
                    onChange={(e) => setSimulatedWrongGuesses(parseInt(e.target.value) || 0)}
                    className="w-full accent-red-500 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
                  />
                  <span className="text-xs font-mono text-gray-300 whitespace-nowrap">
                    {simulatedWrongGuesses} wrong
                  </span>
                </div>

                <p className="text-[11px] text-gray-400">
                  <strong className="text-red-300">Strategic Rule: </strong>
                  Skipping an unsure question costs 0.0 marks. Guessing incorrectly strips 0.25 marks, which drops your aggregate by {(0.25 * (currentRule.testWeightage / currentRule.testTotalMarks) * 100).toFixed(3)}%!
                </p>
              </div>
            )}

            {/* Quick sensitivity rules table */}
            <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] text-xs">
              <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider block mb-1">
                Sensitivity Rate for {currentRule.shortName}:
              </span>
              <p className="text-gray-300 leading-relaxed">
                • Every <strong className="text-sky-400">+5 marks</strong> in the test yields a{' '}
                <strong className="text-emerald-400">
                  +{((5 / currentRule.testTotalMarks) * currentRule.testWeightage * 100).toFixed(2)}%
                </strong>{' '}
                gain on your final aggregate.
              </p>
            </div>
          </div>

          {/* National Percentile Leaderboard Preview */}
          <div className="p-4 sm:p-5 rounded-xl bg-[#161b22] border border-[#30363d] space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#30363d] pb-3">
              <div className="flex items-center space-x-2">
                <Trophy className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white">
                  National Percentile Benchmark Cohort (2025 Aspirants)
                </h3>
              </div>

              {/* Filter by board */}
              <div className="flex items-center space-x-1.5 text-xs">
                <span className="text-gray-400 font-mono text-[11px]">Board:</span>
                {(['All', 'Federal', 'Punjab', 'Sindh', 'KPK'] as const).map((b) => (
                  <button
                    key={b}
                    onClick={() => setLeaderboardBoardFilter(b)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                      leaderboardBoardFilter === b
                        ? 'bg-sky-600 text-white'
                        : 'bg-[#0d1117] text-gray-400 hover:text-white border border-[#30363d]'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#30363d] text-gray-400 font-mono text-[11px]">
                    <th className="py-2 px-2">Rank</th>
                    <th className="py-2 px-2">Aspirant</th>
                    <th className="py-2 px-2">Board</th>
                    <th className="py-2 px-2">Target</th>
                    <th className="py-2 px-2 text-right">Aggregate</th>
                    <th className="py-2 px-2 text-right">Percentile</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#30363d]/60 font-mono">
                  {filteredLeaderboard.map((item) => (
                    <tr
                      key={item.rank}
                      className={`${
                        item.isCurrentUser
                          ? 'bg-sky-500/10 text-sky-200 font-bold'
                          : 'text-gray-300 hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="py-2 px-2 text-gray-400">
                        {item.rank === 1 ? '🥇' : item.rank === 2 ? '🥈' : item.rank === 3 ? '🥉' : `#${item.rank}`}
                      </td>
                      <td className="py-2 px-2 font-sans font-semibold">
                        {item.name} {item.isCurrentUser && <span className="text-sky-400 text-[10px]">(You)</span>}
                      </td>
                      <td className="py-2 px-2 text-gray-400">{item.board}</td>
                      <td className="py-2 px-2 text-gray-300">{item.targetExam}</td>
                      <td className="py-2 px-2 text-right text-white font-bold">
                        {item.isCurrentUser ? simulatedAggregate.toFixed(2) : item.aggregate.toFixed(2)}%
                      </td>
                      <td className="py-2 px-2 text-right text-emerald-400">{item.percentile}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
