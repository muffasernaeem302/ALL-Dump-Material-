import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Check, ArrowRight, BookOpen, AlertTriangle, Sparkles, Target, Zap } from 'lucide-react';
import { BoardId, ExamId } from '../types';
import { BOARDS, EXAMS } from '../data';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentHomeBoard: BoardId;
  currentTargetExam: ExamId;
  onSaveProfile: (homeBoard: BoardId, targetExam: ExamId) => void;
}

export const OnboardingModal: React.FC<OnboardingModalProps> = ({
  isOpen,
  onClose,
  currentHomeBoard,
  currentTargetExam,
  onSaveProfile,
}) => {
  const [selectedBoard, setSelectedBoard] = useState<BoardId>(currentHomeBoard);
  const [selectedExam, setSelectedExam] = useState<ExamId>(currentTargetExam);
  const [activeStep, setActiveStep] = useState<1 | 2>(1);

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveProfile(selectedBoard, selectedExam);
    onClose();
  };

  const selectedBoardObj = BOARDS.find((b) => b.id === selectedBoard) || BOARDS[0];
  const selectedExamObj = EXAMS.find((e) => e.id === selectedExam) || EXAMS[0];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.15 }}
          className="relative w-full max-w-2xl bg-[#161b22] border border-[#30363d] rounded-lg shadow-xl overflow-hidden my-4 text-[#e6edf3]"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-[#30363d] bg-[#0d1117]">
            <div className="flex items-center space-x-2.5">
              <div className="w-7 h-7 rounded bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 font-bold font-mono text-xs">
                Δ
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Target Profile Setup</h3>
                <p className="text-[11px] text-gray-400">Configure your provincial curriculum vs test syllabus</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded text-gray-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Stepper Tabs */}
          <div className="grid grid-cols-2 border-b border-[#30363d] bg-[#0d1117]/60 text-xs font-medium text-center">
            <button
              onClick={() => setActiveStep(1)}
              className={`py-2 px-3 flex items-center justify-center space-x-2 border-b-2 transition-colors cursor-pointer ${
                activeStep === 1
                  ? 'border-sky-500 text-sky-400 bg-sky-500/5'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <span className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-mono bg-[#161b22] border border-[#30363d]">
                1
              </span>
              <span className="text-xs">1. Home Intermediate Board</span>
            </button>
            <button
              onClick={() => setActiveStep(2)}
              className={`py-2 px-3 flex items-center justify-center space-x-2 border-b-2 transition-colors cursor-pointer ${
                activeStep === 2
                  ? 'border-sky-500 text-sky-400 bg-sky-500/5'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <span className="w-4 h-4 rounded-full flex items-center justify-center text-[10px] font-mono bg-[#161b22] border border-[#30363d]">
                2
              </span>
              <span className="text-xs">2. Target Entrance Exam</span>
            </button>
          </div>

          {/* Body Content */}
          <div className="p-4 max-h-[65vh] overflow-y-auto space-y-4">
            {activeStep === 1 ? (
              <div className="space-y-3">
                <div>
                  <h4 className="text-xs font-semibold text-gray-200">Where did you study FSc / A-Level?</h4>
                  <p className="text-[11px] text-gray-400">
                    Our Delta Engine will contrast your board's textbooks against the national test syllabus.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {BOARDS.map((board) => {
                    const isSelected = selectedBoard === board.id;
                    return (
                      <button
                        key={board.id}
                        type="button"
                        onClick={() => setSelectedBoard(board.id)}
                        className={`text-left p-3 rounded-md border transition-colors cursor-pointer relative ${
                          isSelected
                            ? 'bg-sky-500/10 border-sky-500/50 shadow-sm'
                            : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="text-xs font-bold text-white flex items-center space-x-1.5">
                              <span>{board.name}</span>
                            </div>
                            <div className="text-[10px] text-sky-400 font-mono mt-0.5">
                              {board.textbookAuthority}
                            </div>
                          </div>
                          {isSelected && (
                            <div className="w-4 h-4 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center flex-shrink-0">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </div>
                          )}
                        </div>
                        <p className="text-[11px] text-gray-400 mt-1.5 line-clamp-2 leading-relaxed">
                          {board.commonVulnerabilities}
                        </p>
                      </button>
                    );
                  })}
                </div>

                <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] text-xs text-gray-300 flex items-start space-x-2">
                  <Sparkles className="w-3.5 h-3.5 text-sky-400 mt-0.5 flex-shrink-0" />
                  <div className="text-[11px] leading-relaxed">
                    <span className="font-semibold text-white">Why this matters: </span>
                    Over 30% of negative marks in tests like NUST NET and FAST stem from topics that are present in Federal Board textbooks but absent in provincial boards.
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <h4 className="text-xs font-semibold text-gray-200">Which entrance exam are you targeting?</h4>
                  <p className="text-[11px] text-gray-400">
                    We tune your gap analysis, pacing simulator, and merit calculators accordingly.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {EXAMS.map((exam) => {
                    const isSelected = selectedExam === exam.id;
                    return (
                      <button
                        key={exam.id}
                        type="button"
                        onClick={() => setSelectedExam(exam.id)}
                        className={`text-left p-3 rounded-md border transition-colors cursor-pointer relative ${
                          isSelected
                            ? 'bg-sky-500/10 border-sky-500/50 shadow-sm'
                            : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="text-xs font-bold text-white flex items-center space-x-1.5">
                              <span>{exam.name}</span>
                            </div>
                            <div className="text-[10px] text-gray-400 mt-0.5">{exam.organizer}</div>
                          </div>
                          {isSelected && (
                            <div className="w-4 h-4 rounded-full bg-sky-500 text-slate-950 flex items-center justify-center flex-shrink-0">
                              <Check className="w-3 h-3 stroke-[3]" />
                            </div>
                          )}
                        </div>

                        {/* Badges */}
                        <div className="flex flex-wrap gap-1 mt-2">
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#161b22] border border-[#30363d] text-gray-300">
                            {exam.totalQuestions} MCQs · {exam.totalTimeMinutes}m
                          </span>
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#161b22] border border-[#30363d] text-gray-300">
                            ~{exam.avgTimePerQuestionSeconds}s/MCQ
                          </span>
                          {exam.negativeMarkingRate > 0 ? (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-red-500/15 border border-red-500/30 text-red-300">
                              -{exam.negativeMarkingRate} Negative Marking
                            </span>
                          ) : (
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#161b22] border border-[#30363d] text-gray-400">
                              No Negative Marks
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-gray-400 mt-1.5 line-clamp-2 leading-relaxed">
                          {exam.description}
                        </p>
                      </button>
                    );
                  })}
                </div>

                {/* Match Analysis summary card */}
                <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] text-xs text-sky-300 space-y-1">
                  <div className="font-semibold flex items-center space-x-1.5 text-white text-xs">
                    <Target className="w-3.5 h-3.5 text-sky-400" />
                    <span>Engine Match: {selectedBoardObj.shortCode} vs. {selectedExamObj.shortName}</span>
                  </div>
                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    Target test is grounded in <span className="text-sky-300 font-medium">{selectedExamObj.primarySyllabusBasis}</span>. DeltaPrep will flag all textbook divergence topics for your review.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Footer Controls */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-[#30363d] bg-[#0d1117]">
            {activeStep === 1 ? (
              <>
                <div className="text-[11px] text-gray-400">Step 1 of 2</div>
                <button
                  type="button"
                  onClick={() => setActiveStep(2)}
                  className="flex items-center space-x-1 px-3.5 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors cursor-pointer"
                >
                  <span>Select Target Exam</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </>
            ) : (
              <>
                <button
                  type="button"
                  onClick={() => setActiveStep(1)}
                  className="px-2.5 py-1.5 rounded-md text-gray-400 hover:text-white text-xs transition-colors cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="flex items-center space-x-1.5 px-4 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors cursor-pointer shadow-sm"
                >
                  <span>Save Profile & Launch</span>
                  <Zap className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
