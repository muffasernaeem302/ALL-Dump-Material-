import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Calculator,
  Target,
  Award,
  AlertCircle,
  HelpCircle,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { ExamId } from '../types';
import { UNIVERSITY_MERIT_RULES, EXAMS } from '../data';

interface AggregateCalculatorProps {
  initialExam?: ExamId;
  matricPct: number;
  fscPct: number;
  onUpdateAcademics: (matric: number, fsc: number) => void;
}

export const AggregateCalculator: React.FC<AggregateCalculatorProps> = ({
  initialExam = 'nust_net',
  matricPct,
  fscPct,
  onUpdateAcademics,
}) => {
  const [selectedExamId, setSelectedExamId] = useState<ExamId>(initialExam);
  const [inputMatric, setInputMatric] = useState<string>(matricPct.toString());
  const [inputFsc, setInputFsc] = useState<string>(fscPct.toString());

  const currentRule =
    UNIVERSITY_MERIT_RULES.find((u) => u.id === selectedExamId) || UNIVERSITY_MERIT_RULES[0];
  const [selectedProgramIndex, setSelectedProgramIndex] = useState<number>(0);

  // Parse marks
  const parsedMatric = Math.min(100, Math.max(0, parseFloat(inputMatric) || 0));
  const parsedFsc = Math.min(100, Math.max(0, parseFloat(inputFsc) || 0));

  // Default target test score for sensitivity slider
  const defaultTestMarks = Math.round(currentRule.testTotalMarks * 0.75);
  const [simulatedScore, setSimulatedScore] = useState<number>(defaultTestMarks);

  // When university switches, adapt simulated score
  const handleSelectExam = (id: ExamId) => {
    setSelectedExamId(id);
    const newRule = UNIVERSITY_MERIT_RULES.find((u) => u.id === id) || UNIVERSITY_MERIT_RULES[0];
    setSimulatedScore(Math.round(newRule.testTotalMarks * 0.75));
    setSelectedProgramIndex(0);
  };

  // Academic Base calculation
  const matricContribution = parsedMatric * currentRule.matricWeightage;
  const fscContribution = parsedFsc * currentRule.fscWeightage;
  const academicBase = parseFloat((matricContribution + fscContribution).toFixed(2));
  const maxAcademicBase = (currentRule.matricWeightage + currentRule.fscWeightage) * 100;

  // Selected Program
  const currentProgram = currentRule.programs[selectedProgramIndex] || currentRule.programs[0];
  const targetMerit = currentProgram.previousClosingMerit;

  // Required Score Calculation
  const requiredAggregateFromTest = targetMerit - academicBase;
  const requiredTestPct = (requiredAggregateFromTest / (currentRule.testWeightage * 100)) * 100;
  const requiredRawMarks = (requiredTestPct / 100) * currentRule.testTotalMarks;

  const isImpossible = requiredRawMarks > currentRule.testTotalMarks;
  const isAlreadySafe = requiredRawMarks <= 0;

  // Simulated total aggregate with slider
  const simulatedTestPct = (simulatedScore / currentRule.testTotalMarks) * 100;
  const simulatedAggregate = parseFloat(
    (academicBase + (simulatedTestPct * currentRule.testWeightage)).toFixed(2)
  );

  const handleUpdate = (m: number, f: number) => {
    onUpdateAcademics(m, f);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-16 text-[#e6edf3]">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-3">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-md bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
            <Calculator className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold text-[#e6edf3]">
              University Aggregate & Target Score Calculator
            </h1>
            <p className="text-xs text-gray-400">
              Calculate exact minimum entry test marks required to clear Pakistani university closing merits.
            </p>
          </div>
        </div>

        {/* University Selector Pills */}
        <div className="pt-1 flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
          {UNIVERSITY_MERIT_RULES.map((u) => (
            <button
              key={u.id}
              type="button"
              onClick={() => handleSelectExam(u.id)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap transition-colors flex items-center space-x-1.5 cursor-pointer ${
                selectedExamId === u.id
                  ? 'bg-sky-500/20 border border-sky-500/50 text-sky-300 font-bold'
                  : 'bg-[#0d1117] border border-[#30363d] text-gray-300 hover:border-slate-600 hover:bg-slate-800'
              }`}
            >
              <span>{u.universityName}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Inputs + Realtime Required Score Output */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Academic Credentials Form */}
        <div className="lg:col-span-5 space-y-3">
          <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3.5">
            <h2 className="text-[11px] font-mono font-bold uppercase tracking-wider text-gray-400">
              Academic Credentials
            </h2>

            {/* Matric Percentage */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <label className="font-medium text-gray-300">Matric / O-Level %</label>
                <span className="font-mono text-gray-400 text-[11px]">
                  Weight: {(currentRule.matricWeightage * 100).toFixed(0)}%
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="40"
                  max="100"
                  step="0.1"
                  value={inputMatric}
                  onChange={(e) => {
                    setInputMatric(e.target.value);
                    const val = parseFloat(e.target.value) || 0;
                    handleUpdate(val, parsedFsc);
                  }}
                  className="w-full px-3 py-1.5 rounded-md bg-[#0d1117] border border-[#30363d] text-white font-mono text-sm focus:outline-none focus:border-sky-500"
                  placeholder="e.g. 91.5"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-gray-500">
                  %
                </span>
              </div>
              <p className="text-[10px] text-gray-400">
                Adds <strong className="text-gray-200 font-mono">+{matricContribution.toFixed(2)}%</strong> to aggregate
              </p>
            </div>

            {/* FSc Part-1 Percentage */}
            <div className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <label className="font-medium text-gray-300">FSc Part-1 Marks %</label>
                <span className="font-mono text-gray-400 text-[11px]">
                  Weight: {(currentRule.fscWeightage * 100).toFixed(0)}%
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  min="40"
                  max="100"
                  step="0.1"
                  value={inputFsc}
                  onChange={(e) => {
                    setInputFsc(e.target.value);
                    const val = parseFloat(e.target.value) || 0;
                    handleUpdate(parsedMatric, val);
                  }}
                  className="w-full px-3 py-1.5 rounded-md bg-[#0d1117] border border-[#30363d] text-white font-mono text-sm focus:outline-none focus:border-sky-500"
                  placeholder="e.g. 88.0"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono text-gray-500">
                  %
                </span>
              </div>
              <p className="text-[10px] text-gray-400">
                Adds <strong className="text-gray-200 font-mono">+{fscContribution.toFixed(2)}%</strong> to aggregate
              </p>
            </div>

            {/* Academic Base Badge */}
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-400 text-[11px]">Academic Base:</span>
                <span className="font-mono font-bold text-white text-xs">
                  {academicBase.toFixed(2)}%
                  <span className="text-gray-500 font-normal"> / {maxAcademicBase}%</span>
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-sky-500 rounded-full"
                  style={{ width: `${(academicBase / maxAcademicBase) * 100}%` }}
                />
              </div>
            </div>

            {/* Cautionary note */}
            {currentRule.cautionNotice && (
              <div className="p-2.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 flex items-start space-x-2">
                <AlertCircle className="w-3.5 h-3.5 text-amber-400 mt-0.5 flex-shrink-0" />
                <p className="leading-relaxed text-[11px]">{currentRule.cautionNotice}</p>
              </div>
            )}
          </div>

          {/* Official Formula Specs */}
          <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-1.5 text-xs">
            <span className="font-mono text-gray-400 uppercase tracking-wider font-semibold text-[10px]">
              Admission Policy Formula
            </span>
            <code className="block font-mono text-gray-300 bg-[#0d1117] p-2 rounded border border-[#30363d] text-[11px]">
              {currentRule.formulaDescription}
            </code>
            <div className="text-[10px] text-gray-500 flex items-center space-x-1 font-mono">
              <span>Benchmark source:</span>
              <strong className="text-gray-300">{currentRule.closingMeritYear}</strong>
            </div>
          </div>
        </div>

        {/* Right Column: Required Score & Sensitivity Slider */}
        <div className="lg:col-span-7 space-y-3">
          {/* Target Program Selector */}
          <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-mono font-bold uppercase tracking-wider text-gray-400">
                Target Discipline & Closing Merit
              </label>
              <span className="text-[11px] font-mono text-gray-500">2024 Cutoff</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {currentRule.programs.map((prog, pIdx) => {
                const isSelected = selectedProgramIndex === pIdx;
                return (
                  <button
                    key={pIdx}
                    type="button"
                    onClick={() => setSelectedProgramIndex(pIdx)}
                    className={`p-2.5 rounded-md border text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-sky-500/15 border-sky-500/50 text-white'
                        : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600 text-gray-300'
                    }`}
                  >
                    <div className="text-xs font-semibold line-clamp-1">{prog.name}</div>
                    <div className="flex items-center justify-between mt-1 text-[11px]">
                      <span className="text-gray-500 font-mono text-[10px]">Closing:</span>
                      <span className="font-mono font-bold text-sky-400">
                        {prog.previousClosingMerit}%
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* HERO OUTPUT: Required Minimum Score Card */}
          <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-3">
            <div className="flex items-center justify-between text-xs text-gray-400">
              <span className="font-mono uppercase font-bold tracking-wider text-sky-400 flex items-center space-x-1.5">
                <Target className="w-3.5 h-3.5" />
                <span>Required Entry Test Verdict</span>
              </span>
              <span className="font-mono text-gray-400 text-[11px]">
                Target: {targetMerit}%
              </span>
            </div>

            <div className="space-y-1">
              <div className="text-xs text-gray-400">
                To achieve closing merit for <strong className="text-white">{currentProgram.name}</strong>:
              </div>

              {isImpossible ? (
                <div className="p-3 rounded-md bg-red-500/10 border border-red-500/20 text-red-300 space-y-1.5">
                  <div className="flex items-center space-x-2 font-bold text-xs">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
                    <span>Mathematically Out of Reach on Single Attempt</span>
                  </div>
                  <p className="text-[11px] text-gray-300 leading-relaxed">
                    Even with a 100% full score ({currentRule.testTotalMarks}/{currentRule.testTotalMarks}),
                    maximum aggregate would reach{' '}
                    <strong className="text-white">
                      {(academicBase + currentRule.testWeightage * 100).toFixed(2)}%
                    </strong>
                    , which is below {targetMerit}%.
                  </p>
                </div>
              ) : isAlreadySafe ? (
                <div className="p-3 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 space-y-1">
                  <div className="flex items-center space-x-2 font-bold text-xs">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Academic Base Guarantees Merit!</span>
                  </div>
                  <p className="text-[11px] text-gray-300">
                    Your Matric and FSc marks already exceed the previous year closing cutoff.
                  </p>
                </div>
              ) : (
                <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 pt-1">
                  <div>
                    <div className="text-3xl sm:text-4xl font-bold text-white font-mono tracking-tight">
                      {Math.ceil(requiredRawMarks)}{' '}
                      <span className="text-sm sm:text-base text-gray-500 font-normal">
                        / {currentRule.testTotalMarks}
                      </span>
                    </div>
                    <div className="text-xs font-mono text-emerald-400 font-bold mt-0.5">
                      Min {requiredTestPct.toFixed(1)}% Test Percentage Required
                    </div>
                  </div>

                  <div className="text-right sm:max-w-xs">
                    <div className="text-xs text-gray-400 font-mono">
                      Needed from Test: <strong className="text-white">+{requiredAggregateFromTest.toFixed(2)}%</strong>
                    </div>
                    <div className="text-[10px] text-gray-500 mt-0.5">
                      (out of {currentRule.testWeightage * 100}% test share)
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Interactive Sensitivity "What-If" Slider */}
          <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-gray-300 flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-sky-400" />
                <span>"What If I Score X?" Simulator</span>
              </span>
              <span className="font-mono text-xs font-bold text-sky-400">
                {simulatedScore} / {currentRule.testTotalMarks} marks ({simulatedTestPct.toFixed(1)}%)
              </span>
            </div>

            <input
              type="range"
              min="20"
              max={currentRule.testTotalMarks}
              value={simulatedScore}
              onChange={(e) => setSimulatedScore(parseInt(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer h-1.5 bg-[#0d1117] rounded-lg"
            />

            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] flex items-center justify-between">
              <div>
                <div className="text-[10px] text-gray-400 font-mono uppercase">
                  Projected Aggregate
                </div>
                <div className="text-xl sm:text-2xl font-bold text-white font-mono mt-0.5">
                  {simulatedAggregate}%
                </div>
              </div>

              <div className="text-right">
                <div className="text-[10px] text-gray-400 font-mono uppercase">
                  Status for {currentProgram.name}
                </div>
                <div
                  className={`text-xs font-bold font-mono mt-0.5 ${
                    simulatedAggregate >= targetMerit + 0.5
                      ? 'text-emerald-400'
                      : simulatedAggregate >= targetMerit - 0.5
                      ? 'text-amber-400'
                      : 'text-red-400'
                  }`}
                >
                  {simulatedAggregate >= targetMerit + 0.5
                    ? `Safe (+${(simulatedAggregate - targetMerit).toFixed(2)}%)`
                    : simulatedAggregate >= targetMerit - 0.5
                    ? `Borderline (${(simulatedAggregate - targetMerit).toFixed(2)}%)`
                    : `Below Cutoff (${(simulatedAggregate - targetMerit).toFixed(2)}%)`}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
