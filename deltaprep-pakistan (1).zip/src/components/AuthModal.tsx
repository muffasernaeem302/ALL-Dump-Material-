import React from 'react';
import { X, CheckCircle2, Flame, Award, Cloud, RefreshCw, LogIn, LogOut, ShieldCheck } from 'lucide-react';
import { AuthUser } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  authUser: AuthUser;
  onUpdateAuthUser: (updated: AuthUser) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  authUser,
  onUpdateAuthUser,
}) => {
  if (!isOpen) return null;

  const handleToggleLogin = () => {
    if (authUser.isAuthenticated) {
      onUpdateAuthUser({
        ...authUser,
        isAuthenticated: false,
      });
    } else {
      onUpdateAuthUser({
        ...authUser,
        isAuthenticated: true,
        isSyncing: true,
      });
      setTimeout(() => {
        onUpdateAuthUser({
          ...authUser,
          isAuthenticated: true,
          isSyncing: false,
          lastSyncedAt: 'Just now',
        });
      }, 1000);
    }
  };

  const handleManualSync = () => {
    onUpdateAuthUser({ ...authUser, isSyncing: true });
    setTimeout(() => {
      onUpdateAuthUser({
        ...authUser,
        isSyncing: false,
        lastSyncedAt: 'Just now',
      });
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
      <div
        id="auth-modal"
        className="w-full max-w-md bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[#30363d] bg-[#0d1117]">
          <div className="flex items-center space-x-2">
            <div className="h-6 w-6 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">
              Δ
            </div>
            <h3 className="text-sm font-semibold text-[#e6edf3]">
              DeltaPrep Cloud Account
            </h3>
          </div>
          <button
            id="close-auth-modal"
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-5">
          {authUser.isAuthenticated ? (
            <>
              {/* Profile Card */}
              <div className="flex items-center space-x-3.5 p-3.5 rounded-lg bg-[#0d1117] border border-[#30363d]">
                <div className="relative">
                  <div className="h-12 w-12 rounded-full bg-linear-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white font-bold text-base shadow-sm">
                    {authUser.name
                      .split(' ')
                      .map((n) => n[0])
                      .join('')
                      .slice(0, 2)}
                  </div>
                  <div className="absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full bg-emerald-500 border-2 border-[#0d1117] flex items-center justify-center">
                    <CheckCircle2 className="w-2.5 h-2.5 text-white" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2">
                    <p className="text-sm font-semibold text-[#e6edf3] truncate">
                      {authUser.name}
                    </p>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
                      Google OAuth
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 truncate">{authUser.email}</p>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
                  <div className="flex items-center space-x-1.5 text-amber-400 mb-1">
                    <Flame className="w-4 h-4 fill-amber-400/20" />
                    <span className="text-xs font-semibold">Active Streak</span>
                  </div>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-xl font-bold font-mono text-[#e6edf3]">
                      {authUser.streakDays}
                    </span>
                    <span className="text-xs text-gray-400">days 🔥</span>
                  </div>
                  <p className="text-[10px] text-gray-500 mt-0.5">Keep daily continuity</p>
                </div>

                <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
                  <div className="flex items-center space-x-1.5 text-sky-400 mb-1">
                    <Award className="w-4 h-4" />
                    <span className="text-xs font-semibold">Prep XP</span>
                  </div>
                  <div className="flex items-baseline space-x-1">
                    <span className="text-xl font-bold font-mono text-[#e6edf3]">
                      {authUser.xp.toLocaleString()}
                    </span>
                    <span className="text-xs text-sky-400 font-mono">XP</span>
                  </div>
                  <p className="text-[10px] text-gray-500 mt-0.5">Level 4 FSc Aspirant</p>
                </div>
              </div>

              {/* Sync Status */}
              <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <Cloud className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-xs font-medium text-[#e6edf3]">Google Cloud Sync</span>
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    </div>
                    <p className="text-[10px] text-gray-400">
                      Synced {authUser.lastSyncedAt}
                    </p>
                  </div>
                </div>
                <button
                  onClick={handleManualSync}
                  disabled={authUser.isSyncing}
                  className="flex items-center space-x-1 px-2.5 py-1 text-xs text-gray-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors disabled:opacity-50"
                >
                  <RefreshCw
                    className={`w-3 h-3 ${authUser.isSyncing ? 'animate-spin text-sky-400' : ''}`}
                  />
                  <span>{authUser.isSyncing ? 'Syncing...' : 'Sync Now'}</span>
                </button>
              </div>

              {/* Sign Out Action */}
              <button
                id="btn-sign-out"
                onClick={handleToggleLogin}
                className="w-full flex items-center justify-center space-x-2 py-2 px-3 text-xs font-medium text-red-400 hover:text-red-300 hover:bg-red-500/10 border border-red-500/20 rounded-md transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Disconnect Google Account</span>
              </button>
            </>
          ) : (
            <div className="text-center py-4 space-y-4">
              <div className="h-12 w-12 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-semibold text-[#e6edf3]">
                  Sign In to DeltaPrep Cloud
                </h4>
                <p className="text-xs text-gray-400 max-w-xs mx-auto">
                  Sync your syllabus gap progress, bookmarked formulas, practice analytics, and streak count across all devices.
                </p>
              </div>

              <button
                id="btn-sign-in-google"
                onClick={handleToggleLogin}
                className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 rounded-md bg-white hover:bg-gray-100 text-gray-900 font-semibold text-xs transition-colors shadow-sm"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
