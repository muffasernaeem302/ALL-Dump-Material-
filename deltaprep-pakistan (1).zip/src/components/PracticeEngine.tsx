import React, { useState, useEffect } from 'react';
import {
  Clock,
  AlertTriangle,
  ShieldCheck,
  Flag,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Sparkles,
  Award,
  Zap,
  Flame,
  HelpCircle,
  Filter,
  Bookmark,
  Share2,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import {
  ExamId,
  BoardId,
  MCQQuestion,
  PracticeMode,
  Subject,
} from '../types';
import { MOCK_MCQS, EXAMS, UNIVERSITY_MERIT_RULES } from '../data';
import { MathView } from './MathView';
import { QuestionLoader } from './questions/QuestionLoader';

interface PracticeEngineProps {
  targetExam: ExamId;
  homeBoard: BoardId;
  matricPct: number;
  fscPct: number;
  onReturnToDashboard: () => void;
  onAskStudyBuddy?: (questionContext: string) => void;
  onOpenTopicById?: (topicId: string) => void;
}

export const PracticeEngine: React.FC<PracticeEngineProps> = ({
  targetExam,
  homeBoard,
  matricPct,
  fscPct,
  onReturnToDashboard,
  onAskStudyBuddy,
  onOpenTopicById,
}) => {
  // Practice Modes: Full Mock Paper | Chapter Practice | Short Questions & Board Mode
  const [practiceMode, setPracticeMode] = useState<PracticeMode>('full_mock');
  const [selectedSubjectFilter, setSelectedSubjectFilter] = useState<string>('All');
  const [instantFeedback, setInstantFeedback] = useState<boolean>(false);

  // Active exam configuration
  const [examMode, setExamMode] = useState<ExamId>(targetExam);
  const activeExam = EXAMS.find((e) => e.id === examMode) || EXAMS[0];

  // Simulator state
  const [testStarted, setTestStarted] = useState<boolean>(false);
  const [testCompleted, setTestCompleted] = useState<boolean>(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [showQuestionBankRepo, setShowQuestionBankRepo] = useState<boolean>(false);
  const [submissionResult, setSubmissionResult] = useState<{
    xpAwarded: number;
    newlyUnlockedLevels: string[];
    recordId: string;
  } | null>(null);
  const [isSubmittingRecord, setIsSubmittingRecord] = useState<boolean>(false);

  // User responses
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [skippedQuestions, setSkippedQuestions] = useState<Record<number, boolean>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Record<number, boolean>>({});
  const [questionTimeSpent, setQuestionTimeSpent] = useState<Record<number, number>>({});

  // Active timers
  const [totalSeconds, setTotalSeconds] = useState<number>(0);
  const [currentQSeconds, setCurrentQSeconds] = useState<number>(0);

  // Bookmarks persistence
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('deltaprep_bookmarked_ids');
      return stored ? JSON.parse(stored) : ['q-1', 'q-4', 'q-9'];
    } catch {
      return ['q-1', 'q-4', 'q-9'];
    }
  });

  const handleToggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => {
      const isBookmarked = prev.includes(id);
      const updated = isBookmarked ? prev.filter((bId) => bId !== id) : [...prev, id];
      try {
        localStorage.setItem('deltaprep_bookmarked_ids', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  // Filter questions based on mode and subject
  const availableQuestions = React.useMemo(() => {
    let list = MOCK_MCQS;
    if (practiceMode === 'chapter_practice' && selectedSubjectFilter !== 'All') {
      list = list.filter((q) => q.subject === selectedSubjectFilter);
    } else if (practiceMode === 'short_questions') {
      // Prioritize high-delta & conceptual questions
      list = list.filter((q) => q.deltaTagged || q.difficulty === 'Hard' || q.difficulty === 'Trick');
    }
    return list.length > 0 ? list : MOCK_MCQS;
  }, [practiceMode, selectedSubjectFilter]);

  const questions: MCQQuestion[] = availableQuestions;
  const currentQuestion = questions[currentIndex] || questions[0];

  const targetPaceSeconds = activeExam.id === 'fast_nu' ? 40 : activeExam.id === 'nust_net' ? 50 : 60;
  const negativeRate = activeExam.negativeMarkingRate;

  // Timer loop
  useEffect(() => {
    if (!testStarted || testCompleted) return;

    const interval = setInterval(() => {
      setTotalSeconds((prev) => prev + 1);
      setCurrentQSeconds((prev) => {
        const next = prev + 1;
        setQuestionTimeSpent((old) => ({
          ...old,
          [currentIndex]: (old[currentIndex] || 0) + 1,
        }));
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [testStarted, testCompleted, currentIndex]);

  const navigateToQuestion = (index: number) => {
    setCurrentIndex(index);
    setCurrentQSeconds(questionTimeSpent[index] || 0);
  };

  const handleSelectOption = (optionIndex: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: optionIndex }));
    if (skippedQuestions[currentIndex]) {
      const nextSkipped = { ...skippedQuestions };
      delete nextSkipped[currentIndex];
      setSkippedQuestions(nextSkipped);
    }
  };

  const handleSkipQuestion = () => {
    setSkippedQuestions((prev) => ({ ...prev, [currentIndex]: true }));
    if (selectedAnswers[currentIndex] !== undefined) {
      const nextAnswers = { ...selectedAnswers };
      delete nextAnswers[currentIndex];
      setSelectedAnswers(nextAnswers);
    }
    if (currentIndex < questions.length - 1) {
      navigateToQuestion(currentIndex + 1);
    }
  };

  const handleToggleFlag = () => {
    setFlaggedQuestions((prev) => ({
      ...prev,
      [currentIndex]: !prev[currentIndex],
    }));
  };

  const handleFinishTest = async () => {
    setTestCompleted(true);
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    setIsSubmittingRecord(true);
    try {
      const formattedAnswers = questions.map((q, idx) => {
        const selectedOptIdx = selectedAnswers[idx];
        const isSkipped = !!skippedQuestions[idx] || selectedOptIdx === undefined;
        const selectedOptionText = !isSkipped && selectedOptIdx !== undefined ? q.options[selectedOptIdx] : null;

        return {
          questionId: q.id,
          question: q.question,
          options: q.options,
          selectedAnswer: selectedOptionText,
          selectedOptionIndex: isSkipped ? null : selectedOptIdx,
          correctAnswer: q.options[q.correctAnswer] || '',
          correctIndex: q.correctAnswer,
          isSkipped,
          timeTaken: questionTimeSpent[idx] || 0,
          explanation: q.explanation || '',
          boardOrigin: q.boardOrigin || 'Exam Standard',
          topicName: q.topicName || q.subject || 'General',
        };
      });

      const testTypeMap: Record<string, string> = {
        full_mock: 'MOCK',
        chapter_practice: 'SUBJECT',
        short_questions: 'PRACTICE',
      };

      const res = await fetch('/api/records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          testId: `test_${Date.now()}`,
          testName: `${activeExam.name} - ${practiceMode.replace('_', ' ').toUpperCase()}`,
          testType: testTypeMap[practiceMode] || 'PRACTICE',
          subject: selectedSubjectFilter !== 'All' ? selectedSubjectFilter : 'All Subjects',
          answers: formattedAnswers,
          timeTaken: totalSeconds,
          level: 1,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setSubmissionResult({
          xpAwarded: data.xpAwarded || 0,
          newlyUnlockedLevels: data.newlyUnlockedLevels || [],
          recordId: data.record?.id || '',
        });
      }
    } catch (err) {
      console.error('Failed to submit test record to backend:', err);
    } finally {
      setIsSubmittingRecord(false);
    }
  };

  const handleRestart = () => {
    setTestStarted(false);
    setTestCompleted(false);
    setSubmissionResult(null);
    setCurrentIndex(0);
    setSelectedAnswers({});
    setSkippedQuestions({});
    setFlaggedQuestions({});
    setQuestionTimeSpent({});
    setTotalSeconds(0);
    setCurrentQSeconds(0);
  };

  // Performance calculations
  const totalQuestions = questions.length;
  let correctCount = 0;
  let incorrectCount = 0;
  let skippedCount = 0;

  questions.forEach((q, idx) => {
    const ans = selectedAnswers[idx];
    if (ans === undefined || skippedQuestions[idx]) {
      skippedCount++;
    } else if (ans === q.correctAnswer) {
      correctCount++;
    } else {
      incorrectCount++;
    }
  });

  const rawScore = correctCount * 1 - incorrectCount * negativeRate;
  const maxPossibleScore = totalQuestions;
  const accuracyPct =
    correctCount + incorrectCount > 0
      ? Math.round((correctCount / (correctCount + incorrectCount)) * 100)
      : 0;
  const penaltyPointsAvoided = parseFloat((skippedCount * negativeRate).toFixed(2));
  const avgTimePerQuestion =
    totalQuestions > 0 ? Math.round(totalSeconds / Math.max(1, correctCount + incorrectCount + skippedCount)) : 0;

  const isPacingWarning = currentQSeconds > targetPaceSeconds + 15;
  const isPacingOver = currentQSeconds > targetPaceSeconds;
  const isAnswered = selectedAnswers[currentIndex] !== undefined;
  const isSkipped = !!skippedQuestions[currentIndex];
  const isFlagged = !!flaggedQuestions[currentIndex];

  // Merit rules for projected impact
  const meritRule = UNIVERSITY_MERIT_RULES.find((u) => u.id === activeExam.id) || UNIVERSITY_MERIT_RULES[0];
  const matricContrib = matricPct * meritRule.matricWeightage;
  const fscContrib = fscPct * meritRule.fscWeightage;
  const simulatedTestPct = Math.max(0, (rawScore / maxPossibleScore) * 100);
  const testContrib = simulatedTestPct * meritRule.testWeightage;
  const projectedAggregate = parseFloat((matricContrib + fscContrib + testContrib).toFixed(2));

  // Pre-test Setup Screen
  if (!testStarted) {
    return (
      <div className="space-y-4">
        {/* Header Banner */}
        <div className="rounded-lg border border-[#30363d] bg-[#161b22] p-4 sm:p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center space-x-2">
                <span className="h-6 w-6 rounded bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                  ⚡
                </span>
                <h2 className="text-base sm:text-lg font-bold text-[#e6edf3]">
                  High-Yield Practice & Adaptive Mock Engine
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/30">
                  {questions.length} Questions Loaded
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1 max-w-2xl">
                Simulate real negative marking penalties (-0.25 on FAST NU), pacing meters, and time-sink detection.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setShowQuestionBankRepo(!showQuestionBankRepo)}
              className="px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 text-sky-400 hover:text-sky-300 text-xs font-semibold border border-[#30363d] transition-colors cursor-pointer shrink-0"
            >
              {showQuestionBankRepo ? '← Back to Simulator Setup' : 'Explore Question Bank (Lazy Loader) →'}
            </button>
          </div>

          {showQuestionBankRepo ? (
            <div className="mt-4 pt-4 border-t border-[#30363d]">
              <QuestionLoader />
            </div>
          ) : (
            <div>
              {/* Mode Selector Tabs */}
              <div className="mt-4 pt-4 border-t border-[#30363d] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-2 overflow-x-auto pb-1 sm:pb-0">
              <button
                id="mode-full-mock"
                onClick={() => setPracticeMode('full_mock')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  practiceMode === 'full_mock'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                    : 'text-gray-400 hover:text-white bg-[#0d1117] border border-[#30363d]'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>Full Mock Paper</span>
              </button>

              <button
                id="mode-chapter-practice"
                onClick={() => setPracticeMode('chapter_practice')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  practiceMode === 'chapter_practice'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                    : 'text-gray-400 hover:text-white bg-[#0d1117] border border-[#30363d]'
                }`}
              >
                <Filter className="w-3.5 h-3.5 text-sky-400" />
                <span>Chapter Practice</span>
              </button>

              <button
                id="mode-short-questions"
                onClick={() => setPracticeMode('short_questions')}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors flex items-center space-x-1.5 whitespace-nowrap cursor-pointer ${
                  practiceMode === 'short_questions'
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                    : 'text-gray-400 hover:text-white bg-[#0d1117] border border-[#30363d]'
                }`}
              >
                <Zap className="w-3.5 h-3.5 text-emerald-400" />
                <span>Short Questions & Board Delta</span>
              </button>
            </div>

            {/* Instant feedback toggle for chapter mode */}
            {practiceMode !== 'full_mock' && (
              <div className="flex items-center space-x-2 text-xs">
                <span className="text-gray-400">Instant Solution Mode:</span>
                <button
                  onClick={() => setInstantFeedback(!instantFeedback)}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono border ${
                    instantFeedback
                      ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300 font-bold'
                      : 'bg-[#0d1117] border-[#30363d] text-gray-500'
                  }`}
                >
                  {instantFeedback ? 'ENABLED' : 'DISABLED'}
                </button>
              </div>
            )}
          </div>

          {/* Chapter Practice Subject Filters */}
          {practiceMode === 'chapter_practice' && (
            <div className="mt-3 flex items-center space-x-1.5 overflow-x-auto text-[11px]">
              <span className="text-gray-500 font-mono">Subject:</span>
              {['All', 'Mathematics', 'Physics', 'Chemistry', 'Biology'].map((subj) => (
                <button
                  key={subj}
                  onClick={() => setSelectedSubjectFilter(subj)}
                  className={`px-2 py-0.5 rounded font-mono transition-colors ${
                    selectedSubjectFilter === subj
                      ? 'bg-slate-700 text-sky-300 font-semibold border border-slate-600'
                      : 'text-gray-400 hover:text-gray-200 bg-[#0d1117] border border-[#30363d]'
                  }`}
                >
                  {subj}
                </button>
              ))}
            </div>
          )}
            </div>
          )}
        </div>

        {!showQuestionBankRepo && (
          <div className="rounded-lg border border-[#30363d] bg-[#161b22] p-4 sm:p-5 space-y-4">
          <div>
            <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
              Select Exam Pacing & Penalty Profile:
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 mt-2">
              <button
                type="button"
                onClick={() => setExamMode('fast_nu')}
                className={`p-3 rounded-md border text-left transition-colors cursor-pointer ${
                  examMode === 'fast_nu'
                    ? 'bg-amber-500/10 border-amber-500/40 text-white'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-bold text-white flex items-center justify-between">
                  <span>FAST NU-Test</span>
                  <span className="text-[10px] font-mono text-red-400 font-bold">-0.25 Penalty</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1">40s / Question Pacing</div>
                <div className="text-[10px] text-amber-300 mt-0.5 font-medium">
                  Negative marking risk drill
                </div>
              </button>

              <button
                type="button"
                onClick={() => setExamMode('nust_net')}
                className={`p-3 rounded-md border text-left transition-colors cursor-pointer ${
                  examMode === 'nust_net'
                    ? 'bg-sky-500/10 border-sky-500/40 text-white'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-bold text-white flex items-center justify-between">
                  <span>NUST NET</span>
                  <span className="text-[10px] font-mono text-emerald-400">0 Penalty</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1">50s / Question Pacing</div>
                <div className="text-[10px] text-sky-300 mt-0.5 font-medium">
                  Speed sprint drill
                </div>
              </button>

              <button
                type="button"
                onClick={() => setExamMode('mdcat')}
                className={`p-3 rounded-md border text-left transition-colors cursor-pointer ${
                  examMode === 'mdcat'
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-bold text-white flex items-center justify-between">
                  <span>MDCAT PMDC</span>
                  <span className="text-[10px] font-mono text-emerald-400">0 Penalty</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1">60s / Question Pacing</div>
                <div className="text-[10px] text-emerald-300 mt-0.5 font-medium">
                  High-accuracy biology focus
                </div>
              </button>
            </div>
          </div>

          {/* Rules & Pacing Guidance */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-1">
              <div className="font-bold text-[#e6edf3] flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Pacing Meter & Time-Sink Alerts</span>
              </div>
              <p className="text-gray-400 text-[11px]">
                Turns red if you spend &gt;45s on a single MCQ. Pinpoints exact traps where students lose valuable minutes.
              </p>
            </div>

            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-1">
              <div className="font-bold text-[#e6edf3] flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Penalty Prevention Tracker</span>
              </div>
              <p className="text-gray-400 text-[11px]">
                Use the dedicated <strong>&quot;Skip to Avoid Penalty&quot;</strong> button when uncertain on FAST NU-Test to save fractional aggregate marks.
              </p>
            </div>
          </div>

          {/* Start Test CTA */}
          <div className="pt-3 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-[#30363d]">
            <div className="text-xs text-gray-400 font-mono">
              {questions.length} Questions · Target Pace: {targetPaceSeconds}s/MCQ
            </div>

            <button
              type="button"
              id="start-mock-test-btn"
              onClick={() => {
                setTestStarted(true);
                setCurrentQSeconds(0);
                setTotalSeconds(0);
              }}
              className="w-full sm:w-auto px-5 py-2 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm"
            >
              <Flame className="w-3.5 h-3.5 text-amber-300" />
              <span>
                Start {practiceMode === 'full_mock' ? 'Timed Mock Paper' : 'Practice Session'}
              </span>
            </button>
          </div>
        </div>
      )}
      </div>
    );
  }

  // Active Quiz View
  if (!testCompleted) {
    return (
      <div className="space-y-4">
        {/* Top Sticky Test Header */}
        <div className="p-3 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-wrap items-center justify-between gap-3 sticky top-14 z-30 shadow-md">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20">
              Q{currentIndex + 1} of {questions.length}
            </span>
            <span className="text-xs text-gray-300 font-medium">
              {activeExam.shortName} Simulation
            </span>
            {activeExam.negativeMarkingRate > 0 && (
              <span className="text-[10px] font-mono text-red-400 bg-red-500/10 px-1.5 py-0.5 rounded border border-red-500/20 font-bold">
                -0.25 Penalty Active
              </span>
            )}
          </div>

          {/* Question Pacing Meter */}
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-[10px] uppercase font-mono tracking-wider text-gray-400">
                Time on MCQ
              </div>
              <div
                className={`font-mono text-xs font-bold flex items-center justify-end space-x-1 ${
                  isPacingWarning
                    ? 'text-red-400 animate-pulse'
                    : isPacingOver
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                <Clock className="w-3 h-3" />
                <span>{currentQSeconds}s</span>
                <span className="text-[10px] text-gray-500 font-normal">
                  / {targetPaceSeconds}s target
                </span>
              </div>
            </div>

            {/* Total elapsed */}
            <div className="border-l border-[#30363d] pl-3 text-right hidden sm:block">
              <div className="text-[10px] uppercase font-mono tracking-wider text-gray-400">
                Total Elapsed
              </div>
              <div className="font-mono text-xs font-semibold text-gray-200">
                {Math.floor(totalSeconds / 60)}m {totalSeconds % 60}s
              </div>
            </div>

            <button
              type="button"
              id="finish-simulation-btn"
              onClick={handleFinishTest}
              className="px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 text-xs font-medium text-gray-300 border border-[#30363d] transition-colors cursor-pointer"
            >
              Finish Test
            </button>
          </div>
        </div>

        {/* Pacing Danger Warning Toast if user spends > 55s */}
        {isPacingWarning && (
          <div className="p-2.5 rounded-md bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center justify-between animate-in fade-in">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
              <span>
                <strong>Time-Sink Alert:</strong> Over {currentQSeconds}s on this MCQ! Spending &gt;60s hurts subsequent questions.
              </span>
            </div>
            <button
              type="button"
              onClick={handleSkipQuestion}
              className="ml-2 px-2.5 py-1 rounded bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] whitespace-nowrap cursor-pointer"
            >
              Skip to Save Time
            </button>
          </div>
        )}

        {/* Question Canvas Card */}
        <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-4">
          {/* Question Meta tags */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-[#0d1117] text-gray-300 border border-[#30363d]">
                {currentQuestion.subject}
              </span>
              <span className="text-xs text-gray-400">{currentQuestion.topicName}</span>
              {currentQuestion.deltaTagged && (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  Δ Delta Question
                </span>
              )}
            </div>

            <div className="flex items-center space-x-2">
              {/* Instant Ask Study Buddy Shortcut */}
              {onAskStudyBuddy && (
                <button
                  onClick={() =>
                    onAskStudyBuddy(
                      `Please explain this exam MCQ: "${currentQuestion.question}" Options: ${currentQuestion.options.join(', ')}`
                    )
                  }
                  className="flex items-center space-x-1 px-2 py-1 rounded text-xs text-sky-400 hover:text-sky-300 bg-[#0d1117] border border-[#30363d] hover:border-sky-500/40 transition-colors"
                  title="Open AI Study Buddy for this question"
                >
                  <Sparkles className="w-3 h-3" />
                  <span>Ask AI Buddy</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => handleToggleBookmark(currentQuestion.id)}
                className={`flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                  bookmarkedIds.includes(currentQuestion.id)
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-gray-400 hover:text-gray-200 bg-[#0d1117] border border-[#30363d]'
                }`}
                title="Save to Bookmarks for spaced repetition"
              >
                <Bookmark className={`w-3.5 h-3.5 ${bookmarkedIds.includes(currentQuestion.id) ? 'fill-amber-400 text-amber-400' : ''}`} />
                <span>{bookmarkedIds.includes(currentQuestion.id) ? 'Saved' : 'Bookmark'}</span>
              </button>

              <button
                type="button"
                onClick={handleToggleFlag}
                className={`flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                  isFlagged
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-gray-400 hover:text-gray-200 bg-[#0d1117] border border-[#30363d]'
                }`}
              >
                <Flag className={`w-3.5 h-3.5 ${isFlagged ? 'fill-amber-400' : ''}`} />
                <span>{isFlagged ? 'Flagged' : 'Flag'}</span>
              </button>
            </div>
          </div>

          {/* Question Text with KaTeX */}
          <div className="space-y-1.5">
            <div className="text-[10px] font-mono text-gray-500 flex items-center space-x-1.5">
              <span>Syllabus Source:</span>
              <span className="text-gray-400">{currentQuestion.boardOrigin}</span>
            </div>
            <div className="text-sm sm:text-base font-semibold text-[#e6edf3] leading-relaxed">
              <MathView math={currentQuestion.question} />
            </div>
          </div>

          {/* Options Grid */}
          <div className="space-y-2 pt-2">
            {currentQuestion.options.map((opt, optIdx) => {
              const isSelected = selectedAnswers[currentIndex] === optIdx;
              const optionLabel = String.fromCharCode(65 + optIdx); // A, B, C, D

              let borderClass = 'border-[#30363d] bg-[#0d1117] hover:border-slate-600 text-gray-200';
              if (isSelected) {
                borderClass = 'border-sky-500 bg-sky-950/30 text-white font-medium shadow-xs';
              }

              // Instant Feedback display in chapter practice mode
              if (instantFeedback && isAnswered) {
                if (optIdx === currentQuestion.correctAnswer) {
                  borderClass = 'border-emerald-500 bg-emerald-950/30 text-emerald-200 font-bold';
                } else if (isSelected && optIdx !== currentQuestion.correctAnswer) {
                  borderClass = 'border-red-500 bg-red-950/30 text-red-200';
                }
              }

              return (
                <button
                  key={optIdx}
                  type="button"
                  id={`option-${optIdx}`}
                  onClick={() => handleSelectOption(optIdx)}
                  className={`w-full p-3 rounded-md border text-left flex items-start space-x-3 transition-colors cursor-pointer ${borderClass}`}
                >
                  <span
                    className={`h-5 w-5 rounded flex items-center justify-center text-xs font-mono font-bold shrink-0 mt-0.5 ${
                      isSelected
                        ? 'bg-sky-500 text-white'
                        : 'bg-slate-800 text-gray-400 border border-slate-700'
                    }`}
                  >
                    {optionLabel}
                  </span>
                  <div className="text-xs sm:text-sm flex-1 pt-0.5">
                    <MathView math={opt} />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Instant feedback explanation banner if turned on */}
          {instantFeedback && isAnswered && (
            <div className="mt-3 p-3 rounded-md bg-[#0d1117] border border-[#30363d] text-xs space-y-1.5">
              <div className="flex items-center space-x-1.5 text-emerald-400 font-semibold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Correct Answer: Option {String.fromCharCode(65 + currentQuestion.correctAnswer)}</span>
              </div>
              <div className="text-gray-300 text-[11px] leading-relaxed">
                <MathView math={currentQuestion.explanation} />
              </div>
            </div>
          )}

          {/* Action Toolbar: Skip to Avoid Penalty, Prev, Next */}
          <div className="pt-3 border-t border-[#30363d] flex flex-wrap items-center justify-between gap-2.5">
            <button
              type="button"
              id="skip-to-avoid-penalty-btn"
              onClick={handleSkipQuestion}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-md text-xs font-semibold border transition-colors cursor-pointer ${
                isSkipped
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-[#0d1117] border-[#30363d] text-gray-300 hover:text-white hover:border-amber-500/40'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>Skip to Avoid Penalty</span>
              {activeExam.negativeMarkingRate > 0 && (
                <span className="text-[10px] font-mono text-emerald-400 ml-1">
                  (Protects 0.25 pts)
                </span>
              )}
            </button>

            <div className="flex items-center space-x-2 ml-auto">
              <button
                type="button"
                disabled={currentIndex === 0}
                onClick={() => navigateToQuestion(currentIndex - 1)}
                className="px-3 py-1.5 rounded-md border border-[#30363d] bg-[#0d1117] text-gray-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed text-xs font-medium flex items-center space-x-1 cursor-pointer"
              >
                <ArrowLeft className="w-3 h-3" />
                <span>Prev</span>
              </button>

              {currentIndex < questions.length - 1 ? (
                <button
                  type="button"
                  id="next-question-btn"
                  onClick={() => navigateToQuestion(currentIndex + 1)}
                  className="px-4 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                >
                  <span>Next</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleFinishTest}
                  className="px-4 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                >
                  <span>Submit Paper</span>
                  <CheckCircle2 className="w-3 h-3" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Question Navigation Matrix */}
        <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
              Question Navigator ({questions.length} Total)
            </span>
            <div className="flex items-center space-x-3 text-[10px] font-mono">
              <span className="flex items-center space-x-1 text-sky-400">
                <span className="h-2 w-2 rounded-full bg-sky-500" />
                <span>Answered</span>
              </span>
              <span className="flex items-center space-x-1 text-amber-400">
                <span className="h-2 w-2 rounded-full bg-amber-500" />
                <span>Skipped</span>
              </span>
              <span className="flex items-center space-x-1 text-purple-400">
                <span className="h-2 w-2 rounded-full bg-purple-500" />
                <span>Flagged</span>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            {questions.map((_, idx) => {
              const isCurrent = idx === currentIndex;
              const ans = selectedAnswers[idx];
              const sk = skippedQuestions[idx];
              const fl = flaggedQuestions[idx];

              let bg = 'bg-[#0d1117] text-gray-400 border-[#30363d]';
              if (isCurrent) {
                bg = 'ring-2 ring-sky-400 bg-sky-950 text-white border-sky-400';
              } else if (ans !== undefined) {
                bg = 'bg-sky-900/40 text-sky-300 border-sky-600/50';
              } else if (sk) {
                bg = 'bg-amber-950/40 text-amber-300 border-amber-600/40';
              } else if (fl) {
                bg = 'bg-purple-950/40 text-purple-300 border-purple-600/40';
              }

              return (
                <button
                  key={idx}
                  onClick={() => navigateToQuestion(idx)}
                  className={`h-7 w-7 rounded font-mono text-xs border font-semibold flex items-center justify-center transition-colors cursor-pointer ${bg}`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Post-Test Detailed Analytics & Solutions View
  return (
    <div className="space-y-4">
      {/* Analytics Summary Banner */}
      <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#30363d] pb-4">
          <div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
              Mock Test Completed
            </span>
            <h2 className="text-lg font-bold text-[#e6edf3] mt-1">
              Performance & Penalty Diagnostics ({activeExam.shortName})
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Detailed time-per-question analysis and projected university aggregate impact.
            </p>
          </div>

          <button
            type="button"
            id="restart-test-btn"
            onClick={handleRestart}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 text-xs font-semibold text-gray-200 border border-[#30363d] transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
            <span>Retake Test</span>
          </button>
        </div>

        {/* 4 Primary KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d]">
            <span className="text-[10px] uppercase font-mono text-gray-400">Raw Score</span>
            <div className="text-xl font-bold font-mono text-[#e6edf3] mt-0.5">
              {rawScore} / {maxPossibleScore}
            </div>
            <span className="text-[10px] text-gray-500 font-mono">
              {correctCount} Correct · {incorrectCount} Wrong
            </span>
          </div>

          <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d]">
            <span className="text-[10px] uppercase font-mono text-gray-400">Accuracy %</span>
            <div
              className={`text-xl font-bold font-mono mt-0.5 ${
                accuracyPct >= 75 ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {accuracyPct}%
            </div>
            <span className="text-[10px] text-gray-500 font-mono">
              Excludes deliberate skips
            </span>
          </div>

          <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d]">
            <span className="text-[10px] uppercase font-mono text-emerald-400 flex items-center space-x-1">
              <ShieldCheck className="w-3 h-3" />
              <span>Penalty Avoidance</span>
            </span>
            <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
              +{penaltyPointsAvoided} pts
            </div>
            <span className="text-[10px] text-gray-400 font-mono">
              {skippedCount} MCQs skipped safely
            </span>
          </div>

          <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d]">
            <span className="text-[10px] uppercase font-mono text-sky-400">Projected Aggregate</span>
            <div className="text-xl font-bold font-mono text-sky-400 mt-0.5">
              {projectedAggregate}%
            </div>
            <span className="text-[10px] text-gray-400 font-mono">
              Based on {matricPct}% Matric / {fscPct}% FSc
            </span>
          </div>
        </div>

        {/* Time Spent Breakdown */}
        <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
          <div className="flex items-center space-x-2 text-gray-300">
            <Clock className="w-4 h-4 text-sky-400" />
            <span>Average Pace: <strong>{avgTimePerQuestion}s</strong> / Question</span>
          </div>
          <div className="text-gray-400">
            Total Time: {Math.floor(totalSeconds / 60)}m {totalSeconds % 60}s
          </div>
        </div>

        {/* Backend Database Record & XP Award Banner */}
        {submissionResult && (
          <div className="p-3.5 rounded-md bg-sky-950/30 border border-sky-600/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2.5">
              <span className="p-1.5 rounded-full bg-emerald-500/20 text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
              </span>
              <div>
                <div className="font-semibold text-[#e6edf3] flex items-center space-x-2">
                  <span>Test Record Permanently Logged to Database</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-900/60 text-sky-200">
                    ID: {submissionResult.recordId}
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 mt-0.5 flex items-center space-x-3">
                  <span className="text-amber-300 font-mono flex items-center space-x-1">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>+{submissionResult.xpAwarded} XP Earned</span>
                  </span>
                  {submissionResult.newlyUnlockedLevels.length > 0 && (
                    <span className="text-emerald-400 font-semibold font-mono">
                      🎉 {submissionResult.newlyUnlockedLevels.length} Level Unlocked in Topic Mastery!
                    </span>
                  )}
                </div>
              </div>
            </div>

            <span className="text-[11px] text-gray-400 font-mono">
              Available in Records Archive
            </span>
          </div>
        )}
      </div>

      {/* Solutions & Explanations List with KaTeX */}
      <div className="rounded-lg border border-[#30363d] bg-[#161b22] p-4 sm:p-5 space-y-4">
        <h3 className="text-sm font-bold text-[#e6edf3] flex items-center space-x-2">
          <span>Question-by-Question Solutions & LaTeX Derivations</span>
        </h3>

        <div className="space-y-3">
          {questions.map((q, idx) => {
            const userAns = selectedAnswers[idx];
            const wasSkipped = skippedQuestions[idx] || userAns === undefined;
            const isCorrect = userAns === q.correctAnswer;
            const timeSpent = questionTimeSpent[idx] || 0;

            return (
              <div
                key={q.id}
                className={`p-4 rounded-lg border text-xs space-y-2.5 ${
                  wasSkipped
                    ? 'bg-[#0d1117] border-amber-500/30'
                    : isCorrect
                    ? 'bg-[#0d1117] border-emerald-500/30'
                    : 'bg-[#0d1117] border-red-500/30'
                }`}
              >
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="font-mono font-bold text-gray-300">Q{idx + 1}</span>
                    <span className="text-gray-500">·</span>
                    <span className="text-sky-400 font-mono">{q.subject}</span>
                    {q.deltaTagged && (
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400">
                        Δ Delta Topic
                      </span>
                    )}
                  </div>

                  <div className="flex items-center space-x-2 font-mono text-[11px]">
                    <span className="text-gray-500">{timeSpent}s</span>
                    {wasSkipped ? (
                      <span className="text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded font-semibold">
                        Skipped (Saved -0.25)
                      </span>
                    ) : isCorrect ? (
                      <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-semibold">
                        +1.0 Correct
                      </span>
                    ) : (
                      <span className="text-red-400 bg-red-500/10 px-2 py-0.5 rounded font-semibold">
                        -{negativeRate} Incorrect
                      </span>
                    )}
                  </div>
                </div>

                {/* Question */}
                <div className="text-sm font-semibold text-[#e6edf3]">
                  <MathView math={q.question} />
                </div>

                {/* Options display */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                  {q.options.map((opt, oIdx) => {
                    const isRight = oIdx === q.correctAnswer;
                    const isPicked = userAns === oIdx;

                    let optBg = 'bg-[#161b22] border-[#30363d] text-gray-400';
                    if (isRight) {
                      optBg = 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200 font-bold';
                    } else if (isPicked) {
                      optBg = 'bg-red-950/40 border-red-500/50 text-red-200 line-through';
                    }

                    return (
                      <div
                        key={oIdx}
                        className={`p-2 rounded border text-xs flex items-center space-x-2 ${optBg}`}
                      >
                        <span className="font-mono text-[10px] font-bold">
                          {String.fromCharCode(65 + oIdx)}.
                        </span>
                        <div className="flex-1">
                          <MathView math={opt} />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Full Explanation */}
                <div className="p-3 rounded bg-[#161b22] border border-[#30363d] text-xs space-y-1">
                  <div className="font-semibold text-gray-300 text-[11px] flex items-center space-x-1">
                    <Zap className="w-3 h-3 text-amber-400" />
                    <span>Speed Trick & Conceptual Derivation:</span>
                  </div>
                  <div className="text-gray-300 leading-relaxed text-[11px]">
                    <MathView math={q.explanation} />
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="flex items-center justify-between pt-1">
                  <span className="text-[10px] font-mono text-gray-500">
                    Source: {q.boardOrigin}
                  </span>
                  {onAskStudyBuddy && (
                    <button
                      onClick={() =>
                        onAskStudyBuddy(
                          `Can you provide an in-depth breakdown of this question and related shortcut tricks: "${q.question}"?`
                        )
                      }
                      className="text-[11px] text-sky-400 hover:text-sky-300 font-medium flex items-center space-x-1"
                    >
                      <Sparkles className="w-3 h-3" />
                      <span>Deep Dive in AI Study Buddy</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
