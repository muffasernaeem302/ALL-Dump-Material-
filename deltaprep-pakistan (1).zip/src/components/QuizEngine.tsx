import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import {
  Clock,
  AlertTriangle,
  ShieldCheck,
  Flag,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Award,
  Zap,
  Flame,
  Info,
  ChevronRight,
  BookOpen,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ExamId, BoardId, MCQQuestion, UserAnswerRecord, QuizResultSummary } from '../types';
import { MOCK_MCQS, EXAMS, UNIVERSITY_MERIT_RULES } from '../data';

interface QuizEngineProps {
  targetExam: ExamId;
  homeBoard: BoardId;
  matricPct: number;
  fscPct: number;
  onReturnToDashboard: () => void;
  onOpenTopicById?: (topicId: string) => void;
}

export const QuizEngine: React.FC<QuizEngineProps> = ({
  targetExam,
  homeBoard,
  matricPct,
  fscPct,
  onReturnToDashboard,
  onOpenTopicById,
}) => {
  // Test configuration
  const currentExamInfo = EXAMS.find((e) => e.id === targetExam) || EXAMS[0];
  const [examMode, setExamMode] = useState<ExamId>(targetExam);
  const activeExam = EXAMS.find((e) => e.id === examMode) || currentExamInfo;

  // Simulator state
  const [testStarted, setTestStarted] = useState<boolean>(false);
  const [testCompleted, setTestCompleted] = useState<boolean>(false);
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  // User responses
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [skippedQuestions, setSkippedQuestions] = useState<Record<number, boolean>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Record<number, boolean>>({});
  const [questionTimeSpent, setQuestionTimeSpent] = useState<Record<number, number>>({});

  // Active timers
  const [totalSeconds, setTotalSeconds] = useState<number>(0);
  const [currentQSeconds, setCurrentQSeconds] = useState<number>(0);

  const questions: MCQQuestion[] = MOCK_MCQS;
  const currentQuestion = questions[currentIndex];

  const targetPaceSeconds = activeExam.id === 'fast_nu' ? 40 : activeExam.id === 'nust_net' ? 50 : 60;
  const negativeRate = activeExam.negativeMarkingRate;

  // Timer loop
  useEffect(() => {
    if (!testStarted || testCompleted) return;

    const interval = setInterval(() => {
      setTotalSeconds((prev) => prev + 1);
      setCurrentQSeconds((prev) => {
        const next = prev + 1;
        setQuestionTimeSpent((old) => ({
          ...old,
          [currentIndex]: (old[currentIndex] || 0) + 1,
        }));
        return next;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [testStarted, testCompleted, currentIndex]);

  // Reset timer for new question
  const navigateToQuestion = (index: number) => {
    setCurrentIndex(index);
    setCurrentQSeconds(questionTimeSpent[index] || 0);
  };

  const handleSelectOption = (optionIndex: number) => {
    setSelectedAnswers((prev) => ({ ...prev, [currentIndex]: optionIndex }));
    // Remove from skipped if was marked
    if (skippedQuestions[currentIndex]) {
      const nextSkipped = { ...skippedQuestions };
      delete nextSkipped[currentIndex];
      setSkippedQuestions(nextSkipped);
    }
  };

  const handleSkipQuestion = () => {
    setSkippedQuestions((prev) => ({ ...prev, [currentIndex]: true }));
    const nextAnswers = { ...selectedAnswers };
    delete nextAnswers[currentIndex];
    setSelectedAnswers(nextAnswers);

    if (currentIndex < questions.length - 1) {
      navigateToQuestion(currentIndex + 1);
    }
  };

  const handleToggleFlag = () => {
    setFlaggedQuestions((prev) => ({
      ...prev,
      [currentIndex]: !prev[currentIndex],
    }));
  };

  const handleFinishTest = () => {
    setTestCompleted(true);
    confetti({
      particleCount: 60,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleRestart = () => {
    setSelectedAnswers({});
    setSkippedQuestions({});
    setFlaggedQuestions({});
    setQuestionTimeSpent({});
    setTotalSeconds(0);
    setCurrentQSeconds(0);
    setCurrentIndex(0);
    setTestCompleted(false);
    setTestStarted(true);
  };

  // Compile results
  const calculateResults = (): QuizResultSummary => {
    let correct = 0;
    let incorrect = 0;
    let skipped = 0;
    let timeSinkCount = 0;
    let penaltiesAvoided = 0;

    const userAnswers: UserAnswerRecord[] = questions.map((q, idx) => {
      const isSkipped = !!skippedQuestions[idx];
      const selected = selectedAnswers[idx] !== undefined ? selectedAnswers[idx] : null;
      const isCorrect = selected === q.correctAnswer;
      const timeSpent = questionTimeSpent[idx] || 0;
      const isTimeSink = timeSpent > 60 && !isCorrect;

      if (isSkipped) {
        skipped++;
        if (negativeRate > 0) {
          penaltiesAvoided += negativeRate;
        }
      } else if (selected !== null) {
        if (isCorrect) correct++;
        else incorrect++;
      } else {
        // Unanswered treated as skipped
        skipped++;
      }

      if (isTimeSink) {
        timeSinkCount++;
      }

      return {
        questionId: q.id,
        selectedOption: selected,
        isCorrect,
        isSkipped,
        timeSpentSeconds: timeSpent,
        isTimeSink,
        savedNegativePenalty: isSkipped && negativeRate > 0,
      };
    });

    const attempted = correct + incorrect;
    const scoreRaw = correct;
    const negativeMarkingDeduction = incorrect * negativeRate;
    const netScore = Math.max(0, scoreRaw - negativeMarkingDeduction);
    const accuracyRate = attempted > 0 ? Math.round((correct / attempted) * 100) : 0;
    const avgTimePerQuestion = questions.length > 0 ? Math.round(totalSeconds / questions.length) : 0;

    // Projected Aggregate calculation
    const meritRule = UNIVERSITY_MERIT_RULES.find((u) => u.id === activeExam.id) || UNIVERSITY_MERIT_RULES[0];
    const testNormalizedPct = (netScore / questions.length) * 100;
    const projectedAggregate = parseFloat(
      (
        matricPct * meritRule.matricWeightage +
        fscPct * meritRule.fscWeightage +
        testNormalizedPct * meritRule.testWeightage
      ).toFixed(2)
    );

    return {
      examId: activeExam.id,
      totalQuestions: questions.length,
      attempted,
      correct,
      incorrect,
      skipped,
      scoreRaw,
      negativeMarkingDeduction,
      netScore,
      accuracyRate,
      totalTimeSpentSeconds: totalSeconds,
      avgTimePerQuestion,
      timeSinkQuestionsCount: timeSinkCount,
      penaltyAvoidedPoints: penaltiesAvoided,
      projectedAggregate,
      userAnswers,
    };
  };

  const results = testCompleted ? calculateResults() : null;

  // Render Start Screen
  if (!testStarted && !testCompleted) {
    return (
      <div className="max-w-3xl mx-auto space-y-4 py-2 text-[#e6edf3]">
        <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-md bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-[#e6edf3]">
                Pacing & Risk Simulator (Mock Test)
              </h2>
              <p className="text-xs text-gray-400">
                Calibrate speed, avoid time-sink questions, and master negative marking prevention.
              </p>
            </div>
          </div>

          {/* Exam Mode Toggle */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono font-semibold uppercase tracking-wider text-gray-400">
              Select Exam Pacing Mode
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                type="button"
                onClick={() => setExamMode('fast_nu')}
                className={`p-3 rounded-md border text-left transition-colors cursor-pointer ${
                  examMode === 'fast_nu'
                    ? 'bg-amber-500/10 border-amber-500/40 text-white'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-bold text-white flex items-center justify-between">
                  <span>FAST NU-Test</span>
                  <span className="text-[10px] font-mono text-red-400 font-bold">-0.25 Penalty</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1">40s / Question</div>
                <div className="text-[10px] text-amber-300 mt-0.5 font-medium">
                  Negative marking drill
                </div>
              </button>

              <button
                type="button"
                onClick={() => setExamMode('nust_net')}
                className={`p-3 rounded-md border text-left transition-colors cursor-pointer ${
                  examMode === 'nust_net'
                    ? 'bg-sky-500/10 border-sky-500/40 text-white'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-bold text-white flex items-center justify-between">
                  <span>NUST NET</span>
                  <span className="text-[10px] font-mono text-emerald-400">0 Penalty</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1">50s / Question</div>
                <div className="text-[10px] text-sky-300 mt-0.5 font-medium">
                  Speed sprint drill
                </div>
              </button>

              <button
                type="button"
                onClick={() => setExamMode('mdcat')}
                className={`p-3 rounded-md border text-left transition-colors cursor-pointer ${
                  examMode === 'mdcat'
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-white'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                }`}
              >
                <div className="text-xs font-bold text-white flex items-center justify-between">
                  <span>MDCAT</span>
                  <span className="text-[10px] font-mono text-emerald-400">0 Penalty</span>
                </div>
                <div className="text-[11px] text-gray-400 mt-1">60s / Question</div>
                <div className="text-[10px] text-emerald-300 mt-0.5 font-medium">
                  High-accuracy biology focus
                </div>
              </button>
            </div>
          </div>

          {/* Simulator Rules & Features */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-1">
              <div className="font-bold text-[#e6edf3] flex items-center space-x-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Pacing Meter & Time-Sink Alerts</span>
              </div>
              <p className="text-gray-400 text-[11px]">
                Turns red if you spend &gt;45s on a single MCQ. Pinpoints exact traps where students
                lose valuable minutes.
              </p>
            </div>

            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-1">
              <div className="font-bold text-[#e6edf3] flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
                <span>Penalty Prevention Tracker</span>
              </div>
              <p className="text-gray-400 text-[11px]">
                Use the dedicated <strong>"Skip to Avoid Penalty"</strong> button when uncertain to save
                fractional aggregate marks.
              </p>
            </div>
          </div>

          {/* Start CTA */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-[#30363d]">
            <div className="text-xs text-gray-400 font-mono">
              {questions.length} Questions · Target Pace: {targetPaceSeconds}s/MCQ
            </div>

            <button
              type="button"
              id="start-mock-test-btn"
              onClick={() => {
                setTestStarted(true);
                setCurrentQSeconds(0);
                setTotalSeconds(0);
              }}
              className="w-full sm:w-auto px-5 py-2 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm"
            >
              <Flame className="w-3.5 h-3.5 text-amber-300" />
              <span>Start Timed Simulation</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Render Active Quiz Mode
  if (testStarted && !testCompleted) {
    const isPacingOver = currentQSeconds > targetPaceSeconds;
    const isPacingWarning = currentQSeconds > targetPaceSeconds * 1.5;
    const isSkipped = skippedQuestions[currentIndex];
    const isFlagged = flaggedQuestions[currentIndex];
    const hasAnswered = selectedAnswers[currentIndex] !== undefined;

    return (
      <div className="max-w-4xl mx-auto space-y-3 pb-12 text-[#e6edf3]">
        {/* Top Live Metrics Bar */}
        <div className="p-3 rounded-md bg-[#161b22] border border-[#30363d] flex flex-wrap items-center justify-between gap-3 shadow-sm">
          {/* Progress & Question Count */}
          <div className="flex items-center space-x-3">
            <div className="text-xs font-mono font-bold text-white">
              Q <span className="text-sm text-sky-400">{currentIndex + 1}</span> / {questions.length}
            </div>
            <div className="hidden sm:flex items-center space-x-1.5 px-2 py-0.5 rounded bg-[#0d1117] border border-[#30363d] text-[11px] text-gray-300 font-mono">
              <span>{activeExam.shortName}</span>
              {negativeRate > 0 && <span className="text-red-400 font-semibold">(-{negativeRate})</span>}
            </div>
          </div>

          {/* Question Pacing Meter */}
          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-[10px] uppercase font-mono tracking-wider text-gray-400">
                Time on MCQ
              </div>
              <div
                className={`font-mono text-xs font-bold flex items-center justify-end space-x-1 ${
                  isPacingWarning
                    ? 'text-red-400 animate-pulse'
                    : isPacingOver
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                <Clock className="w-3 h-3" />
                <span>{currentQSeconds}s</span>
                <span className="text-[10px] text-gray-500 font-normal">
                  / {targetPaceSeconds}s target
                </span>
              </div>
            </div>

            {/* Total elapsed */}
            <div className="border-l border-[#30363d] pl-3 text-right hidden sm:block">
              <div className="text-[10px] uppercase font-mono tracking-wider text-gray-400">
                Total Elapsed
              </div>
              <div className="font-mono text-xs font-semibold text-gray-200">
                {Math.floor(totalSeconds / 60)}m {totalSeconds % 60}s
              </div>
            </div>
          </div>

          {/* Finish Button */}
          <button
            type="button"
            id="finish-simulation-btn"
            onClick={handleFinishTest}
            className="px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 text-xs font-medium text-gray-300 border border-[#30363d] transition-colors cursor-pointer"
          >
            Finish & View Analytics
          </button>
        </div>

        {/* Pacing Danger Warning Toast if user is spending > 60s */}
        {isPacingWarning && (
          <div className="p-2.5 rounded-md bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-center justify-between animate-fadeIn">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>
                <strong>Time-Sink Alert:</strong> Over {currentQSeconds}s on this MCQ! In {activeExam.shortName}, spending &gt;60s hurts subsequent questions.
              </span>
            </div>
            <button
              type="button"
              onClick={handleSkipQuestion}
              className="ml-2 px-2.5 py-1 rounded bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] whitespace-nowrap cursor-pointer"
            >
              Skip Now
            </button>
          </div>
        )}

        {/* Question Canvas Card */}
        <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-4">
          {/* Question Meta tags */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-[#0d1117] text-gray-300 border border-[#30363d]">
                {currentQuestion.subject}
              </span>
              <span className="text-xs text-gray-400">{currentQuestion.topicName}</span>
              {currentQuestion.deltaTagged && (
                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  Δ Delta Question
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={handleToggleFlag}
              className={`flex items-center space-x-1 px-2.5 py-1 rounded-md text-xs transition-colors cursor-pointer ${
                isFlagged
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'text-gray-400 hover:text-gray-200 bg-[#0d1117] border border-[#30363d]'
              }`}
            >
              <Flag className={`w-3.5 h-3.5 ${isFlagged ? 'fill-amber-400' : ''}`} />
              <span>{isFlagged ? 'Flagged' : 'Flag'}</span>
            </button>
          </div>

          {/* Question Text */}
          <div className="space-y-1.5">
            <div className="text-[10px] font-mono text-gray-500 flex items-center space-x-1.5">
              <span>Syllabus Source:</span>
              <span className="text-gray-400">{currentQuestion.boardOrigin}</span>
            </div>
            <h3 className="text-sm sm:text-base font-semibold text-[#e6edf3] leading-relaxed">
              {currentQuestion.question}
            </h3>
          </div>

          {/* 4 MCQ Options */}
          <div className="space-y-2">
            {currentQuestion.options.map((option, optIdx) => {
              const isSelected = selectedAnswers[currentIndex] === optIdx;

              return (
                <button
                  key={optIdx}
                  type="button"
                  onClick={() => handleSelectOption(optIdx)}
                  className={`w-full text-left p-3 rounded-md border transition-colors flex items-start space-x-3 cursor-pointer ${
                    isSelected
                      ? 'bg-sky-500/15 border-sky-500/60 text-white shadow-sm'
                      : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600 text-gray-200'
                  }`}
                >
                  <span
                    className={`w-5 h-5 rounded flex items-center justify-center font-mono text-xs font-bold flex-shrink-0 transition-colors ${
                      isSelected
                        ? 'bg-sky-600 text-white'
                        : 'bg-[#161b22] border border-[#30363d] text-gray-400'
                    }`}
                  >
                    {String.fromCharCode(65 + optIdx)}
                  </span>
                  <span className="text-xs sm:text-sm leading-relaxed flex-1 pt-0.5">{option}</span>
                </button>
              );
            })}
          </div>

          {/* Tactical Bottom Buttons: Prev, Next, and Skip to Avoid Penalty */}
          <div className="pt-3 border-t border-[#30363d] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5">
            <div className="flex items-center space-x-2">
              <button
                type="button"
                disabled={currentIndex === 0}
                onClick={() => navigateToQuestion(currentIndex - 1)}
                className="px-3 py-1.5 rounded-md border border-[#30363d] bg-[#0d1117] disabled:opacity-30 text-xs text-gray-300 hover:bg-slate-800 flex items-center space-x-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Prev</span>
              </button>

              <button
                type="button"
                disabled={currentIndex === questions.length - 1}
                onClick={() => navigateToQuestion(currentIndex + 1)}
                className="px-3 py-1.5 rounded-md border border-[#30363d] bg-[#0d1117] disabled:opacity-30 text-xs text-gray-300 hover:bg-slate-800 flex items-center space-x-1 cursor-pointer"
              >
                <span>Next</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Crucial: Skip to Avoid Penalty Button */}
            <div className="flex items-center space-x-2">
              <button
                type="button"
                id="skip-avoid-penalty-btn"
                onClick={handleSkipQuestion}
                className={`flex items-center justify-center space-x-1.5 px-3 py-1.5 rounded-md border text-xs font-semibold transition-colors cursor-pointer ${
                  isSkipped
                    ? 'bg-red-500/20 border-red-500/50 text-red-300'
                    : 'bg-[#0d1117] border-[#30363d] hover:border-red-500/40 hover:bg-red-500/10 text-gray-200'
                }`}
                title="Skip this question to prevent negative marking deduction"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-red-400" />
                <span>Skip to Avoid Penalty</span>
                {negativeRate > 0 && (
                  <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-red-500/20 text-red-400">
                    Saves +{negativeRate}
                  </span>
                )}
              </button>

              {currentIndex === questions.length - 1 && (
                <button
                  type="button"
                  onClick={handleFinishTest}
                  className="px-4 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs cursor-pointer shadow-sm"
                >
                  Submit
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Question Palette Grid */}
        <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-400">
            <span className="font-mono uppercase font-semibold text-[11px]">Question Palette</span>
            <div className="flex items-center space-x-3 text-[10px]">
              <span className="flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-sky-500 inline-block" />
                <span>Answered</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-red-500 inline-block" />
                <span>Skipped</span>
              </span>
              <span className="flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
                <span>Flagged</span>
              </span>
            </div>
          </div>

          <div className="flex flex-wrap gap-1">
            {questions.map((_, qIdx) => {
              const answered = selectedAnswers[qIdx] !== undefined;
              const skipped = skippedQuestions[qIdx];
              const flagged = flaggedQuestions[qIdx];
              const isCurrent = currentIndex === qIdx;

              let btnClass = 'bg-[#0d1117] text-gray-400 border-[#30363d]';
              if (answered) {
                btnClass = 'bg-sky-500/20 border-sky-500/50 text-sky-300';
              } else if (skipped) {
                btnClass = 'bg-red-500/20 border-red-500/50 text-red-300';
              }
              if (flagged) {
                btnClass += ' ring-1 ring-amber-400';
              }
              if (isCurrent) {
                btnClass += ' ring-1 ring-white font-bold text-white';
              }

              return (
                <button
                  key={qIdx}
                  type="button"
                  onClick={() => navigateToQuestion(qIdx)}
                  className={`w-7 h-7 rounded border text-[11px] font-mono transition-colors flex items-center justify-center cursor-pointer ${btnClass}`}
                >
                  {qIdx + 1}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Render Post-Test Analytics Screen
  if (testCompleted && results) {
    const accuracy = results.accuracyRate;
    const timeSinks = results.userAnswers.filter((a) => a.isTimeSink);

    // Determine target university predictions
    const meritRule = UNIVERSITY_MERIT_RULES.find((u) => u.id === activeExam.id) || UNIVERSITY_MERIT_RULES[0];
    const competitiveProgram = meritRule.programs[0];
    const isSafe = results.projectedAggregate >= competitiveProgram.previousClosingMerit;
    const gap = (results.projectedAggregate - competitiveProgram.previousClosingMerit).toFixed(2);

    return (
      <div className="max-w-4xl mx-auto space-y-4 pb-16 text-[#e6edf3]">
        {/* Header Summary Card */}
        <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#30363d] pb-3.5">
            <div>
              <div className="inline-flex items-center space-x-1.5 px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-medium">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Simulation Complete</span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold text-[#e6edf3] mt-1">
                Post-Test Analytics & Risk Diagnostic
              </h2>
              <p className="text-xs text-gray-400">
                Pacing benchmarked against official {activeExam.name} standards.
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleRestart}
                className="flex items-center space-x-1 px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 text-xs font-medium text-gray-300 border border-[#30363d] transition-colors cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Retest</span>
              </button>
              <button
                type="button"
                onClick={onReturnToDashboard}
                className="px-3.5 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors cursor-pointer"
              >
                Delta Dashboard
              </button>
            </div>
          </div>

          {/* Primary 4 Metric Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
            {/* Accuracy */}
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-0.5">
              <div className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
                Accuracy Rate
              </div>
              <div className="text-xl sm:text-2xl font-bold text-emerald-400 font-mono">
                {results.accuracyRate}%
              </div>
              <div className="text-[10px] text-gray-500 font-mono">
                {results.correct} of {results.attempted} attempted
              </div>
            </div>

            {/* Net Score */}
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-0.5">
              <div className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
                Net Score
              </div>
              <div className="text-xl sm:text-2xl font-bold text-white font-mono">
                {results.netScore.toFixed(2)}
                <span className="text-xs text-gray-500 font-normal"> / {questions.length}</span>
              </div>
              <div className="text-[10px] text-gray-500 font-mono">
                {results.negativeMarkingDeduction > 0
                  ? `-${results.negativeMarkingDeduction.toFixed(2)} penalty applied`
                  : '0 negative marks incurred'}
              </div>
            </div>

            {/* Penalty Prevented */}
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-0.5">
              <div className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
                Penalty Avoided
              </div>
              <div className="text-xl sm:text-2xl font-bold text-amber-400 font-mono">
                +{results.penaltyAvoidedPoints.toFixed(2)}
              </div>
              <div className="text-[10px] text-gray-500 font-mono">
                Saved via {results.skipped} smart skips
              </div>
            </div>

            {/* Avg Pace */}
            <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-0.5">
              <div className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
                Avg Time / MCQ
              </div>
              <div
                className={`text-xl sm:text-2xl font-bold font-mono ${
                  results.avgTimePerQuestion <= targetPaceSeconds ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {results.avgTimePerQuestion}s
              </div>
              <div className="text-[10px] text-gray-500 font-mono">
                Target: {targetPaceSeconds}s per MCQ
              </div>
            </div>
          </div>

          {/* Estimated Aggregate Prediction Card */}
          <div className="p-4 rounded-md bg-[#0d1117] border border-[#30363d] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-sky-400 flex items-center space-x-1.5">
                <Award className="w-3.5 h-3.5" />
                <span>Target University Aggregate Prediction</span>
              </span>
              <span className="text-[10px] font-mono text-gray-500">
                {meritRule.universityName} Formula
              </span>
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-white font-mono">
                  {results.projectedAggregate}%
                </div>
                <p className="text-xs text-gray-400 mt-0.5">
                  Based on Matric ({matricPct}%) + FSc ({fscPct}%) + Test Net Score
                </p>
              </div>

              <div className="p-2.5 rounded bg-[#161b22] border border-[#30363d] text-xs space-y-1 sm:w-64">
                <div className="text-gray-500 font-mono text-[10px]">Closing Merit Benchmark:</div>
                <div className="font-semibold text-white truncate">{competitiveProgram.name}</div>
                <div className="flex items-center space-x-1.5 font-mono text-xs">
                  <span className="text-gray-400">{competitiveProgram.previousClosingMerit}%</span>
                  <span className="text-gray-500">→</span>
                  <span className={isSafe ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                    {isSafe ? `+${gap}% (Safe Zone)` : `${gap}% (Borderline)`}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Time-Sink Alert Section */}
          <div className="space-y-2">
            <div className="flex items-center space-x-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
              <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                Time-Sink Trap Diagnostics ({timeSinks.length} Detected)
              </h3>
            </div>

            {timeSinks.length > 0 ? (
              <div className="space-y-1.5">
                {timeSinks.map((ts, idx) => {
                  const q = questions.find((quest) => quest.id === ts.questionId);
                  if (!q) return null;

                  return (
                    <div
                      key={idx}
                      className="p-2.5 rounded-md bg-red-500/10 border border-red-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-2">
                          <span className="font-mono font-bold text-red-400">
                            Burned {ts.timeSpentSeconds}s
                          </span>
                          <span className="text-gray-500">·</span>
                          <span className="font-semibold text-white">{q.subject} - {q.topicName}</span>
                        </div>
                        <p className="text-gray-300 line-clamp-1">{q.question}</p>
                      </div>

                      <div className="text-right sm:flex-shrink-0">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-red-500/20 text-red-300">
                          Exceeded benchmark by +{ts.timeSpentSeconds - 40}s
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="p-2.5 rounded-md bg-[#0d1117] border border-[#30363d] text-xs text-gray-300 flex items-center space-x-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span>
                  Outstanding pacing discipline! No question exceeded &gt;60s.
                </span>
              </div>
            )}
          </div>

          {/* Question-by-Question Detailed Review */}
          <div className="space-y-3 pt-3 border-t border-[#30363d]">
            <h3 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              Question-by-Question Textbook Review
            </h3>

            <div className="space-y-2">
              {questions.map((q, qIdx) => {
                const ans = results.userAnswers[qIdx];
                const wasCorrect = ans.isCorrect;
                const wasSkipped = ans.isSkipped;

                return (
                  <div
                    key={q.id}
                    className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-2 text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-bold text-gray-400">Q{qIdx + 1}</span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-[#161b22] border border-[#30363d] text-gray-300">
                          {q.subject}
                        </span>
                        <span className="text-gray-500 font-mono text-[11px]">
                          Time: {ans.timeSpentSeconds}s
                        </span>
                      </div>

                      <div>
                        {wasCorrect ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                            +1.00 Correct
                          </span>
                        ) : wasSkipped ? (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold font-mono bg-slate-800 text-gray-300 border border-slate-700">
                            Skipped (0.00)
                          </span>
                        ) : (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold font-mono bg-red-500/10 text-red-400 border border-red-500/30">
                            -{negativeRate > 0 ? negativeRate : '0'} Penalty
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="font-semibold text-[#e6edf3] text-xs leading-relaxed">{q.question}</p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-[11px]">
                      <div className="p-1.5 rounded bg-[#161b22] border border-[#30363d]">
                        <span className="text-gray-400">Your Answer: </span>
                        <span
                          className={
                            wasCorrect
                              ? 'text-emerald-400 font-bold'
                              : wasSkipped
                              ? 'text-gray-400'
                              : 'text-red-400 font-bold'
                          }
                        >
                          {ans.selectedOption !== null
                            ? q.options[ans.selectedOption]
                            : 'Skipped to avoid penalty'}
                        </span>
                      </div>

                      <div className="p-1.5 rounded bg-[#161b22] border border-[#30363d]">
                        <span className="text-gray-400">Correct Answer: </span>
                        <span className="text-emerald-400 font-bold">
                          {q.options[q.correctAnswer]}
                        </span>
                      </div>
                    </div>

                    {/* Textbook Board Origin & Explanation */}
                    <div className="p-2 rounded bg-[#161b22] border border-[#30363d] text-gray-300 space-y-0.5">
                      <div className="text-[10px] font-mono text-sky-400">
                        Board Origin: {q.boardOrigin}
                      </div>
                      <p className="leading-relaxed text-[11px]">{q.explanation}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
