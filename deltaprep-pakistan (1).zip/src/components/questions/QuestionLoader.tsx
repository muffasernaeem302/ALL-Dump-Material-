import React, { useState, useEffect, useCallback } from 'react';
import { ArrowDown, Database, Filter, Loader2, Search } from 'lucide-react';
import { QuestionBankItem } from '../../types';
import { QuestionCard } from './QuestionCard';

export const QuestionLoader: React.FC = () => {
  const [questions, setQuestions] = useState<QuestionBankItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [loadingMore, setLoadingMore] = useState<boolean>(false);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState<boolean>(false);
  const [total, setTotal] = useState<number>(0);

  // Filters
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('All');
  const [selectedLevel, setSelectedLevel] = useState<string>('All');

  const fetchQuestions = useCallback(
    async (cursor?: string, append = false) => {
      if (append) {
        setLoadingMore(true);
      } else {
        setLoading(true);
      }

      try {
        const params = new URLSearchParams();
        params.append('limit', '10');
        if (cursor) params.append('cursor', cursor);
        if (selectedSubject !== 'All') params.append('subject', selectedSubject);
        if (selectedDifficulty !== 'All') params.append('difficulty', selectedDifficulty);
        if (selectedLevel !== 'All') params.append('level', selectedLevel);

        const res = await fetch(`/api/questions?${params.toString()}`);
        if (res.ok) {
          const data = await res.json();
          if (append) {
            setQuestions((prev) => [...prev, ...data.questions]);
          } else {
            setQuestions(data.questions);
          }
          setHasMore(data.hasMore);
          setNextCursor(data.nextCursor);
          if (data.total !== undefined) setTotal(data.total);
        }
      } catch (e) {
        console.error('Failed to load questions:', e);
      } finally {
        setLoading(false);
        setLoadingMore(false);
      }
    },
    [selectedSubject, selectedDifficulty, selectedLevel]
  );

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  const loadMore = () => {
    if (nextCursor && !loadingMore) {
      fetchQuestions(nextCursor, true);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header & Filter Bar */}
      <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded bg-sky-500/20 text-sky-400">
              <Database className="w-4 h-4" />
            </span>
            <div>
              <h3 className="text-sm font-bold text-[#e6edf3]">Question Bank Repository</h3>
              <p className="text-xs text-gray-400">
                Chunked batch loader with server-side cursor pagination.
              </p>
            </div>
          </div>

          <span className="text-xs font-mono text-gray-400">
            Showing <strong className="text-sky-400">{questions.length}</strong> of {total} verified questions
          </span>
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-[#30363d]/60">
          <div>
            <label className="text-[10px] font-mono text-gray-400 block mb-1">Subject</label>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2.5 py-1.5 text-xs text-[#e6edf3] focus:outline-none focus:border-sky-500"
            >
              <option value="All">All Subjects</option>
              <option value="Physics">Physics</option>
              <option value="Mathematics">Mathematics</option>
              <option value="Chemistry">Chemistry</option>
              <option value="Biology">Biology</option>
              <option value="Analytical & Logical Reasoning">Analytical Reasoning</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] font-mono text-gray-400 block mb-1">Difficulty</label>
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2.5 py-1.5 text-xs text-[#e6edf3] focus:outline-none focus:border-sky-500"
            >
              <option value="All">All Difficulties</option>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] font-mono text-gray-400 block mb-1">Progression Level</label>
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="w-full bg-[#0d1117] border border-[#30363d] rounded px-2.5 py-1.5 text-xs text-[#e6edf3] focus:outline-none focus:border-sky-500"
            >
              <option value="All">All Levels</option>
              <option value="1">Level 1 (Basic Formulas)</option>
              <option value="2">Level 2 (Applied Dynamics)</option>
              <option value="3">Level 3 (Advanced Entrance Mock)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Questions List */}
      {loading ? (
        <div className="space-y-3 animate-pulse">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="h-40 rounded-lg bg-[#161b22] border border-[#30363d]" />
          ))}
        </div>
      ) : questions.length === 0 ? (
        <div className="p-8 rounded-lg bg-[#161b22] border border-[#30363d] text-center text-gray-400">
          No questions matched your filter criteria.
        </div>
      ) : (
        <div className="space-y-3">
          {questions.map((q, idx) => (
            <QuestionCard key={q.id} question={q} index={idx} />
          ))}
        </div>
      )}

      {/* Cursor Load More Trigger */}
      {hasMore && (
        <div className="text-center pt-2">
          <button
            type="button"
            onClick={loadMore}
            disabled={loadingMore}
            className="inline-flex items-center space-x-2 px-5 py-2 rounded-md bg-slate-800 hover:bg-slate-700 text-gray-200 hover:text-white text-xs font-semibold border border-slate-600 transition-colors cursor-pointer disabled:opacity-50"
          >
            {loadingMore ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-sky-400" />
                <span>Loading Next Batch...</span>
              </>
            ) : (
              <>
                <ArrowDown className="w-3.5 h-3.5" />
                <span>Load More Questions (Cursor Pagination)</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
