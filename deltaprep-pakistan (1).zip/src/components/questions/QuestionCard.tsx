import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Clock, HelpCircle, Sparkles } from 'lucide-react';
import { QuestionBankItem } from '../../types';
import { MathView } from '../MathView';

interface QuestionCardProps {
  question: QuestionBankItem;
  index: number;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({ question, index }) => {
  const [showSolution, setShowSolution] = useState<boolean>(false);

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Easy':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30';
      case 'Medium':
        return 'bg-amber-500/10 text-amber-300 border-amber-500/30';
      default:
        return 'bg-red-500/10 text-red-300 border-red-500/30';
    }
  };

  return (
    <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3 transition-colors hover:border-[#30363d]/80">
      <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
        <div className="flex items-center space-x-2">
          <span className="font-mono text-gray-400 font-bold px-2 py-0.5 rounded bg-[#0d1117] border border-[#30363d]">
            #{index + 1}
          </span>
          <span
            className={`px-2 py-0.5 rounded font-mono text-[10px] font-semibold border ${getDifficultyColor(
              question.difficulty
            )}`}
          >
            {question.difficulty}
          </span>
          <span className="px-2 py-0.5 rounded font-mono text-[10px] bg-sky-500/10 text-sky-400 border border-sky-500/30">
            Level {question.level}
          </span>
        </div>

        <div className="flex items-center space-x-2 text-[11px] text-gray-400 font-mono">
          <span className="flex items-center space-x-1">
            <Clock className="w-3 h-3 text-gray-500" />
            <span>{question.timeTargetSeconds}s target</span>
          </span>
          <span className="px-2 py-0.5 rounded bg-slate-800 text-gray-300 text-[10px]">
            {question.boardOrigin}
          </span>
        </div>
      </div>

      {/* Question Stem */}
      <div className="text-xs sm:text-sm text-[#e6edf3] font-medium leading-relaxed">
        <MathView math={question.question} />
      </div>

      {/* 4 Options Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
        {question.options.map((opt, optIdx) => {
          const isCorrect = optIdx === question.correctIndex;
          return (
            <div
              key={optIdx}
              className={`p-2.5 rounded border text-xs flex items-start space-x-2.5 transition-colors ${
                showSolution && isCorrect
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-emerald-200 font-medium'
                  : 'bg-[#0d1117] border-[#30363d] text-gray-300'
              }`}
            >
              <span
                className={`h-4 w-4 rounded flex items-center justify-center font-mono text-[10px] font-bold shrink-0 mt-0.5 ${
                  showSolution && isCorrect
                    ? 'bg-emerald-500 text-white'
                    : 'bg-slate-800 text-gray-400'
                }`}
              >
                {String.fromCharCode(65 + optIdx)}
              </span>
              <div className="flex-1">
                <MathView math={opt} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Toggle Solution */}
      <div className="pt-2 border-t border-[#30363d]/60 flex items-center justify-between">
        <button
          type="button"
          onClick={() => setShowSolution(!showSolution)}
          className="inline-flex items-center space-x-1 text-xs text-sky-400 hover:text-sky-300 font-semibold cursor-pointer transition-colors"
        >
          <span>{showSolution ? 'Hide Solution' : 'Reveal Verified Solution & KaTeX Proof'}</span>
          {showSolution ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>

        {question.deltaTagged && (
          <span className="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
            FBISE / Provincial Delta
          </span>
        )}
      </div>

      {/* Detailed KaTeX Explanation */}
      {showSolution && (
        <div className="p-3.5 rounded-md bg-[#0d1117] border border-[#30363d] text-xs space-y-1.5 animate-fadeIn">
          <div className="text-[10px] font-mono uppercase text-emerald-400 font-bold flex items-center space-x-1">
            <span>Correct: Option {String.fromCharCode(65 + question.correctIndex)}</span>
          </div>
          <div className="text-gray-300 leading-relaxed text-xs">
            <MathView math={question.explanation} />
          </div>
        </div>
      )}
    </div>
  );
};
