import React, { useMemo } from 'react';
import katex from 'katex';

interface MathViewProps {
  math: string;
  block?: boolean;
  className?: string;
}

/**
 * Determine if a string without explicit delimiters is a pure math equation
 * rather than a natural language sentence containing math words.
 */
function isPureFormula(str: string): boolean {
  const trimmed = str.trim();
  if (!trimmed) return false;

  // Wrapped in math delimiters
  if (
    (trimmed.startsWith('$$') && trimmed.endsWith('$$')) ||
    (trimmed.startsWith('$') && trimmed.endsWith('$')) ||
    (trimmed.startsWith('\\[') && trimmed.endsWith('\\]')) ||
    (trimmed.startsWith('\\(') && trimmed.endsWith('\\)'))
  ) {
    return true;
  }

  // If there are no backslashes, it is standard text/unicode, not a LaTeX formula
  if (!trimmed.includes('\\')) {
    return false;
  }

  // Strip LaTeX \text{...}, \mathrm{...}, \operatorname{...}, etc.
  const withoutText = trimmed.replace(/\\[a-zA-Z]+\{[^}]*\}/g, '');
  // Strip LaTeX command names (\frac, \sqrt, \alpha, \mu, \quad, etc.)
  const withoutCommands = withoutText.replace(/\\[a-zA-Z]+/g, '');

  // Count natural language words (alphabetic words of length >= 3)
  const words = withoutCommands.match(/[a-zA-Z]{3,}/g) || [];

  // In a pure math formula, variables are usually single letters (x, y, v, a, t, etc.)
  // If there are 2 or more multi-letter words outside LaTeX commands, it's a natural sentence!
  return words.length < 2;
}

function renderKatexToString(expr: string, displayMode: boolean): string | null {
  try {
    const cleaned = expr.trim();
    if (!cleaned) return '';
    return katex.renderToString(cleaned, {
      displayMode,
      throwOnError: false,
      output: 'htmlAndMathml',
    });
  } catch {
    return null;
  }
}

export const MathView: React.FC<MathViewProps> = ({ math, block = false, className = '' }) => {
  if (!math || typeof math !== 'string') {
    return null;
  }

  // 1. Explicit block equation (e.g. FormulaVault cards, StudyBuddy derivation boxes)
  if (block) {
    let cleanExpr = math.trim();
    if (cleanExpr.startsWith('$$') && cleanExpr.endsWith('$$')) {
      cleanExpr = cleanExpr.slice(2, -2).trim();
    } else if (cleanExpr.startsWith('\\[') && cleanExpr.endsWith('\\]')) {
      cleanExpr = cleanExpr.slice(2, -2).trim();
    } else if (cleanExpr.startsWith('$') && cleanExpr.endsWith('$')) {
      cleanExpr = cleanExpr.slice(1, -1).trim();
    }

    const html = renderKatexToString(cleanExpr, true);
    if (!html) {
      return (
        <code className={`font-mono text-sky-400 bg-[#0d1117] px-1.5 py-0.5 rounded text-xs block text-center overflow-x-auto ${className}`}>
          {math}
        </code>
      );
    }

    return (
      <div
        className={`my-2 block text-center overflow-x-auto py-1 select-text ${className}`}
        dangerouslySetInnerHTML={{ __html: html }}
      />
    );
  }

  // 2. Pure plain text with NO LaTeX backslashes and NO math delimiters
  // This directly prevents KaTeX from destroying word spacing in MCQ questions, options, and explanations
  if (!math.includes('\\') && !math.includes('$')) {
    return <span className={`select-text inline leading-relaxed ${className}`}>{math}</span>;
  }

  // 3. String contains explicit delimiters: $...$, $$...$$, \(...\), \[...\]
  const DELIMITER_REGEX = /(\$\$[\s\S]+?\$\$|\$[^\$\n]+?\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\))/g;
  if (DELIMITER_REGEX.test(math)) {
    const parts = math.split(DELIMITER_REGEX);
    return (
      <span className={`select-text inline leading-relaxed ${className}`}>
        {parts.map((part, idx) => {
          if (!part) return null;

          let isMath = false;
          let isDisplay = false;
          let mathExpr = part;

          if (part.startsWith('$$') && part.endsWith('$$')) {
            isMath = true;
            isDisplay = true;
            mathExpr = part.slice(2, -2);
          } else if (part.startsWith('\\[') && part.endsWith('\\]')) {
            isMath = true;
            isDisplay = true;
            mathExpr = part.slice(2, -2);
          } else if (part.startsWith('$') && part.endsWith('$')) {
            isMath = true;
            isDisplay = false;
            mathExpr = part.slice(1, -1);
          } else if (part.startsWith('\\(') && part.endsWith('\\)')) {
            isMath = true;
            isDisplay = false;
            mathExpr = part.slice(2, -2);
          }

          if (isMath) {
            const html = renderKatexToString(mathExpr, isDisplay);
            if (html) {
              return (
                <span
                  key={idx}
                  className={isDisplay ? 'block text-center my-1' : 'inline px-0.5'}
                  dangerouslySetInnerHTML={{ __html: html }}
                />
              );
            }
            return (
              <code key={idx} className="font-mono text-sky-400 bg-[#0d1117] px-1 rounded text-xs">
                {part}
              </code>
            );
          }

          // Plain text segment: preserves normal spaces and typography
          return <span key={idx}>{part}</span>;
        })}
      </span>
    );
  }

  // 4. String contains backslashes but NO delimiters:
  // Check if it is a pure standalone formula (e.g. \mu_0, R = \frac{v^2}{a_n})
  if (isPureFormula(math)) {
    const html = renderKatexToString(math, false);
    if (html) {
      return (
        <span
          className={`select-text inline ${className}`}
          dangerouslySetInnerHTML={{ __html: html }}
        />
      );
    }
    return (
      <code className={`font-mono text-sky-400 bg-[#0d1117] px-1.5 py-0.5 rounded text-xs ${className}`}>
        {math}
      </code>
    );
  }

  // 5. String is a natural language sentence containing embedded LaTeX commands (e.g. "Recall \frac{1}{2}...")
  const LATEX_TOKEN_REGEX = /(\\[a-zA-Z]+(?:\{[^{}]*\}|\[[^\[\]]*\])*(?:_[0-9a-zA-Z]+|\^[0-9a-zA-Z]+)*)/g;
  const parts = math.split(LATEX_TOKEN_REGEX);

  return (
    <span className={`select-text inline leading-relaxed ${className}`}>
      {parts.map((part, idx) => {
        if (!part) return null;
        if (part.startsWith('\\')) {
          const html = renderKatexToString(part, false);
          if (html) {
            return (
              <span
                key={idx}
                className="inline px-0.5"
                dangerouslySetInnerHTML={{ __html: html }}
              />
            );
          }
          return <code key={idx} className="font-mono text-sky-400 bg-[#0d1117] px-1 rounded text-xs">{part}</code>;
        }
        return <span key={idx}>{part}</span>;
      })}
    </span>
  );
};
