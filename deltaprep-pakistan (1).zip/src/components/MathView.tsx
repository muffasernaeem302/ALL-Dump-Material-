import React, { useMemo } from 'react';
import katex from 'katex';

interface MathViewProps {
  math: string;
  block?: boolean;
  className?: string;
}

export const MathView: React.FC<MathViewProps> = ({ math, block = false, className = '' }) => {
  const html = useMemo(() => {
    try {
      return katex.renderToString(math, {
        displayMode: block,
        throwOnError: false,
        output: 'htmlAndMathml',
      });
    } catch {
      return null;
    }
  }, [math, block]);

  if (!html) {
    return (
      <code className={`font-mono text-sky-400 bg-[#0d1117] px-1.5 py-0.5 rounded text-xs ${className}`}>
        {math}
      </code>
    );
  }

  return (
    <span
      className={`inline-block select-text ${block ? 'my-2 block text-center overflow-x-auto py-1' : ''} ${className}`}
      dangerouslySetInnerHTML={{ __html: html }}
    />
  );
};
