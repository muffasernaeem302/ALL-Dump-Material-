import React, { useState, useMemo } from 'react';
import {
  Search,
  Bookmark,
  Sparkles,
  Eye,
  EyeOff,
  Filter,
  CheckCircle2,
  HelpCircle,
  Zap,
  BookOpen,
  ArrowUpRight,
  Printer,
  FileText,
  Layers,
  AlertTriangle,
  Lightbulb,
  Check,
  Copy,
} from 'lucide-react';
import { FormulaItem, FormulaSubject, ShorthandChapterCheatSheet } from '../types';
import { formulasData, shorthandFormulas } from '../data';
import { MathView } from './MathView';

interface FormulaVaultProps {
  onAskStudyBuddy?: (formula: FormulaItem) => void;
  onGoToPractice?: (subject: string) => void;
}

export const FormulaVault: React.FC<FormulaVaultProps> = ({
  onAskStudyBuddy,
  onGoToPractice,
}) => {
  const [viewMode, setViewMode] = useState<'cards' | 'shorthand'>('cards');
  const [activeSubject, setActiveSubject] = useState<FormulaSubject>('Physics');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedChapter, setSelectedChapter] = useState<string>('All');
  const [activeRecallMode, setActiveRecallMode] = useState<boolean>(false);
  const [revealedIds, setRevealedIds] = useState<Set<string>>(new Set());
  const [starredIds, setStarredIds] = useState<Set<string>>(
    new Set(formulasData.filter((f) => f.isStarred).map((f) => f.id))
  );
  const [filterStarredOnly, setFilterStarredOnly] = useState<boolean>(false);
  const [selectedCheatSheetId, setSelectedCheatSheetId] = useState<string>(
    shorthandFormulas[0]?.id || ''
  );
  const [copiedFormulaTitle, setCopiedFormulaTitle] = useState<string | null>(null);

  // Subject counts
  const subjectCounts = useMemo(() => {
    return {
      Physics: formulasData.filter((f) => f.subject === 'Physics').length,
      Mathematics: formulasData.filter((f) => f.subject === 'Mathematics').length,
      Chemistry: formulasData.filter((f) => f.subject === 'Chemistry').length,
    };
  }, []);

  // Distinct chapters for the active subject
  const chapters = useMemo(() => {
    const list = formulasData
      .filter((f) => f.subject === activeSubject)
      .map((f) => f.chapter);
    return ['All', ...Array.from(new Set(list))];
  }, [activeSubject]);

  // Filtered formulas
  const filteredFormulas = useMemo(() => {
    return formulasData.filter((f) => {
      if (f.subject !== activeSubject) return false;
      if (selectedChapter !== 'All' && f.chapter !== selectedChapter) return false;
      if (filterStarredOnly && !starredIds.has(f.id)) return false;

      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        f.title.toLowerCase().includes(q) ||
        f.chapter.toLowerCase().includes(q) ||
        f.shortcutTip.toLowerCase().includes(q) ||
        f.boardOrigin.toLowerCase().includes(q) ||
        f.tags.some((t) => t.toLowerCase().includes(q))
      );
    });
  }, [activeSubject, selectedChapter, filterStarredOnly, starredIds, searchQuery]);

  const activeCheatSheet = useMemo(() => {
    return (
      shorthandFormulas.find((s) => s.id === selectedCheatSheetId) ||
      shorthandFormulas[0]
    );
  }, [selectedCheatSheetId]);

  const toggleStar = (id: string) => {
    setStarredIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const toggleReveal = (id: string) => {
    setRevealedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleCopyLatex = (title: string, latex: string) => {
    navigator.clipboard?.writeText(latex);
    setCopiedFormulaTitle(title);
    setTimeout(() => setCopiedFormulaTitle(null), 2000);
  };

  const handlePrintCheatSheet = () => {
    window.print();
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header Banner */}
      <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-4 sm:p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <span className="h-6 w-6 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">
                ∑
              </span>
              <h2 className="text-base sm:text-lg font-bold text-[#e6edf3]">
                Formula Vault & Shorthand Cheat Sheets
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                15+ Equations / Chapter
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-1 max-w-2xl">
              KaTeX LaTeX rendering, active recall memory-testing toggles, and high-speed exam shortcut heuristics for NUST NET, FAST NU-Test, COMSATS, and MDCAT.
            </p>
          </div>

          {/* View Mode & Active Recall Toggle Cluster */}
          <div className="flex flex-wrap items-center gap-2">
            {/* View Mode Switcher */}
            <div className="flex items-center bg-[#0d1117] border border-[#30363d] p-1 rounded-lg">
              <button
                id="btn-view-cards"
                onClick={() => setViewMode('cards')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  viewMode === 'cards'
                    ? 'bg-sky-500 text-white shadow-xs'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Recall Cards</span>
              </button>
              <button
                id="btn-view-shorthand"
                onClick={() => setViewMode('shorthand')}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                  viewMode === 'shorthand'
                    ? 'bg-sky-500 text-white shadow-xs'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Chapter Cheat Sheets</span>
              </button>
            </div>

            {/* Active Recall Toggle */}
            <div className="flex items-center space-x-2.5 bg-[#0d1117] border border-[#30363d] px-3 py-1.5 rounded-lg">
              <div className="flex flex-col">
                <span className="text-[11px] font-semibold text-[#e6edf3] flex items-center space-x-1">
                  <span>Active Recall</span>
                  {activeRecallMode && (
                    <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
                  )}
                </span>
                <span className="text-[9px] text-gray-400">Blurs formula</span>
              </div>
              <button
                id="btn-toggle-active-recall"
                onClick={() => {
                  setActiveRecallMode(!activeRecallMode);
                  setRevealedIds(new Set());
                }}
                className={`relative inline-flex h-4.5 w-8 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  activeRecallMode ? 'bg-amber-500' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    activeRecallMode ? 'translate-x-3.5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Controls Bar */}
        {viewMode === 'cards' ? (
          <div className="mt-4 pt-4 border-t border-[#30363d] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
            {/* Subject Pills */}
            <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
              {(['Physics', 'Mathematics', 'Chemistry'] as FormulaSubject[]).map((subj) => (
                <button
                  key={subj}
                  id={`tab-formula-${subj.toLowerCase()}`}
                  onClick={() => {
                    setActiveSubject(subj);
                    setSelectedChapter('All');
                  }}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    activeSubject === subj
                      ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                      : 'text-gray-400 hover:text-gray-200 hover:bg-slate-800 border border-transparent'
                  }`}
                >
                  <span>{subj}</span>
                  <span className="text-[10px] font-mono px-1 rounded bg-[#0d1117] text-gray-400 border border-[#30363d]">
                    {subjectCounts[subj]}
                  </span>
                </button>
              ))}
            </div>

            {/* Search & Starred Filter */}
            <div className="flex items-center space-x-2">
              <div className="relative grow sm:w-60">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search formula, keyword..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#0d1117] border border-[#30363d] rounded-md text-xs text-white placeholder-gray-500 focus:outline-none focus:border-sky-500"
                />
              </div>

              <button
                id="btn-filter-starred"
                onClick={() => setFilterStarredOnly(!filterStarredOnly)}
                className={`p-2 rounded-md border text-xs flex items-center space-x-1 transition-colors cursor-pointer ${
                  filterStarredOnly
                    ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                    : 'bg-[#0d1117] border-[#30363d] text-gray-400 hover:text-gray-200'
                }`}
                title="Filter bookmarked formulas"
              >
                <Bookmark className={`w-3.5 h-3.5 ${filterStarredOnly ? 'fill-current' : ''}`} />
                <span className="hidden sm:inline">Starred</span>
              </button>
            </div>
          </div>
        ) : (
          /* Shorthand Cheat Sheet Selector */
          <div className="mt-4 pt-4 border-t border-[#30363d] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-2 overflow-x-auto pb-1">
              <span className="text-xs text-gray-400 font-mono">Chapter Sheet:</span>
              {shorthandFormulas.map((sheet) => (
                <button
                  key={sheet.id}
                  onClick={() => setSelectedCheatSheetId(sheet.id)}
                  className={`px-3 py-1.5 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                    activeCheatSheet.id === sheet.id
                      ? 'bg-sky-500 text-white shadow-xs'
                      : 'bg-[#0d1117] text-gray-300 hover:bg-slate-800 border border-[#30363d]'
                  }`}
                >
                  {sheet.subject} Ch {sheet.chapterNumber}: {sheet.chapter}
                </button>
              ))}
            </div>

            <button
              onClick={handlePrintCheatSheet}
              className="px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 border border-[#30363d] text-xs font-semibold text-gray-200 flex items-center space-x-1.5 cursor-pointer"
              title="Print or Save PDF Cheat Sheet"
            >
              <Printer className="w-3.5 h-3.5 text-sky-400" />
              <span>Print / Save PDF</span>
            </button>
          </div>
        )}
      </div>

      {/* VIEW MODE 1: Interactive Recall Cards */}
      {viewMode === 'cards' && (
        <>
          {filteredFormulas.length === 0 ? (
            <div className="p-10 rounded-xl border border-[#30363d] bg-[#161b22] text-center space-y-2">
              <p className="text-sm font-semibold text-gray-300">No formulas match your criteria</p>
              <p className="text-xs text-gray-500">
                Try adjusting your search query or selecting &quot;All&quot; chapters.
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedChapter('All');
                  setFilterStarredOnly(false);
                }}
                className="text-xs text-sky-400 hover:underline cursor-pointer"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5">
              {filteredFormulas.map((formula) => {
                const isRevealed = !activeRecallMode || revealedIds.has(formula.id);
                const isStarred = starredIds.has(formula.id);

                return (
                  <div
                    key={formula.id}
                    id={`formula-card-${formula.id}`}
                    className="rounded-xl border border-[#30363d] bg-[#161b22] hover:border-slate-600 transition-colors flex flex-col justify-between overflow-hidden shadow-xs"
                  >
                    {/* Card Top */}
                    <div className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#0d1117] border border-[#30363d] text-sky-400 font-semibold">
                              {formula.chapter}
                            </span>
                            <span className="text-[10px] text-gray-500 font-mono">
                              {formula.boardOrigin}
                            </span>
                          </div>
                          <h3 className="text-sm font-bold text-[#e6edf3] mt-1">
                            {formula.title}
                          </h3>
                        </div>

                        <div className="flex items-center space-x-1 shrink-0">
                          <button
                            onClick={() => handleCopyLatex(formula.title, formula.latex)}
                            className="p-1.5 rounded text-gray-500 hover:text-gray-300 bg-[#0d1117] cursor-pointer"
                            title="Copy LaTeX"
                          >
                            {copiedFormulaTitle === formula.title ? (
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <button
                            id={`star-btn-${formula.id}`}
                            onClick={() => toggleStar(formula.id)}
                            className={`p-1.5 rounded transition-colors cursor-pointer ${
                              isStarred
                                ? 'text-amber-400 hover:text-amber-300 bg-amber-500/10'
                                : 'text-gray-500 hover:text-gray-300 bg-[#0d1117]'
                            }`}
                            title={isStarred ? 'Unstar' : 'Bookmark formula'}
                          >
                            <Bookmark className={`w-3.5 h-3.5 ${isStarred ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                      </div>

                      {/* Formula Box with Active Recall Blur */}
                      <div className="relative rounded-md bg-[#0d1117] border border-[#30363d] p-3 text-center min-h-[72px] flex items-center justify-center">
                        {isRevealed ? (
                          <div className="w-full overflow-x-auto text-[#e6edf3]">
                            <MathView math={formula.latex} block />
                          </div>
                        ) : (
                          <button
                            onClick={() => toggleReveal(formula.id)}
                            className="w-full h-full flex flex-col items-center justify-center py-3 group cursor-pointer"
                          >
                            <div className="flex items-center space-x-1.5 text-xs text-amber-400 font-medium group-hover:text-amber-300">
                              <Eye className="w-3.5 h-3.5" />
                              <span>Tap to Reveal Formula (Active Recall)</span>
                            </div>
                            <span className="text-[10px] text-gray-500 mt-1 font-mono">
                              Test your mental derivation before revealing
                            </span>
                          </button>
                        )}

                        {activeRecallMode && isRevealed && (
                          <button
                            onClick={() => toggleReveal(formula.id)}
                            className="absolute top-2 right-2 p-1 rounded text-gray-500 hover:text-gray-300 bg-[#161b22] border border-[#30363d] cursor-pointer"
                            title="Hide formula"
                          >
                            <EyeOff className="w-3 h-3" />
                          </button>
                        )}
                      </div>

                      {/* Variable Breakdown */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">
                          Variable Breakdown:
                        </span>
                        <div className="grid grid-cols-2 gap-1.5">
                          {formula.variableBreakdown.map((vb, idx) => (
                            <div
                              key={idx}
                              className="px-2 py-1 rounded bg-[#0d1117]/60 border border-[#30363d]/60 text-[11px] flex items-center justify-between"
                            >
                              <span className="font-mono text-sky-400 text-xs">{vb.symbol}</span>
                              <span
                                className="text-gray-400 text-[10px] truncate max-w-[130px] ml-1.5"
                                title={vb.meaning}
                              >
                                {vb.meaning}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Shortcut Tip */}
                      <div className="p-2.5 rounded-md bg-amber-500/10 border border-amber-500/20 text-xs">
                        <div className="flex items-center space-x-1 text-amber-400 font-semibold mb-0.5 text-[11px]">
                          <Zap className="w-3 h-3" />
                          <span>Exam Shortcut / Elimination Rule</span>
                        </div>
                        <p className="text-[11px] text-amber-200/90 leading-relaxed">
                          {formula.shortcutTip}
                        </p>
                      </div>
                    </div>

                    {/* Card Bottom Actions */}
                    <div className="px-4 py-2.5 border-t border-[#30363d] bg-[#0d1117] flex items-center justify-between">
                      <div className="flex items-center space-x-1">
                        {formula.tags.map((tag) => (
                          <span
                            key={tag}
                            className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-gray-400"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>

                      <div className="flex items-center space-x-2">
                        {onAskStudyBuddy && (
                          <button
                            onClick={() => onAskStudyBuddy(formula)}
                            className="flex items-center space-x-1 text-[11px] text-sky-400 hover:text-sky-300 transition-colors font-medium cursor-pointer"
                          >
                            <Sparkles className="w-3 h-3" />
                            <span>Solve in AI Buddy</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* VIEW MODE 2: Comprehensive Shorthand Chapter Cheat Sheets */}
      {viewMode === 'shorthand' && activeCheatSheet && (
        <div className="space-y-6 print:m-0 print:p-0">
          {/* Chapter Hero Card */}
          <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#30363d] pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="px-2 py-0.5 rounded text-xs font-mono font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
                    {activeCheatSheet.subject} · {activeCheatSheet.grade}
                  </span>
                  <span className="text-xs text-gray-400 font-mono">
                    Chapter {activeCheatSheet.chapterNumber} Master Sheet
                  </span>
                </div>
                <h3 className="text-xl font-bold text-white mt-1">
                  {activeCheatSheet.chapter}
                </h3>
                <p className="text-xs text-gray-400 mt-1 max-w-2xl leading-relaxed">
                  {activeCheatSheet.description}
                </p>
              </div>

              <div className="flex items-center space-x-2 shrink-0">
                <span className="px-2.5 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono font-semibold">
                  {activeCheatSheet.coreFormulas.length} Core Formulas
                </span>
                <span className="px-2.5 py-1 rounded bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-mono font-semibold">
                  {activeCheatSheet.speedTricksAndEliminations.length} Speed Tricks
                </span>
              </div>
            </div>

            {/* Standard Constants Strip */}
            {activeCheatSheet.standardConstants.length > 0 && (
              <div className="mt-4 pt-1">
                <span className="text-[11px] font-mono text-gray-400 uppercase tracking-wider">
                  Standard Constants & Benchmarks:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 mt-1.5">
                  {activeCheatSheet.standardConstants.map((sc, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded bg-[#0d1117] border border-[#30363d] flex items-center justify-between text-xs"
                    >
                      <span className="text-gray-300">{sc.name}:</span>
                      <span className="font-mono font-bold text-amber-300 ml-2">
                        {sc.value} {sc.unit || ''}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Section A: Core Formulas (All 15+ Equations) */}
          <div className="rounded-xl border border-[#30363d] bg-[#161b22] overflow-hidden">
            <div className="px-4 py-3 bg-[#1c2128] border-b border-[#30363d] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-sky-400" />
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  Core Equation Vault (15+ High-Yield Formulas)
                </h4>
              </div>
              <span className="text-xs text-gray-400 font-mono">
                Click any formula to reveal in Active Recall mode
              </span>
            </div>

            <div className="divide-y divide-[#30363d]">
              {activeCheatSheet.coreFormulas.map((f, idx) => {
                const sheetFId = `${activeCheatSheet.id}-formula-${idx}`;
                const isRevealed = !activeRecallMode || revealedIds.has(sheetFId);

                return (
                  <div
                    key={idx}
                    className="p-4 hover:bg-[#1c2128]/50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="space-y-1 md:max-w-md">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-mono font-bold text-sky-400">
                          #{idx + 1}
                        </span>
                        <h5 className="text-sm font-bold text-[#e6edf3]">{f.title}</h5>
                      </div>
                      <p className="text-xs text-gray-400 leading-relaxed">{f.meaning}</p>
                      <p className="text-[11px] font-mono text-gray-500">{f.variables}</p>
                    </div>

                    {/* Equation with Active Recall */}
                    <div className="grow md:max-w-md flex flex-col items-center">
                      <div
                        onClick={() => toggleReveal(sheetFId)}
                        className={`w-full p-2.5 rounded-lg bg-[#0d1117] border border-[#30363d] text-center overflow-x-auto cursor-pointer transition-colors ${
                          !isRevealed ? 'hover:border-amber-500' : ''
                        }`}
                      >
                        {isRevealed ? (
                          <MathView math={f.latex} block />
                        ) : (
                          <div className="py-2 flex items-center justify-center space-x-1.5 text-xs text-amber-400 font-medium">
                            <Eye className="w-3.5 h-3.5" />
                            <span>Click to Reveal Equation #{idx + 1}</span>
                          </div>
                        )}
                      </div>

                      {f.speedTrick && (
                        <div className="mt-1.5 w-full flex items-start space-x-1 text-[11px] text-amber-300/90 font-medium">
                          <Zap className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                          <span>Trick: {f.speedTrick}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Section B: Identities & Transforms + Speed Tricks */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Identities & Transforms */}
            <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-4 space-y-3">
              <div className="flex items-center space-x-2 text-indigo-400">
                <Lightbulb className="w-4 h-4" />
                <h4 className="text-sm font-bold text-white">
                  Identities & Fast Transformations
                </h4>
              </div>
              <div className="space-y-2.5">
                {activeCheatSheet.identitiesAndTransforms.map((it, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold text-gray-200">{it.title}</span>
                      <span className="text-[10px] text-gray-400">{it.note}</span>
                    </div>
                    <div className="overflow-x-auto text-sky-300 text-sm">
                      <MathView math={it.latex} block />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Speed Tricks & Elimination Hacks */}
            <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-4 space-y-3">
              <div className="flex items-center space-x-2 text-amber-400">
                <Zap className="w-4 h-4" />
                <h4 className="text-sm font-bold text-white">
                  Speed Tricks & Elimination Hacks
                </h4>
              </div>
              <div className="space-y-2.5">
                {activeCheatSheet.speedTricksAndEliminations.map((st, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-[#0d1117] border border-amber-500/30 space-y-1"
                  >
                    <span className="text-xs font-bold text-amber-300">{st.rule}</span>
                    <p className="text-xs text-gray-400">
                      <strong className="text-gray-300">Context: </strong>
                      {st.example}
                    </p>
                    <p className="text-xs text-emerald-300 font-mono">
                      <strong>Hack: </strong>
                      {st.shortcut}
                    </p>
                  </div>
                ))}

                {/* Common Traps */}
                {activeCheatSheet.commonTraps.length > 0 && (
                  <div className="p-3 rounded-lg bg-red-950/20 border border-red-800/40 space-y-1">
                    <div className="flex items-center space-x-1 text-red-400 text-xs font-bold">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>Exam Traps to Avoid:</span>
                    </div>
                    <ul className="list-disc pl-4 space-y-0.5 text-xs text-red-200/90">
                      {activeCheatSheet.commonTraps.map((trap, idx) => (
                        <li key={idx}>{trap}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
