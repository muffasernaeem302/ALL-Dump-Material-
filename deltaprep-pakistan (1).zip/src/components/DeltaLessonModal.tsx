import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, BookOpen, HelpCircle, CheckCircle2, XCircle, Award, ArrowRight, ArrowLeft, Lightbulb, Copy, Check } from 'lucide-react';
import confetti from 'canvas-confetti';
import { DeltaTopic, MicroQuizItem } from '../types';

interface DeltaLessonModalProps {
  topic: DeltaTopic | null;
  onClose: () => void;
  onMarkCompleted: (topicId: string) => void;
  isAlreadyCompleted: boolean;
}

export const DeltaLessonModal: React.FC<DeltaLessonModalProps> = ({
  topic,
  onClose,
  onMarkCompleted,
  isAlreadyCompleted,
}) => {
  if (!topic) return null;

  const [activeTab, setActiveTab] = useState<'lesson' | 'quiz'>('lesson');
  const [currentQuizIndex, setCurrentQuizIndex] = useState<number>(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [copiedFormula, setCopiedFormula] = useState<boolean>(false);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const microQuestions = topic.lesson.microQuiz;
  const currentQuestion: MicroQuizItem | undefined = microQuestions[currentQuizIndex];

  const handleSelectOption = (optionIndex: number) => {
    if (selectedAnswers[currentQuizIndex] !== undefined) return; // already answered
    const nextAnswers = { ...selectedAnswers, [currentQuizIndex]: optionIndex };
    setSelectedAnswers(nextAnswers);

    // If last question answered, check finish
    if (Object.keys(nextAnswers).length === microQuestions.length) {
      setQuizFinished(true);
      const correctCount = microQuestions.filter(
        (q, idx) => nextAnswers[idx] === q.correctAnswer
      ).length;
      if (correctCount >= 2) {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
        onMarkCompleted(topic.id);
      }
    }
  };

  const handleCopyFormula = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFormula(true);
    setTimeout(() => setCopiedFormula(false), 2000);
  };

  const quizCorrectCount = microQuestions.filter(
    (q, idx) => selectedAnswers[idx] === q.correctAnswer
  ).length;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-xs overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.15 }}
          className="relative w-full max-w-3xl bg-[#161b22] border border-[#30363d] rounded-lg shadow-xl overflow-hidden my-3 text-[#e6edf3]"
        >
          {/* Header */}
          <div className="px-4 py-3 border-b border-[#30363d] bg-[#0d1117] flex items-start justify-between">
            <div className="space-y-1">
              <div className="flex items-center space-x-1.5">
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-sky-500/15 border border-sky-500/30 text-sky-400">
                  {topic.subject}
                </span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider ${
                    topic.importance === 'Critical'
                      ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                      : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  {topic.importance} Delta
                </span>
                <span className="text-[11px] text-gray-400 font-mono">
                  {topic.expectedMarks}
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-white leading-snug">
                {topic.title}
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded text-gray-400 hover:text-white hover:bg-slate-800 transition-colors ml-2 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Tabs */}
          <div className="flex border-b border-[#30363d] bg-[#0d1117]/60 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('lesson')}
              className={`flex-1 py-2 px-3 flex items-center justify-center space-x-1.5 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'lesson'
                  ? 'border-sky-500 text-sky-400 bg-sky-500/5'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>5-Min Gap Fill Lesson</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('quiz')}
              className={`flex-1 py-2 px-3 flex items-center justify-center space-x-1.5 border-b-2 transition-colors cursor-pointer ${
                activeTab === 'quiz'
                  ? 'border-sky-500 text-sky-400 bg-sky-500/5'
                  : 'border-transparent text-gray-400 hover:text-gray-200'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Micro-Quiz Drill ({Object.keys(selectedAnswers).length}/3 Completed)</span>
            </button>
          </div>

          {/* Tab Content */}
          <div className="p-4 max-h-[68vh] overflow-y-auto space-y-4">
            {activeTab === 'lesson' ? (
              <div className="space-y-4">
                {/* Headline Gap Alert */}
                <div className="p-3 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-200 space-y-1">
                  <div className="flex items-center space-x-1.5 text-[11px] font-bold uppercase tracking-wider text-amber-400">
                    <Lightbulb className="w-3.5 h-3.5" />
                    <span>The Missing Knowledge Trap</span>
                  </div>
                  <p className="text-xs font-semibold text-white">{topic.headlineDifference}</p>
                  <p className="text-[11px] text-gray-300 leading-relaxed">{topic.whyBoardMissing}</p>
                </div>

                {/* Textbook Comparison Matrix */}
                <div className="space-y-1.5">
                  <h4 className="text-[11px] font-mono font-semibold uppercase tracking-wider text-gray-400">
                    Curriculum Divergence Breakdown
                  </h4>
                  <div className="grid grid-cols-1 gap-1.5">
                    {topic.lesson.textbookComparison.map((comp, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-md border border-[#30363d] bg-[#0d1117] flex flex-col sm:flex-row sm:items-start justify-between gap-1.5"
                      >
                        <div className="flex items-center space-x-1.5 sm:w-1/3">
                          <span className="text-xs font-semibold text-gray-200">{comp.board}</span>
                          <span
                            className={`px-1.5 py-0.2 rounded text-[9px] font-mono font-bold uppercase ${
                              comp.status === 'Included'
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                : comp.status === 'Missing'
                                ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                                : comp.status === 'Contradictory'
                                ? 'bg-purple-500/15 text-purple-400 border border-purple-500/30'
                                : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                            }`}
                          >
                            {comp.status}
                          </span>
                        </div>
                        <p className="text-[11px] text-gray-300 sm:w-2/3 leading-relaxed">
                          {comp.detail}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* High Yield Bullet Points */}
                <div className="space-y-1.5">
                  <h4 className="text-[11px] font-mono font-semibold uppercase tracking-wider text-sky-400">
                    High-Yield Exam Points (Read in 2 Minutes)
                  </h4>
                  <div className="space-y-1.5">
                    {topic.lesson.highYieldBulletPoints.map((point, idx) => (
                      <div
                        key={idx}
                        className="flex items-start space-x-2 p-2 rounded-md bg-[#0d1117] border border-[#30363d] text-xs text-gray-200"
                      >
                        <div className="w-4 h-4 rounded bg-sky-500/15 text-sky-400 flex items-center justify-center flex-shrink-0 text-[10px] font-mono font-bold">
                          {idx + 1}
                        </div>
                        <p className="text-[11px] leading-relaxed">{point}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Formula / Key Rule callout */}
                {topic.lesson.formulaOrKeyRule && (
                  <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] relative group">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-gray-400">
                        High-Yield Rule / Formula
                      </span>
                      <button
                        onClick={() => handleCopyFormula(topic.lesson.formulaOrKeyRule!)}
                        className="flex items-center space-x-1 text-[10px] text-gray-400 hover:text-sky-400 transition-colors cursor-pointer"
                      >
                        {copiedFormula ? (
                          <>
                            <Check className="w-3 h-3 text-sky-400" />
                            <span className="text-sky-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                    <code className="block mt-1.5 font-mono text-xs text-sky-300 leading-relaxed">
                      {topic.lesson.formulaOrKeyRule}
                    </code>
                  </div>
                )}

                {/* Pro Exam Tip */}
                <div className="p-3 rounded-md bg-sky-500/10 border border-sky-500/25 text-xs text-gray-200 flex items-start space-x-2">
                  <div className="p-1 rounded bg-sky-500/20 text-sky-400 flex-shrink-0">
                    <Award className="w-3.5 h-3.5" />
                  </div>
                  <div className="text-[11px] leading-relaxed">
                    <span className="font-bold text-white">Examiner Mindset Tip: </span>
                    {topic.lesson.proExamTip}
                  </div>
                </div>
              </div>
            ) : (
              /* Micro-Quiz Drill tab */
              <div className="space-y-4">
                {quizFinished ? (
                  /* Quiz Completion Banner */
                  <div className="p-5 rounded-lg bg-[#0d1117] border border-[#30363d] text-center space-y-3">
                    <div className="w-11 h-11 mx-auto rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
                      <Award className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Micro-Quiz Completed!</h4>
                      <p className="text-[11px] text-gray-400 mt-0.5">
                        You scored {quizCorrectCount} out of {microQuestions.length} on this Delta Topic drill.
                      </p>
                    </div>

                    <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-md bg-[#161b22] border border-[#30363d] text-xs font-semibold">
                      <span className="text-gray-400">Status:</span>
                      <span className={quizCorrectCount >= 2 ? 'text-emerald-400' : 'text-amber-400'}>
                        {quizCorrectCount >= 2 ? 'Mastered & Verified' : 'Review Recommended'}
                      </span>
                    </div>

                    <div className="pt-1 flex flex-col sm:flex-row items-center justify-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedAnswers({});
                          setQuizFinished(false);
                          setCurrentQuizIndex(0);
                        }}
                        className="w-full sm:w-auto px-3.5 py-1.5 rounded-md bg-[#161b22] hover:bg-slate-700 border border-[#30363d] text-xs font-semibold text-gray-200 transition-colors cursor-pointer"
                      >
                        Retake Quiz
                      </button>
                      <button
                        onClick={() => {
                          onMarkCompleted(topic.id);
                          onClose();
                        }}
                        className="w-full sm:w-auto px-4 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-sm"
                      >
                        Mark Delta Mastered
                      </button>
                    </div>
                  </div>
                ) : null}

                {/* Question Card */}
                {currentQuestion && (
                  <div className="space-y-3">
                    {/* Stepper bar */}
                    <div className="flex items-center justify-between text-[11px] text-gray-400">
                      <span>
                        Question <strong className="text-white">{currentQuizIndex + 1}</strong> of{' '}
                        {microQuestions.length}
                      </span>
                      <span className="font-mono text-gray-400">
                        Target pace: ~{currentQuestion.timeTargetSeconds}s
                      </span>
                    </div>

                    <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d]">
                      <div className="text-[10px] font-mono text-sky-400 mb-1 flex items-center space-x-1">
                        <span>Origin:</span>
                        <span className="text-gray-300">{currentQuestion.boardOrigin}</span>
                      </div>
                      <h4 className="text-xs sm:text-sm font-semibold text-white leading-relaxed">
                        {currentQuestion.question}
                      </h4>
                    </div>

                    {/* Options list */}
                    <div className="space-y-1.5">
                      {currentQuestion.options.map((option, optIdx) => {
                        const hasSelected = selectedAnswers[currentQuizIndex] !== undefined;
                        const isSelected = selectedAnswers[currentQuizIndex] === optIdx;
                        const isCorrectOption = optIdx === currentQuestion.correctAnswer;

                        let style =
                          'bg-[#0d1117] border-[#30363d] hover:border-slate-600 text-gray-200';
                        if (hasSelected) {
                          if (isCorrectOption) {
                            style = 'bg-emerald-500/15 border-emerald-500/60 text-emerald-200';
                          } else if (isSelected) {
                            style = 'bg-red-500/15 border-red-500/60 text-red-200';
                          } else {
                            style = 'bg-[#0d1117]/60 border-[#30363d] opacity-40 text-gray-400';
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            disabled={hasSelected}
                            onClick={() => handleSelectOption(optIdx)}
                            className={`w-full text-left p-2.5 rounded-md border text-xs transition-colors flex items-start space-x-2.5 cursor-pointer ${style}`}
                          >
                            <span className="w-4 h-4 rounded bg-[#161b22] border border-[#30363d] flex items-center justify-center font-mono text-[10px] flex-shrink-0 text-gray-300">
                              {String.fromCharCode(65 + optIdx)}
                            </span>
                            <span className="flex-1 leading-snug">{option}</span>
                            {hasSelected && isCorrectOption && (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                            )}
                            {hasSelected && isSelected && !isCorrectOption && (
                              <XCircle className="w-3.5 h-3.5 text-red-400 flex-shrink-0" />
                            )}
                          </button>
                        );
                      })}
                    </div>

                    {/* Instant Explanation Callout */}
                    {selectedAnswers[currentQuizIndex] !== undefined && (
                      <motion.div
                        initial={{ opacity: 0, y: 5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={`p-3 rounded-md border text-xs leading-relaxed space-y-1 ${
                          selectedAnswers[currentQuizIndex] === currentQuestion.correctAnswer
                            ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                            : 'bg-red-950/20 border-red-500/30 text-red-200'
                        }`}
                      >
                        <div className="font-bold flex items-center space-x-1.5 text-[11px]">
                          {selectedAnswers[currentQuizIndex] === currentQuestion.correctAnswer ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-400">Correct! Great catch.</span>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-3.5 h-3.5 text-red-400" />
                              <span className="text-red-400">Classic Board Delta Trap!</span>
                            </>
                          )}
                        </div>
                        <p className="text-[11px] text-gray-200">{currentQuestion.explanation}</p>
                      </motion.div>
                    )}

                    {/* Pagination Buttons */}
                    <div className="flex items-center justify-between pt-1">
                      <button
                        type="button"
                        disabled={currentQuizIndex === 0}
                        onClick={() => setCurrentQuizIndex((prev) => Math.max(0, prev - 1))}
                        className="px-2.5 py-1 rounded border border-[#30363d] bg-[#0d1117] disabled:opacity-30 text-xs text-gray-300 hover:bg-[#161b22] flex items-center space-x-1 cursor-pointer"
                      >
                        <ArrowLeft className="w-3 h-3" />
                        <span>Previous</span>
                      </button>

                      <div className="flex space-x-1.5">
                        {microQuestions.map((_, qIdx) => (
                          <button
                            key={qIdx}
                            onClick={() => setCurrentQuizIndex(qIdx)}
                            className={`w-2 h-2 rounded-full transition-colors cursor-pointer ${
                              currentQuizIndex === qIdx
                                ? 'bg-sky-400 scale-125'
                                : selectedAnswers[qIdx] !== undefined
                                ? 'bg-gray-500'
                                : 'bg-gray-700'
                            }`}
                          />
                        ))}
                      </div>

                      <button
                        type="button"
                        disabled={currentQuizIndex === microQuestions.length - 1}
                        onClick={() =>
                          setCurrentQuizIndex((prev) => Math.min(microQuestions.length - 1, prev + 1))
                        }
                        className="px-2.5 py-1 rounded border border-[#30363d] bg-[#0d1117] disabled:opacity-30 text-xs text-gray-300 hover:bg-[#161b22] flex items-center space-x-1 cursor-pointer"
                      >
                        <span>Next</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="px-4 py-2.5 border-t border-[#30363d] bg-[#0d1117] flex items-center justify-between">
            <div className="text-[11px] text-gray-400">
              {isAlreadyCompleted ? (
                <span className="flex items-center space-x-1 text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Topic marked as studied</span>
                </span>
              ) : (
                <span>Complete notes & micro-drill to fill syllabus gap</span>
              )}
            </div>

            <div className="flex items-center space-x-2">
              {activeTab === 'lesson' ? (
                <button
                  type="button"
                  onClick={() => setActiveTab('quiz')}
                  className="flex items-center space-x-1 px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs transition-colors cursor-pointer"
                >
                  <span>Test in 3 Questions</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setActiveTab('lesson')}
                  className="px-2.5 py-1.5 rounded-md text-gray-400 hover:text-white text-xs transition-colors cursor-pointer"
                >
                  Review Lesson Notes
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
