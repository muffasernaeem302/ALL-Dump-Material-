import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Compass,
  AlertTriangle,
  Zap,
  BookOpen,
  CheckCircle2,
  Filter,
  Search,
  ExternalLink,
  ArrowRight,
  Sparkles,
  Flame,
  ShieldCheck,
  ChevronRight,
} from 'lucide-react';
import { BoardId, ExamId, DeltaTopic, Subject } from '../types';
import { BOARDS, EXAMS, DELTA_TOPICS } from '../data';

interface DeltaDashboardProps {
  homeBoard: BoardId;
  targetExam: ExamId;
  completedDeltaLessons: string[];
  onOpenTopicModal: (topic: DeltaTopic) => void;
  onOpenProfileModal: () => void;
  onStartQuizMode: () => void;
}

export const DeltaDashboard: React.FC<DeltaDashboardProps> = ({
  homeBoard,
  targetExam,
  completedDeltaLessons,
  onOpenTopicModal,
  onOpenProfileModal,
  onStartQuizMode,
}) => {
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const currentBoard = BOARDS.find((b) => b.id === homeBoard) || BOARDS[0];
  const currentExam = EXAMS.find((e) => e.id === targetExam) || EXAMS[0];

  // Filter delta topics applicable to current board & exam or general
  const filteredTopics = DELTA_TOPICS.filter((topic) => {
    // Subject filter
    if (selectedSubject !== 'All' && topic.subject !== selectedSubject) {
      return false;
    }
    // Search filter
    if (
      searchQuery &&
      !topic.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !topic.headlineDifference.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !topic.subject.toLowerCase().includes(searchQuery.toLowerCase())
    ) {
      return false;
    }
    return true;
  });

  const totalTopics = DELTA_TOPICS.length;
  const completedCount = completedDeltaLessons.length;
  const readinessPercentage = Math.round((completedCount / totalTopics) * 100);

  const subjects: ('All' | Subject)[] = ['All', 'Mathematics', 'Physics', 'Chemistry', 'Biology'];

  return (
    <div className="space-y-4 pb-12 text-[#e6edf3]">
      {/* 3 High Density Top Metric Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-[#161b22] border border-[#30363d] p-3.5 rounded-lg shadow-sm">
          <div className="text-[11px] text-gray-400 uppercase font-mono tracking-wider mb-1 flex items-center justify-between">
            <span>Syllabus Gap</span>
            <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
              {currentBoard.shortCode} → {currentExam.shortName}
            </span>
          </div>
          <div className="text-2xl font-bold text-amber-400 font-mono">
            {totalTopics} Delta Topics
          </div>
          <div className="text-[11px] text-gray-400 mt-1 truncate">
            {currentExam.primarySyllabusBasis}
          </div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-3.5 rounded-lg shadow-sm">
          <div className="text-[11px] text-gray-400 uppercase font-mono tracking-wider mb-1 flex items-center justify-between">
            <span>Pace Target</span>
            <span className="text-[10px] text-sky-400 bg-sky-500/10 px-1.5 py-0.5 rounded border border-sky-500/20">
              {currentExam.totalQuestions} MCQs
            </span>
          </div>
          <div className="text-2xl font-bold text-sky-400 font-mono">
            {currentExam.avgTimePerQuestionSeconds}s <span className="text-xs font-normal text-gray-400 font-sans">/ pace</span>
          </div>
          <div className="text-[11px] text-gray-400 mt-1">
            Target: {currentExam.avgTimePerQuestionSeconds}s ({currentExam.shortName} Efficiency)
          </div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] p-3.5 rounded-lg shadow-sm">
          <div className="text-[11px] text-gray-400 uppercase font-mono tracking-wider mb-1 flex items-center justify-between">
            <span>Preparation Status</span>
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
              {completedCount}/{totalTopics} Gaps
            </span>
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono">
            {readinessPercentage}% <span className="text-xs font-normal text-gray-400 font-sans">Exam Ready</span>
          </div>
          <div className="w-full bg-[#0d1117] h-1.5 rounded-full mt-2 overflow-hidden border border-[#30363d]">
            <div
              className="bg-emerald-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${readinessPercentage}%` }}
            />
          </div>
        </div>
      </section>

      {/* Dynamic Syllabus Gap Analysis Hero Card */}
      <div className="rounded-lg border border-[#30363d] bg-[#161b22] p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2.5 max-w-2xl">
            <div className="inline-flex items-center space-x-2 px-2 py-0.5 rounded bg-sky-500/10 border border-sky-500/20 text-sky-400 text-xs font-mono font-medium">
              <Zap className="w-3.5 h-3.5" />
              <span>Dual-Syllabus "Delta Engine" Active</span>
            </div>

            <h1 className="text-lg sm:text-xl md:text-2xl font-bold text-[#e6edf3] tracking-tight leading-tight">
              Syllabus Divergence: <span className="text-sky-400 font-semibold">{currentBoard.name}</span>
              <span className="text-gray-500 font-normal mx-2">vs.</span>
              <span className="text-white underline decoration-sky-500/40 decoration-2 underline-offset-4">
                {currentExam.name}
              </span>
            </h1>

            <p className="text-xs text-gray-300 leading-relaxed">
              Target exam questions are authored against{' '}
              <strong className="text-sky-300 font-semibold">{currentExam.primarySyllabusBasis}</strong>.
              Students from {currentBoard.province} regularly drop percentile marks on textbook discrepancies in
              calculus shortcuts, nomenclature conventions, and specialized bioenergetics concepts.
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-[11px] text-gray-400 font-mono">Exam Parameters:</span>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-[#0d1117] border border-[#30363d] text-gray-300">
                {currentExam.totalQuestions} MCQs ({currentExam.totalTimeMinutes}m)
              </span>
              <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-[#0d1117] border border-[#30363d] text-gray-300">
                ~{currentExam.avgTimePerQuestionSeconds}s Target Pace
              </span>
              {currentExam.negativeMarkingRate > 0 ? (
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-red-500/10 border border-red-500/30 text-red-400 font-medium">
                  ⚠️ -{currentExam.negativeMarkingRate} Penalty Marking
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                  ✓ Zero Negative Marking
                </span>
              )}
            </div>
          </div>

          {/* Quick Actions Panel */}
          <div className="w-full lg:w-64 flex-shrink-0 p-3.5 rounded-lg bg-[#0d1117] border border-[#30363d] flex flex-col justify-between space-y-3">
            <div>
              <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                <span>Coverage</span>
                <span className="font-mono font-bold text-sky-400">{readinessPercentage}%</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 transition-all duration-300 rounded-full"
                  style={{ width: `${readinessPercentage}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[10px] text-gray-500 mt-1 font-mono">
                <span>{completedCount} Mastered</span>
                <span>{totalTopics - completedCount} Gaps Left</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <button
                type="button"
                onClick={onStartQuizMode}
                className="w-full flex items-center justify-center space-x-1.5 py-2 px-3 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition-colors shadow-sm cursor-pointer"
              >
                <Flame className="w-3.5 h-3.5 text-amber-300" />
                <span>Launch Risk Simulator</span>
              </button>
              <button
                type="button"
                onClick={onOpenProfileModal}
                className="w-full py-1.5 px-3 rounded-md text-[11px] text-gray-400 hover:text-white hover:bg-slate-800 transition-colors text-center border border-transparent hover:border-[#30363d]"
              >
                Switch Board or Exam →
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 pt-1">
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
          {subjects.map((subj) => (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                selectedSubject === subj
                  ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30 font-semibold'
                  : 'bg-[#161b22] border border-[#30363d] text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search delta topics & traps..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-md bg-[#0d1117] border border-[#30363d] text-gray-200 placeholder-gray-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Delta Topics Section */}
      <section className="bg-[#161b22] border border-[#30363d] rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-base sm:text-lg flex items-center gap-2 text-[#e6edf3]">
            <span className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></span>
            <span>Delta Engine: Priority Gaps</span>
          </h2>
          <span className="text-xs bg-[#0d1117] border border-[#30363d] px-2.5 py-1 rounded text-gray-300 font-mono">
            {currentBoard.shortCode} → {currentExam.shortName}
          </span>
        </div>

        <div className="space-y-2.5">
          {filteredTopics.map((topic) => {
            const isCompleted = completedDeltaLessons.includes(topic.id);

            // High Density subject badges
            const subjectCode =
              topic.subject === 'Mathematics'
                ? 'MATH'
                : topic.subject === 'Physics'
                ? 'PHYS'
                : topic.subject === 'Chemistry'
                ? 'CHEM'
                : 'BIO';

            const badgeBg =
              topic.subject === 'Mathematics'
                ? 'bg-amber-500/20 text-amber-400'
                : topic.subject === 'Physics'
                ? 'bg-sky-500/20 text-sky-400'
                : topic.subject === 'Chemistry'
                ? 'bg-purple-500/20 text-purple-400'
                : 'bg-emerald-500/20 text-emerald-400';

            return (
              <div
                key={topic.id}
                className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-[#0d1117] border border-[#30363d] rounded-md transition-colors ${
                  isCompleted ? 'opacity-85 border-emerald-500/30' : 'hover:border-slate-600'
                }`}
              >
                <div className="flex items-start sm:items-center gap-3 flex-1 min-w-0">
                  <div
                    className={`w-11 h-11 rounded-md flex-shrink-0 flex items-center justify-center font-bold text-xs font-mono ${badgeBg}`}
                  >
                    {subjectCode}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 flex-wrap gap-y-1">
                      <span className="text-sm font-semibold text-[#e6edf3] truncate">
                        {topic.title}
                      </span>
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-medium ${
                          topic.importance === 'Critical'
                            ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                            : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                        }`}
                      >
                        {topic.importance}
                      </span>
                      <span className="text-[10px] font-mono text-gray-500">
                        {topic.expectedMarks}
                      </span>
                      {isCompleted && (
                        <span className="text-[10px] text-emerald-400 flex items-center space-x-1 font-mono">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Mastered</span>
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-400 mt-0.5 line-clamp-1">
                      {topic.headlineDifference}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 flex-shrink-0 self-end sm:self-center">
                  <button
                    type="button"
                    onClick={() => onOpenTopicModal(topic)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors cursor-pointer ${
                      isCompleted
                        ? 'bg-slate-800 hover:bg-slate-700 text-gray-300 border border-slate-700'
                        : 'bg-sky-600 hover:bg-sky-500 text-white shadow-sm'
                    }`}
                  >
                    {isCompleted ? 'Review' : '5-Min Gap Fill'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* High Density Risk Simulator & Admission Odds Row (From Design HTML) */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="bg-[#161b22] border border-[#30363d] rounded-lg p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono flex items-center space-x-1.5">
              <span>Risk Simulator Analysis</span>
            </h3>
            <span className="text-[10px] font-mono text-sky-400">Pacing Profile</span>
          </div>

          <div className="flex items-end gap-1 h-16 pt-2 pb-1">
            <div className="flex-1 bg-sky-500/20 h-[50%] rounded-t-sm" title="Q1: 22s" />
            <div className="flex-1 bg-sky-500/30 h-[70%] rounded-t-sm" title="Q2: 35s" />
            <div className="flex-1 bg-sky-500 h-[85%] rounded-t-sm" title="Q3: 42s" />
            <div className="flex-1 bg-red-500 h-[100%] rounded-t-sm" title="Q4: 95s (Time Sink)" />
            <div className="flex-1 bg-sky-500/40 h-[45%] rounded-t-sm" title="Q5: 20s" />
            <div className="flex-1 bg-sky-500/30 h-[60%] rounded-t-sm" title="Q6: 30s" />
            <div className="flex-1 bg-emerald-500 h-[65%] rounded-t-sm" title="Q7: 32s (Optimal)" />
          </div>

          <div className="text-[11px] text-red-400 flex items-center gap-1.5 font-mono pt-1 border-t border-[#30363d]/60">
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
            <span>Time-Sink Alert: Complex math integration problems taking &gt;60s</span>
          </div>
        </div>

        <div className="bg-[#161b22] border border-[#30363d] rounded-lg p-3.5 space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono">
              Admission Odds Projections
            </h3>
            <span className="text-[10px] font-mono text-gray-500">2024 Benchmark</span>
          </div>

          <div className="space-y-1.5 text-xs">
            <div className="flex justify-between items-center py-1 px-2 rounded bg-[#0d1117] border border-[#30363d]">
              <span className="text-gray-400">NUST CS (SEECS Islamabad)</span>
              <span className="text-emerald-400 font-semibold font-mono text-[11px]">Highly Likely (~81.2%)</span>
            </div>
            <div className="flex justify-between items-center py-1 px-2 rounded bg-[#0d1117] border border-[#30363d]">
              <span className="text-gray-400">FAST CS (Lahore / Islamabad)</span>
              <span className="text-amber-400 font-semibold font-mono text-[11px]">Competitive (~75.8%)</span>
            </div>
            <div className="flex justify-between items-center py-1 px-2 rounded bg-[#0d1117] border border-[#30363d]">
              <span className="text-gray-400">COMSATS CS (Islamabad / Lahore)</span>
              <span className="text-emerald-400 font-semibold font-mono text-[11px]">Safe Margin (&gt;84%)</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

