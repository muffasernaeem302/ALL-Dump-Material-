import React from 'react';
import { Lightbulb, ShieldAlert, Zap, BookOpen, CheckCircle2, Clock } from 'lucide-react';

export const StrategyGuide: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-16 text-[#e6edf3]">
      {/* Hero Header */}
      <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] shadow-sm space-y-1.5">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-md bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Lightbulb className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-bold text-white">
              Pakistani Entrance Exam Playbook
            </h1>
            <p className="text-xs text-gray-400">
              Tactical blueprints for NUST (NET), FAST NU-Test, PMDC MDCAT, and COMSATS NAT.
            </p>
          </div>
        </div>
      </div>

      {/* Grid of Strategy Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* FAST Negative Marking Card */}
        <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-2.5">
          <div className="flex items-center space-x-1.5 text-[11px] font-mono font-bold uppercase tracking-wider text-red-400">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>The FAST Negative Marking Math</span>
          </div>
          <h3 className="text-sm font-bold text-white">
            When to Guess vs. When to Skip (-0.25 Penalty)
          </h3>
          <p className="text-xs text-gray-300 leading-relaxed">
            FAST deducts <strong className="text-white">0.25 marks</strong> for each wrong answer. If you can eliminate 2 options
            out of 4, your expected value is:
          </p>
          <div className="p-2.5 rounded-md bg-[#0d1117] border border-[#30363d] font-mono text-[11px] text-emerald-400">
            E = (0.50 × +1.0) + (0.50 × -0.25) = +0.375 marks (PROFITABLE GUESS)
          </div>
          <p className="text-xs text-gray-400 leading-relaxed">
            However, if you have <strong className="text-white">zero clues</strong> and guess blindly among 4 choices:
          </p>
          <div className="p-2.5 rounded-md bg-[#0d1117] border border-[#30363d] font-mono text-[11px] text-red-400">
            E = (0.25 × +1.0) + (0.75 × -0.25) = +0.0625 marks (HIGH VARIANCE RISK)
          </div>
          <p className="text-xs text-gray-300">
            Rule of thumb: If you cannot eliminate at least 1 option in 25 seconds, click{' '}
            <strong className="text-red-300">"Skip to Avoid Penalty"</strong> immediately.
          </p>
        </div>

        {/* NUST Speed Trap Card */}
        <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-2.5">
          <div className="flex items-center space-x-1.5 text-[11px] font-mono font-bold uppercase tracking-wider text-sky-400">
            <Clock className="w-3.5 h-3.5" />
            <span>NUST NET Speed Engineering</span>
          </div>
          <h3 className="text-sm font-bold text-white">
            200 Questions in 180 Minutes (54 Seconds / MCQ)
          </h3>
          <p className="text-xs text-gray-300 leading-relaxed">
            There is <strong className="text-white">zero negative marking</strong> in NUST NET. Therefore, no question should ever be left blank.
          </p>
          <div className="space-y-1.5 text-xs text-gray-300">
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span>
                <strong className="text-white">Round 1 (0 to 90 min):</strong> Solve all direct definition and 1-step numerical questions.
              </span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span>
                <strong className="text-white">Round 2 (90 to 150 min):</strong> Tackle calculus integration shortcuts and kinematics.
              </span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 flex-shrink-0" />
              <span>
                <strong className="text-white">Round 3 (Final 30 min):</strong> Eliminate 2 options and mark educated guesses for remainder.
              </span>
            </div>
          </div>
        </div>

        {/* MDCAT Provincial Divergence */}
        <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-2.5">
          <div className="flex items-center space-x-1.5 text-[11px] font-mono font-bold uppercase tracking-wider text-emerald-400">
            <BookOpen className="w-3.5 h-3.5" />
            <span>PMDC Textbook Conflict Resolution</span>
          </div>
          <h3 className="text-sm font-bold text-white">
            Federal vs. Punjab vs. Sindh Contradictions
          </h3>
          <p className="text-xs text-gray-300 leading-relaxed">
            PMDC sets questions based on the "National Curriculum", but questions are authored by examiners
            who reference either <strong className="text-white">Federal (NBF)</strong> or <strong className="text-white">Punjab (PTB)</strong> textbooks.
          </p>
          <div className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] text-xs text-gray-300 space-y-1">
            <div className="font-semibold text-white">Key Golden Rule:</div>
            <p className="text-[11px] leading-relaxed">
              In Bioenergetics (ATP yield, proton translocation, Photosystem carrier order) and Organic IUPAC names,
              examiners consistently honor the <strong className="text-emerald-300">Federal FBISE textbook formulation</strong> over provincial prints.
            </p>
          </div>
        </div>

        {/* Mental Math without Calculator */}
        <div className="p-4 rounded-lg bg-[#161b22] border border-[#30363d] space-y-2.5">
          <div className="flex items-center space-x-1.5 text-[11px] font-mono font-bold uppercase tracking-wider text-amber-400">
            <Zap className="w-3.5 h-3.5" />
            <span>Calculator-Free Mental Math Cheats</span>
          </div>
          <h3 className="text-sm font-bold text-white">
            Quick Physics Approximations
          </h3>
          <p className="text-xs text-gray-300 leading-relaxed">
            Calculators are strictly forbidden in NUST, FAST, and MDCAT. Memorize these standard shortcuts:
          </p>
          <div className="space-y-1 font-mono text-[11px] text-gray-300">
            <div className="p-2 rounded bg-[#0d1117] border border-[#30363d] flex justify-between">
              <span>g ≈ 9.8 or 10 m/s²</span>
              <span className="text-amber-400">√2 ≈ 1.414, √3 ≈ 1.732</span>
            </div>
            <div className="p-2 rounded bg-[#0d1117] border border-[#30363d] flex justify-between">
              <span>1 / (4πε₀) = 9 × 10⁹</span>
              <span className="text-amber-400">hc ≈ 2 × 10⁻²⁵ J·m ≈ 1240 eV·nm</span>
            </div>
            <div className="p-2 rounded bg-[#0d1117] border border-[#30363d] flex justify-between">
              <span>e ≈ 2.718</span>
              <span className="text-amber-400">ln(2) ≈ 0.693, log₁₀(2) ≈ 0.301</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
