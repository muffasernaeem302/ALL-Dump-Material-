import React, { useState, useEffect } from 'react';
import {
  Bookmark,
  Sparkles,
  Trash2,
  ExternalLink,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Clock,
  Layers,
} from 'lucide-react';
import { MCQQuestion, Subject } from '../types';
import { MOCK_MCQS } from '../data';
import { MathView } from './MathView';

interface BookmarksViewProps {
  onStartPractice?: (subject?: string, questionIds?: string[]) => void;
  onAskStudyBuddy?: (promptText: string) => void;
}

export const BookmarksView: React.FC<BookmarksViewProps> = ({
  onStartPractice,
  onAskStudyBuddy,
}) => {
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedExplanations, setExpandedExplanations] = useState<Record<string, boolean>>({});

  useEffect(() => {
    try {
      const stored = localStorage.getItem('deltaprep_bookmarked_ids');
      if (stored) {
        setBookmarkedIds(JSON.parse(stored));
      } else {
        // Default high-yield seed bookmarks so student has immediate value
        const seed = ['q-1', 'q-4', 'q-9', 'q-15'];
        setBookmarkedIds(seed);
        localStorage.setItem('deltaprep_bookmarked_ids', JSON.stringify(seed));
      }
    } catch (e) {
      console.error(e);
      setBookmarkedIds(['q-1', 'q-4', 'q-9']);
    }
  }, []);

  const handleRemoveBookmark = (id: string) => {
    const updated = bookmarkedIds.filter((bId) => bId !== id);
    setBookmarkedIds(updated);
    try {
      localStorage.setItem('deltaprep_bookmarked_ids', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear all bookmarked questions?')) {
      setBookmarkedIds([]);
      localStorage.setItem('deltaprep_bookmarked_ids', JSON.stringify([]));
    }
  };

  const toggleExplanation = (id: string) => {
    setExpandedExplanations((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Find questions in MOCK_MCQS or synthesized questions
  const bookmarkedQuestions = MOCK_MCQS.filter((q) => bookmarkedIds.includes(q.id));

  // Filter by subject and search
  const filteredQuestions = bookmarkedQuestions.filter((q) => {
    const matchesSubject = selectedSubject === 'All' || q.subject === selectedSubject;
    const matchesSearch =
      searchQuery.trim() === '' ||
      q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.topicName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      q.boardOrigin.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  const subjects: ('All' | Subject)[] = [
    'All',
    'Mathematics',
    'Physics',
    'Chemistry',
    'Biology',
    'Analytical & IQ',
  ];

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="h-7 w-7 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Bookmark className="w-4 h-4 fill-amber-400" />
            </div>
            <h2 className="text-lg font-bold text-[#e6edf3]">
              Bookmarked Questions & Spaced Review
            </h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
              {bookmarkedIds.length} Saved
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Revisit tough MCQs, Federal-vs-Provincial traps, and speed shortcuts you flagged during practice drills.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {bookmarkedIds.length > 0 && (
            <>
              <button
                type="button"
                onClick={handleClearAll}
                className="px-3 py-1.5 rounded text-xs font-medium text-gray-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
              >
                Clear All
              </button>
              {onStartPractice && (
                <button
                  type="button"
                  onClick={() => onStartPractice(undefined, bookmarkedIds)}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-md bg-sky-500 hover:bg-sky-600 text-white font-semibold text-xs transition-colors shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Drill Bookmarks Now</span>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
        {/* Subject Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {subjects.map((subj) => (
            <button
              key={subj}
              onClick={() => setSelectedSubject(subj)}
              className={`px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                selectedSubject === subj
                  ? 'bg-sky-500 text-white shadow-xs'
                  : 'bg-[#161b22] text-gray-300 hover:bg-slate-800 border border-[#30363d]'
              }`}
            >
              {subj}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-gray-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search topic, formula, board..."
            className="w-full bg-[#161b22] border border-[#30363d] rounded-md pl-9 pr-3 py-1.5 text-xs text-[#e6edf3] placeholder:text-gray-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Questions List */}
      {filteredQuestions.length === 0 ? (
        <div className="p-12 text-center rounded-lg border border-dashed border-[#30363d] bg-[#161b22]">
          <Bookmark className="w-10 h-10 text-gray-500 mx-auto mb-3 opacity-40" />
          <h3 className="text-sm font-semibold text-[#e6edf3]">No Bookmarks Found</h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto mt-1">
            {searchQuery
              ? `No bookmarked questions matched "${searchQuery}". Try a different keyword.`
              : 'You haven’t bookmarked any questions yet. While taking mock tests or drills, click the bookmark icon on any difficult MCQ to review it here!'}
          </p>
          {bookmarkedIds.length === 0 && (
            <button
              onClick={() => {
                const sample = ['q-1', 'q-4', 'q-9'];
                setBookmarkedIds(sample);
                localStorage.setItem('deltaprep_bookmarked_ids', JSON.stringify(sample));
              }}
              className="mt-4 px-3 py-1.5 rounded bg-[#0d1117] border border-[#30363d] hover:border-sky-500 text-xs text-sky-400 font-medium"
            >
              Load Sample High-Yield Bookmarks
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredQuestions.map((q, idx) => {
            const isExpanded = expandedExplanations[q.id];
            return (
              <div
                key={q.id}
                className="p-5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3.5 transition-colors"
              >
                {/* Meta header */}
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#0d1117] text-sky-300 border border-[#30363d]">
                      {q.subject}
                    </span>
                    <span className="text-xs text-gray-300 font-medium">{q.topicName}</span>
                    {q.deltaTagged && (
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                        Δ Delta Question
                      </span>
                    )}
                    <span className="text-[11px] text-gray-400 flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-gray-500" />
                      <span>{q.timeTargetSeconds}s target</span>
                    </span>
                  </div>

                  <div className="flex items-center space-x-2">
                    {onAskStudyBuddy && (
                      <button
                        onClick={() =>
                          onAskStudyBuddy(
                            `Please explain this bookmarked question in depth: "${q.question}" Options: ${q.options.join(', ')}. Highlight shortcut solutions.`
                          )
                        }
                        className="flex items-center space-x-1 px-2.5 py-1 rounded text-xs text-sky-400 hover:text-sky-300 bg-[#0d1117] border border-[#30363d] hover:border-sky-500/40 transition-colors"
                        title="Open AI Study Buddy"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Ask AI Buddy</span>
                      </button>
                    )}
                    <button
                      onClick={() => handleRemoveBookmark(q.id)}
                      className="p-1.5 rounded text-gray-400 hover:text-red-400 hover:bg-slate-800 transition-colors"
                      title="Remove Bookmark"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Question Statement */}
                <div className="text-sm text-[#e6edf3] font-medium leading-relaxed">
                  <MathView math={q.question} />
                </div>

                {/* Options Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {q.options.map((opt, optIdx) => {
                    const isCorrect = optIdx === q.correctAnswer;
                    return (
                      <div
                        key={optIdx}
                        className={`p-2.5 rounded text-xs flex items-center space-x-2 ${
                          isCorrect
                            ? 'bg-emerald-950/30 border border-emerald-500/50 text-emerald-200'
                            : 'bg-[#0d1117] border border-[#30363d] text-gray-300'
                        }`}
                      >
                        <span
                          className={`w-5 h-5 rounded-full flex items-center justify-center font-mono text-[11px] font-bold ${
                            isCorrect
                              ? 'bg-emerald-500 text-white'
                              : 'bg-slate-800 text-gray-400'
                          }`}
                        >
                          {String.fromCharCode(65 + optIdx)}
                        </span>
                        <span className="flex-1">
                          <MathView math={opt} />
                        </span>
                        {isCorrect && (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Explanation and Board Origin */}
                <div className="pt-2 border-t border-[#30363d]/60 flex items-center justify-between text-xs">
                  <span className="text-gray-400 text-[11px]">
                    Origin: <strong className="text-gray-300">{q.boardOrigin}</strong>
                  </span>

                  <button
                    onClick={() => toggleExplanation(q.id)}
                    className="text-xs text-sky-400 hover:text-sky-300 font-medium"
                  >
                    {isExpanded ? 'Hide Solution & KaTeX' : 'View Solution & KaTeX'}
                  </button>
                </div>

                {isExpanded && (
                  <div className="p-3.5 rounded bg-[#0d1117] border border-sky-500/20 text-xs text-gray-300 space-y-1.5 animate-in fade-in">
                    <span className="font-semibold text-sky-400 block">
                      Detailed Solution & Speed Shortcut:
                    </span>
                    <p className="leading-relaxed text-gray-200">
                      <MathView math={q.explanation} />
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
