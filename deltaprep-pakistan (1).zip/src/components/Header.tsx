import React, { useState } from 'react';
import {
  Compass,
  Layers,
  BookOpen,
  Clock,
  Sparkles,
  Calculator,
  Flame,
  Award,
  Cloud,
  CheckCircle2,
  LogIn,
  Moon,
  ChevronDown,
  Settings,
  ShieldCheck,
  User,
  Bookmark,
  History,
} from 'lucide-react';
import { BoardId, ExamId, NavTab, AuthUser } from '../types';
import { BOARDS, EXAMS } from '../data';

interface HeaderProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  homeBoard: BoardId;
  targetExam: ExamId;
  onOpenProfileModal: () => void;
  completedLessonsCount: number;
  totalDeltaLessons: number;
  authUser: AuthUser;
  onOpenAuthModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  homeBoard,
  targetExam,
  onOpenProfileModal,
  completedLessonsCount,
  totalDeltaLessons,
  authUser,
  onOpenAuthModal,
}) => {
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const boardInfo = BOARDS.find((b) => b.id === homeBoard) || BOARDS[0];
  const examInfo = EXAMS.find((e) => e.id === targetExam) || EXAMS[0];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-[#30363d] bg-[#161b22]/95 backdrop-blur-xs">
      {/* Top Bar: Brand, Target Switcher, Streak, and Auth Profile */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-14">
          {/* Logo & Tagline */}
          <div
            className="flex items-center space-x-3 cursor-pointer select-none"
            onClick={() => onSelectTab('dashboard')}
          >
            <div className="bg-sky-500 text-white font-bold px-2.5 py-1 rounded-md text-base flex items-center justify-center shadow-xs">
              Δ
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-base sm:text-lg font-bold tracking-tight text-[#e6edf3]">
                  DeltaPrep <span className="text-sky-400 font-semibold">AI</span>
                </h1>
                <span className="inline-flex items-center space-x-1 px-1.5 py-0.5 text-[10px] font-mono rounded bg-[#0d1117] border border-[#30363d] text-gray-300">
                  <Moon className="w-2.5 h-2.5 text-sky-400" />
                  <span>Dark Mode</span>
                </span>
                <span className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-mono rounded bg-sky-950/40 border border-sky-800/40 text-sky-300">
                  MDCAT · NET · FAST · COMSATS
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-gray-400">
                AI Exam Prep & Dual-Syllabus Study Assistant for Pakistani Universities
              </p>
            </div>
          </div>

          {/* Right Action Cluster: Target Switcher, Streak 🔥, Auth */}
          <div className="flex items-center space-x-2 sm:space-x-2.5">
            {/* Target Profile Switcher */}
            <button
              id="profile-switcher-btn"
              onClick={onOpenProfileModal}
              className="group flex items-center space-x-2 px-2.5 py-1.5 rounded-md border border-[#30363d] bg-[#0d1117] hover:bg-slate-800 transition-colors text-left cursor-pointer"
              title="Click to switch Home Board or Target Exam"
            >
              <div className="flex flex-col items-end">
                <span className="text-[9px] text-gray-400 uppercase font-mono tracking-wider">Target Exam</span>
                <span className="text-xs font-semibold text-[#e6edf3] flex items-center space-x-1">
                  <span className="text-sky-400 font-mono">{boardInfo.shortCode}</span>
                  <span className="text-gray-500 text-[10px]">→</span>
                  <span className="text-white">{examInfo.shortName}</span>
                </span>
              </div>
            </button>

            {/* Streak Counter 🔥 */}
            <button
              id="header-streak-btn"
              onClick={onOpenAuthModal}
              className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-md bg-[#0d1117] border border-amber-500/30 hover:border-amber-500/60 transition-colors text-xs cursor-pointer group"
              title="Daily Study Continuity Streak"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20 group-hover:scale-110 transition-transform" />
              <span className="font-mono font-bold text-amber-300 text-xs">
                {authUser.streakDays}d
              </span>
              <span className="text-[10px] text-gray-400">🔥</span>
            </button>

            {/* Google OAuth Profile Bar & Dropdown */}
            {authUser.isAuthenticated ? (
              <div className="relative">
                <button
                  id="header-user-profile-btn"
                  onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                  className="flex items-center space-x-2 px-2.5 py-1.5 rounded-md border border-[#30363d] bg-[#0d1117] hover:bg-slate-800 transition-colors cursor-pointer"
                  title="Google Account & Profile Settings"
                >
                  <div className="relative">
                    <div className="h-6 w-6 rounded-full bg-linear-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-[10px] font-bold text-white shadow-xs">
                      {authUser.name
                        .split(' ')
                        .map((n) => n[0])
                        .join('')
                        .slice(0, 2)}
                    </div>
                    <span className="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-400 border border-[#0d1117]" />
                  </div>
                  <div className="hidden sm:flex flex-col items-start leading-none text-left">
                    <span className="text-xs font-semibold text-[#e6edf3] truncate max-w-[90px]">
                      {authUser.name.split(' ')[0]}
                    </span>
                    <span className="text-[10px] text-sky-400 font-mono">
                      {authUser.xp.toLocaleString()} XP
                    </span>
                  </div>
                  <ChevronDown className="w-3 h-3 text-gray-400 hidden sm:inline-block" />
                </button>

                {/* Profile Settings Dropdown Menu */}
                {isProfileDropdownOpen && (
                  <div
                    id="profile-settings-dropdown"
                    className="absolute right-0 mt-2 w-64 rounded-lg bg-[#161b22] border border-[#30363d] shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
                  >
                    <div className="px-3.5 py-2 border-b border-[#30363d]/80">
                      <p className="text-xs font-semibold text-white">{authUser.name}</p>
                      <p className="text-[11px] text-gray-400 truncate">{authUser.email}</p>
                      <div className="mt-1.5 flex items-center space-x-1 text-[10px] text-emerald-400 font-mono">
                        <Cloud className="w-3 h-3" />
                        <span>Google Cloud Synced</span>
                      </div>
                    </div>

                    <div className="p-1 space-y-0.5">
                      <button
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          onOpenAuthModal();
                        }}
                        className="w-full flex items-center space-x-2 px-3 py-2 text-xs text-gray-200 hover:bg-slate-800 rounded-md text-left transition-colors cursor-pointer"
                      >
                        <Settings className="w-3.5 h-3.5 text-gray-400" />
                        <span>Account & Cloud Sync Settings</span>
                      </button>

                      <button
                        onClick={() => {
                          setIsProfileDropdownOpen(false);
                          onOpenProfileModal();
                        }}
                        className="w-full flex items-center space-x-2 px-3 py-2 text-xs text-gray-200 hover:bg-slate-800 rounded-md text-left transition-colors cursor-pointer"
                      >
                        <Compass className="w-3.5 h-3.5 text-sky-400" />
                        <span>Switch Board & Target Exam</span>
                      </button>

                      <div className="px-3 py-2 border-t border-[#30363d]/60 mt-1 flex items-center justify-between text-[11px] text-gray-400 font-mono">
                        <span>Total Solved XP:</span>
                        <span className="text-sky-300 font-bold">{authUser.xp} pts</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                id="header-sign-in-btn"
                onClick={onOpenAuthModal}
                className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-white hover:bg-gray-100 text-gray-950 text-xs font-semibold transition-colors"
              >
                <LogIn className="w-3 h-3 text-gray-800" />
                <span>Google Sign In</span>
              </button>
            )}
          </div>
        </div>

        {/* Primary Navigation Tabs */}
        {/* [Dashboard] | [Syllabus Explorer] | [Formula Vault & Shorthand] | [Practice & Mocks] | [AI Study Buddy] | [2025 Merit Predictor] */}
        <div className="flex items-center space-x-1 sm:space-x-1.5 overflow-x-auto py-1.5 scrollbar-none border-t border-[#30363d]/60 text-xs font-medium">
          {/* 1. Dashboard */}
          <button
            id="nav-tab-dashboard"
            onClick={() => onSelectTab('dashboard')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'dashboard'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Dashboard</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 font-mono">
              Core
            </span>
          </button>

          {/* 2. Syllabus Explorer */}
          <button
            id="nav-tab-syllabus"
            onClick={() => onSelectTab('syllabus')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'syllabus'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            <span>Syllabus Explorer</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 font-mono">
              Boards
            </span>
          </button>

          {/* 3. Formula Vault & Shorthand */}
          <button
            id="nav-tab-formulas"
            onClick={() => onSelectTab('formulas')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'formulas'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-400" />
            <span>Formula Vault & Shorthand</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
              PDF
            </span>
          </button>

          {/* 4. Practice & Mocks */}
          <button
            id="nav-tab-practice"
            onClick={() => onSelectTab('practice')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'practice'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Practice & Mocks</span>
            {examInfo.negativeMarkingRate > 0 ? (
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-red-500/20 text-red-300 font-mono">
                -0.25 Skip
              </span>
            ) : (
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                NET/MDCAT
              </span>
            )}
          </button>

          {/* 4b. Topic Mastery & Level Unlocking */}
          <button
            id="nav-tab-mastery"
            onClick={() => onSelectTab('mastery')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'mastery'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-amber-400" />
            <span>Topic Mastery</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
              L1–L3
            </span>
          </button>

          {/* 4c. Records Archive & Diagnostics */}
          <button
            id="nav-tab-records"
            onClick={() => onSelectTab('records')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'records'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <History className="w-3.5 h-3.5 text-sky-400" />
            <span>Records</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">
              Archive
            </span>
          </button>

          {/* 5. AI Study Buddy */}
          <button
            id="nav-tab-buddy"
            onClick={() => onSelectTab('buddy')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'buddy'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>AI Study Buddy</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 font-mono">
              OCR & LaTeX
            </span>
          </button>

          {/* 6. 2025 Merit Predictor */}
          <button
            id="nav-tab-analytics"
            onClick={() => onSelectTab('analytics')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'analytics'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Calculator className="w-3.5 h-3.5 text-sky-400" />
            <span>2025 Merit Predictor</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-amber-300 font-mono">
              2025 Cutoffs
            </span>
          </button>

          {/* 7. Bookmarks & Spaced Review */}
          <button
            id="nav-tab-bookmarks"
            onClick={() => onSelectTab('bookmarks')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md transition-colors whitespace-nowrap text-xs cursor-pointer ${
              currentTab === 'bookmarks'
                ? 'bg-sky-500/10 text-sky-400 border border-sky-500/20 font-semibold'
                : 'text-gray-400 hover:text-[#e6edf3] hover:bg-slate-800/80 border border-transparent'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span>Bookmarks</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
              Review
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};

