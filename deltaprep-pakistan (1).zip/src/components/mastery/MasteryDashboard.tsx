import React, { useState, useEffect, useCallback } from 'react';
import { Award, BookOpen, Layers, RefreshCw, Sparkles, Target } from 'lucide-react';
import { SubjectMasteryData } from '../../types';
import { MasteryCard } from './MasteryCard';
import { TopicProgress } from './TopicProgress';

interface MasteryDashboardProps {
  onStartLevelPractice: (subject: string, topicId: string, levelNumber: number) => void;
}

export const MasteryDashboard: React.FC<MasteryDashboardProps> = ({
  onStartLevelPractice,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [masteryData, setMasteryData] = useState<Record<string, SubjectMasteryData>>({});
  const [userTotalXP, setUserTotalXP] = useState<number>(0);
  const [activeSubjectId, setActiveSubjectId] = useState<string>('subj_physics');

  const fetchMastery = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/mastery');
      if (res.ok) {
        const data = await res.json();
        setMasteryData(data.subjects || {});
        setUserTotalXP(data.userTotalXP || 0);

        // Default to first subject if active isn't in response
        if (data.subjects && !data.subjects[activeSubjectId]) {
          const firstKey = Object.keys(data.subjects)[0];
          if (firstKey) setActiveSubjectId(firstKey);
        }
      }
    } catch (e) {
      console.error('Failed to load mastery data:', e);
    } finally {
      setLoading(false);
    }
  }, [activeSubjectId]);

  useEffect(() => {
    fetchMastery();
  }, [fetchMastery]);

  const subjectKeys = Object.keys(masteryData);
  const currentSubjectData = masteryData[activeSubjectId];

  return (
    <div className="space-y-5 max-w-7xl mx-auto px-2 sm:px-4 py-4">
      {/* Top Banner */}
      <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-md bg-emerald-500/20 text-emerald-400">
              <Award className="w-4 h-4" />
            </span>
            <h1 className="text-base sm:text-lg font-bold text-[#e6edf3]">
              Progressive Topic Mastery & Level Unlocking
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
              Granular Progression
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1 max-w-2xl">
            Slower, more meaningful mastery: Advance through Basic Formulas (L1), Applied Dynamics (L2), and Advanced Entrance Mocks (L3). Level 2 and 3 require verified 80%+ rolling accuracy over at least 10 questions.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <div className="p-2 px-3 rounded-md bg-[#0d1117] border border-[#30363d] flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <div>
              <div className="text-[10px] font-mono text-gray-400 uppercase">Total User XP</div>
              <div className="text-sm font-bold font-mono text-amber-300">{userTotalXP} XP</div>
            </div>
          </div>

          <button
            type="button"
            onClick={fetchMastery}
            className="p-2 rounded-md bg-[#0d1117] hover:bg-slate-800 text-gray-400 hover:text-white border border-[#30363d] transition-colors cursor-pointer"
            title="Refresh Mastery Progress"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-sky-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Subject Navigation Tabs */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1">
        {subjectKeys.map((sId) => {
          const sData = masteryData[sId];
          const isActive = activeSubjectId === sId;
          return (
            <button
              key={sId}
              type="button"
              onClick={() => setActiveSubjectId(sId)}
              className={`flex items-center space-x-2 px-3.5 py-2 rounded-md text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                isActive
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                  : 'bg-[#161b22] text-gray-400 hover:text-gray-200 border border-[#30363d]'
              }`}
            >
              <span>{sData.subject.name}</span>
              <span
                className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                  isActive ? 'bg-sky-500/30 text-sky-200' : 'bg-slate-800 text-gray-400'
                }`}
              >
                {sData.overallMastery}%
              </span>
            </button>
          );
        })}
      </div>

      {/* Loading Skeleton */}
      {loading && !currentSubjectData ? (
        <div className="space-y-4 animate-pulse">
          <div className="h-32 rounded-lg bg-[#161b22] border border-[#30363d]" />
          <div className="h-48 rounded-lg bg-[#161b22] border border-[#30363d]" />
        </div>
      ) : currentSubjectData ? (
        <div className="space-y-4">
          {/* Subject Mastery Overview Card */}
          <MasteryCard subjectData={currentSubjectData} />

          {/* Topics Breakdown List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-gray-400 px-1">
              <span className="font-mono uppercase tracking-wider text-[10px] flex items-center space-x-1">
                <Layers className="w-3.5 h-3.5 text-sky-400" />
                <span>Topics & Progression Levels ({currentSubjectData.topics.length} Topics)</span>
              </span>
              <span>Click topic to expand/collapse level tiers</span>
            </div>

            {currentSubjectData.topics.map((topic) => (
              <TopicProgress
                key={topic.id}
                topic={topic}
                onStartLevelDrill={(tId, lvl) =>
                  onStartLevelPractice(currentSubjectData.subject.name, tId, lvl)
                }
              />
            ))}
          </div>
        </div>
      ) : (
        <div className="p-12 rounded-lg bg-[#161b22] border border-[#30363d] text-center text-gray-400">
          No topic data available for this subject.
        </div>
      )}
    </div>
  );
};
