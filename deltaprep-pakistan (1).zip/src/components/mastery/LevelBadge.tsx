import React from 'react';
import { Check, Lock, Unlock } from 'lucide-react';

interface LevelBadgeProps {
  level: number;
  unlocked: boolean;
  completed: boolean;
}

export const LevelBadge: React.FC<LevelBadgeProps> = ({ level, unlocked, completed }) => {
  if (completed) {
    return (
      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
        <Check className="w-3 h-3 text-emerald-400" />
        <span>L{level} Mastered</span>
      </span>
    );
  }

  if (unlocked) {
    return (
      <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-sky-500/20 text-sky-300 border border-sky-500/40">
        <Unlock className="w-3 h-3 text-sky-400" />
        <span>L{level} Active</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-gray-400 border border-slate-700">
      <Lock className="w-3 h-3 text-gray-500" />
      <span>L{level} Locked</span>
    </span>
  );
};
