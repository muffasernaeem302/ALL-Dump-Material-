import React from 'react';
import { Award, CheckCircle, Flame, Lock, ShieldCheck, Sparkles } from 'lucide-react';
import { SubjectMasteryData } from '../../types';

interface MasteryCardProps {
  subjectData: SubjectMasteryData;
}

export const MasteryCard: React.FC<MasteryCardProps> = ({ subjectData }) => {
  const { subject, overallMastery, totalXP, unlockedCount, totalLevels } = subjectData;

  return (
    <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-md bg-sky-500/20 text-sky-400 font-mono font-bold text-xs">
              {subject.code}
            </span>
            <h2 className="text-base sm:text-lg font-bold text-[#e6edf3]">
              {subject.name} Mastery Dashboard
            </h2>
          </div>
          <p className="text-xs text-gray-400 mt-1">
            Sequential progression engine with rolling accuracy verification. Requires 80%+ accuracy on 10+ questions to unlock subsequent levels.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-300 font-mono text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{totalXP} Subject XP</span>
          </div>

          <div className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-sky-500/10 border border-sky-500/30 text-sky-300 font-mono text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
            <span>{unlockedCount} / {totalLevels} Levels Unlocked</span>
          </div>
        </div>
      </div>

      {/* Main Mastery Progress Bar */}
      <div className="p-4 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-mono text-gray-300 font-semibold uppercase text-[10px] tracking-wider">
            Overall Subject Mastery
          </span>
          <span
            className={`font-mono font-bold text-sm ${
              overallMastery >= 80 ? 'text-emerald-400' : 'text-sky-400'
            }`}
          >
            {overallMastery}%
          </span>
        </div>
        <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5">
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              overallMastery >= 80 ? 'bg-gradient-to-r from-emerald-500 to-teal-400' : 'bg-gradient-to-r from-sky-500 to-indigo-500'
            }`}
            style={{ width: `${Math.min(100, overallMastery)}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-[10px] text-gray-400 font-mono pt-1">
          <span>0% Beginner</span>
          <span>50% Intermediate</span>
          <span>80% Entrance Ready (NUST NET & MDCAT)</span>
          <span>100% Master</span>
        </div>
      </div>
    </div>
  );
};
