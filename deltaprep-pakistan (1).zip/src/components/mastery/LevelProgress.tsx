import React from 'react';
import { Lock, Play, Sparkles, Target } from 'lucide-react';
import { TopicLevelData } from '../../types';
import { LevelBadge } from './LevelBadge';

interface LevelProgressProps {
  level: TopicLevelData;
  topicName: string;
  onStartLevelDrill: (topicId: string, levelNumber: number) => void;
}

export const LevelProgress: React.FC<LevelProgressProps> = ({
  level,
  topicName,
  onStartLevelDrill,
}) => {
  return (
    <div
      className={`p-3.5 rounded-lg border transition-all ${
        level.completed
          ? 'bg-emerald-950/15 border-emerald-900/50'
          : level.unlocked
          ? 'bg-[#0d1117] border-[#30363d] hover:border-sky-500/50'
          : 'bg-[#0d1117]/50 border-[#30363d]/40 opacity-75'
      }`}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-xs sm:text-sm text-[#e6edf3]">
              {level.name}
            </span>
            <LevelBadge
              level={level.level}
              unlocked={level.unlocked}
              completed={level.completed}
            />
            <span className="inline-flex items-center space-x-1 text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              <Sparkles className="w-2.5 h-2.5" />
              <span>+{level.xpReward} XP</span>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-[11px] text-gray-400 font-mono">
            <span>Accuracy: <strong className={level.accuracy >= 80 ? 'text-emerald-400' : 'text-gray-300'}>{level.accuracy}%</strong></span>
            <span>Attempts: <strong className="text-gray-300">{level.attempts}</strong> q's</span>
            <span>Correct: <strong className="text-emerald-400">{level.correct}</strong></span>
          </div>
        </div>

        {/* Action Button */}
        <div>
          {level.unlocked ? (
            <button
              type="button"
              onClick={() => onStartLevelDrill(level.topicId, level.level)}
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-1.5 px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              <Play className="w-3 h-3 fill-white" />
              <span>{level.attempts > 0 ? 'Drill Again' : 'Start Level Drill'}</span>
            </button>
          ) : (
            <div className="inline-flex items-center space-x-1 text-xs text-gray-400 font-mono bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700">
              <Lock className="w-3 h-3 text-gray-500" />
              <span>Locked (Needs L{level.level - 1} ≥ 80% & 10 Qs)</span>
            </div>
          )}
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mt-3 space-y-1">
        <div className="flex items-center justify-between text-[10px] font-mono text-gray-400">
          <span>Mastery Threshold</span>
          <span>{level.accuracy}% / {level.unlockAccuracy}%</span>
        </div>
        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              level.completed
                ? 'bg-emerald-500'
                : level.accuracy >= 80
                ? 'bg-emerald-400'
                : 'bg-sky-500'
            }`}
            style={{ width: `${Math.min(100, (level.accuracy / level.unlockAccuracy) * 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
};
