import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Layers } from 'lucide-react';
import { TopicMasteryDetail } from '../../types';
import { LevelProgress } from './LevelProgress';

interface TopicProgressProps {
  topic: TopicMasteryDetail;
  onStartLevelDrill: (topicId: string, levelNumber: number) => void;
}

export const TopicProgress: React.FC<TopicProgressProps> = ({
  topic,
  onStartLevelDrill,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  const completedLevels = topic.levels.filter((l) => l.completed).length;

  return (
    <div className="rounded-lg bg-[#161b22] border border-[#30363d] overflow-hidden transition-all">
      {/* Topic Header Accordion */}
      <div
        onClick={() => setIsExpanded(!isExpanded)}
        className="p-4 flex items-center justify-between cursor-pointer hover:bg-[#0d1117]/60 transition-colors"
      >
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="p-1 rounded bg-sky-500/10 text-sky-400">
              <Layers className="w-3.5 h-3.5" />
            </span>
            <h3 className="font-bold text-sm text-[#e6edf3]">{topic.name}</h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-gray-300">
              {completedLevels} / {topic.levels.length} Levels Mastered
            </span>
          </div>

          <div className="flex items-center space-x-3 text-xs text-gray-400">
            <span>Overall Topic Accuracy:</span>
            <span
              className={`font-mono font-bold ${
                topic.overallMastery >= 80 ? 'text-emerald-400' : 'text-sky-400'
              }`}
            >
              {topic.overallMastery}%
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          {/* Circular or Mini Progress Bar */}
          <div className="w-24 sm:w-32 bg-slate-800 h-2 rounded-full overflow-hidden hidden sm:block">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                topic.overallMastery >= 80 ? 'bg-emerald-500' : 'bg-sky-500'
              }`}
              style={{ width: `${Math.min(100, topic.overallMastery)}%` }}
            />
          </div>

          <button
            type="button"
            className="p-1 rounded text-gray-400 hover:text-white"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Expanded Levels Breakdown */}
      {isExpanded && (
        <div className="p-4 pt-0 space-y-2.5 border-t border-[#30363d]/40 mt-1">
          <div className="text-[10px] font-mono uppercase tracking-wider text-gray-400 pt-2">
            Progressive Sub-Sections & Entrance Levels:
          </div>
          {topic.levels.map((lvl) => (
            <LevelProgress
              key={lvl.id}
              level={lvl}
              topicName={topic.name}
              onStartLevelDrill={onStartLevelDrill}
            />
          ))}
        </div>
      )}
    </div>
  );
};
