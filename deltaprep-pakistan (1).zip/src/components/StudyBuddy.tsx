import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Calendar,
  Bell,
  Clock,
  Send,
  Camera,
  Upload,
  Lightbulb,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  X,
  FileText,
  BarChart3,
  HelpCircle,
  BrainCircuit,
  Zap,
} from 'lucide-react';
import {
  StudyBuddyData,
  ChatMessage,
  FormulaItem,
  Subject,
  StudyTimetableSlot,
  BoardId,
  ExamId,
} from '../types';
import { studyBuddyData, sampleChatResponses } from '../data';
import { MathView } from './MathView';

interface StudyBuddyProps {
  isDrawerMode?: boolean;
  onCloseDrawer?: () => void;
  initialQuestionPrompt?: string;
  onSelectPractice?: (subject: string) => void;
  homeBoard?: BoardId;
  targetExam?: ExamId;
}

export const StudyBuddy: React.FC<StudyBuddyProps> = ({
  isDrawerMode = false,
  onCloseDrawer,
  initialQuestionPrompt,
  onSelectPractice,
  homeBoard = 'punjab',
  targetExam = 'nust_net',
}) => {
  const [timetable, setTimetable] = useState<StudyTimetableSlot[]>(studyBuddyData.timetable);
  const [notifications, setNotifications] = useState(studyBuddyData.notifications);
  const [isRescheduling, setIsRescheduling] = useState(false);
  const [showRescheduleToast, setShowRescheduleToast] = useState(false);
  const [rescheduleMessage, setRescheduleMessage] = useState<string>('');

  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      sender: 'assistant',
      text: "Assalam-o-Alaikum! I'm your DeltaPrep AI Study Buddy, specialized in the Federal vs. Provincial FSc divergence for NUST NET, FAST, and MDCAT. How can I help you conquer today's syllabus gaps?",
      timestamp: '9:00 AM',
      hints: [
        "Ask me to solve any Math or Physics numerical with full step-by-step KaTeX working.",
        "Upload a photo of a textbook problem to test our OCR Vision parsing.",
        "Ask: 'Generate a 3-day revision plan for FAST math traps'",
      ],
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [expandedHints, setExpandedHints] = useState<Record<string, boolean>>({});

  // OCR Mockup & Real file state
  const [isOcrModalOpen, setIsOcrModalOpen] = useState(false);
  const [ocrProcessing, setOcrProcessing] = useState(false);
  const [uploadedImagePreview, setUploadedImagePreview] = useState<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto-fill prompt if provided externally
  useEffect(() => {
    if (initialQuestionPrompt) {
      handleSendPrompt(initialQuestionPrompt);
    }
  }, [initialQuestionPrompt]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleRescheduleDay = async () => {
    setIsRescheduling(true);
    try {
      const response = await fetch('/api/ai/study-planner', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetExam,
          homeBoard,
          weakTopics: ['Calculus Shortcuts', 'Solenoid End-Effects', 'Organic Stereochemistry'],
          dailyHours: 4,
        }),
      });

      const data = await response.json();
      if (data.plan && Array.isArray(data.plan) && data.plan.length > 0) {
        const firstDay = data.plan[0];
        const newSlots: StudyTimetableSlot[] = firstDay.timeSlots.map((slot: any, idx: number) => ({
          id: `slot-ai-${Date.now()}-${idx}`,
          time: slot.time || '10:00 AM',
          subject: (idx === 0 ? 'Mathematics' : idx === 1 ? 'Physics' : 'Chemistry') as Subject,
          topic: slot.activity || 'High Yield Practice',
          duration: '90 mins',
          status: (idx === 0 ? 'Completed' : idx === 1 ? 'In Progress' : 'Upcoming') as any,
          badge: slot.type || 'AI Optimized',
        }));
        setTimetable(newSlots);
        setRescheduleMessage(firstDay.highYieldDeltaTip || 'Schedule optimized for current exam gaps.');
      } else {
        // Fallback rebalance
        const updated = [...timetable].map((slot, index) => {
          if (slot.status === 'Upcoming' && index === 2) {
            return {
              ...slot,
              topic: 'Intensive Walli Definite Integrals & Tabular D-I Drill (AI Rebalanced)',
              duration: '90 mins',
              badge: 'Speed Priority',
            };
          }
          return slot;
        });
        setTimetable(updated);
        setRescheduleMessage('Priority shifted to Walli Integrals and Solenoid End-Effects.');
      }
    } catch (e) {
      console.error('Failed to reschedule day:', e);
      setRescheduleMessage('Schedule refreshed with latest high-yield syllabus gaps.');
    } finally {
      setIsRescheduling(false);
      setShowRescheduleToast(true);
      setTimeout(() => setShowRescheduleToast(false), 5000);
    }
  };

  const handleDismissNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const handleSendPrompt = async (promptText: string) => {
    if (!promptText.trim()) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: promptText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, userMsg]);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/study-buddy/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText,
          history: messages.slice(-6),
          context: {
            homeBoard,
            targetExam,
          },
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data = await response.json();

      const aiResponse: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        latexSnippet: data.latexSnippet,
        hints: [
          `Focus on ${targetExam.toUpperCase()} syllabus divergence rules`,
          'Ask: "Can you generate 3 practice MCQs on this topic?"',
        ],
      };

      setMessages((prev) => [...prev, aiResponse]);
    } catch (err: any) {
      console.error('Error in chat request:', err);
      // Contextual graceful fallback
      const fallbackResponse: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: `Regarding "${promptText}": For ${targetExam}, verify the Federal Board (FBISE / NBF) textbook derivations. Since calculators are prohibited in NET, FAST, and MDCAT, look for dimensional cancellation or ratio shortcuts.`,
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, fallbackResponse]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setUploadedImagePreview(result);
    };
    reader.readAsDataURL(file);
  };

  const handleProcessUploadedImage = async () => {
    if (!uploadedImagePreview) return;
    setOcrProcessing(true);

    try {
      const response = await fetch('/api/study-buddy/vision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: uploadedImagePreview,
          mimeType: 'image/jpeg',
          prompt: 'Transcribe this entry-test problem, identify the board divergence, and provide the complete step-by-step KaTeX solution.',
          homeBoard,
          targetExam,
        }),
      });

      const data = await response.json();
      setIsOcrModalOpen(false);

      const userMsg: ChatMessage = {
        id: `user-ocr-${Date.now()}`,
        sender: 'user',
        text: `[Uploaded Problem Image: ${uploadedFileName || 'Exam Question'}]`,
        timestamp: 'Just now',
        attachmentUrl: uploadedImagePreview,
        attachmentName: uploadedFileName || 'problem.png',
      };

      const aiResponse: ChatMessage = {
        id: `ai-ocr-${Date.now()}`,
        sender: 'assistant',
        text: data.analysis,
        timestamp: 'Just now',
        latexSnippet: data.latexSnippet,
        hints: [
          'Practice similar problems in Practice & Mocks tab',
          'Notice how Federal FBISE vs Provincial approaches differ on this topic',
        ],
      };

      setMessages((prev) => [...prev, userMsg, aiResponse]);
    } catch (error) {
      console.error('Vision solver failed:', error);
    } finally {
      setOcrProcessing(false);
      setUploadedImagePreview(null);
      setUploadedFileName('');
    }
  };

  const handleSimulateOcr = async (presetName: string, problemText: string) => {
    setOcrProcessing(true);
    try {
      setIsOcrModalOpen(false);

      const ocrUserMsg: ChatMessage = {
        id: `user-ocr-${Date.now()}`,
        sender: 'user',
        text: `[Scanned Textbook Question]: ${problemText}`,
        timestamp: 'Just now',
        attachmentName: `${presetName}.png`,
      };
      setMessages((prev) => [...prev, ocrUserMsg]);
      setIsTyping(true);

      const response = await fetch('/api/study-buddy/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `Please solve this problem step-by-step with KaTeX: "${problemText}" for ${targetExam}. Highlight why it is a known syllabus trap.`,
          history: [],
          context: {
            homeBoard,
            targetExam,
          },
        }),
      });

      const data = await response.json();
      const ocrAiResponse: ChatMessage = {
        id: `ai-ocr-${Date.now()}`,
        sender: 'assistant',
        text: data.reply,
        timestamp: 'Just now',
        latexSnippet: data.latexSnippet,
      };
      setMessages((prev) => [...prev, ocrAiResponse]);
    } catch (e) {
      console.error(e);
    } finally {
      setOcrProcessing(false);
      setIsTyping(false);
    }
  };

  const toggleHint = (msgId: string) => {
    setExpandedHints((prev) => ({ ...prev, [msgId]: !prev[msgId] }));
  };

  return (
    <div className={`space-y-4 ${isDrawerMode ? 'h-full flex flex-col' : ''}`}>
      {/* Drawer Mode Top Bar */}
      {isDrawerMode && (
        <div className="flex items-center justify-between px-4 py-3 border-b border-[#30363d] bg-[#161b22]">
          <div className="flex items-center space-x-2">
            <div className="h-6 w-6 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">
              <BrainCircuit className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-bold text-[#e6edf3]">
              AI Study Buddy & Socratic Solver
            </h3>
          </div>
          {onCloseDrawer && (
            <button
              onClick={onCloseDrawer}
              className="p-1 rounded text-gray-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      )}

      {/* 1. Timetable & Nudge Bar */}
      <div className="rounded-lg border border-[#30363d] bg-[#161b22] p-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-sky-400" />
              <h3 className="text-sm font-bold text-[#e6edf3]">
                Today&apos;s High-Yield Timetable & Nudges
              </h3>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/30">
                Personalized Schedule
              </span>
            </div>
            <p className="text-xs text-gray-400 mt-0.5">
              Balanced dynamically to cover Federal vs. Punjab textbook divergences before exam day.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              id="btn-reschedule-day"
              onClick={handleRescheduleDay}
              disabled={isRescheduling}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-[#0d1117] hover:bg-slate-800 border border-[#30363d] text-xs font-medium text-gray-200 hover:text-white transition-colors disabled:opacity-50"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isRescheduling ? 'animate-spin text-sky-400' : ''}`} />
              <span>{isRescheduling ? 'Rebalancing...' : 'Reschedule Day'}</span>
            </button>
          </div>
        </div>

        {/* Reschedule Toast Confirmation */}
        {showRescheduleToast && (
          <div className="mt-3 p-2.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center space-x-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>
              Schedule updated! Priority shifted to Walli Definite Integrals and Solenoid End-Effects based on recent accuracy gaps.
            </span>
          </div>
        )}

        {/* Notifications & Nudges */}
        {notifications.length > 0 && (
          <div className="mt-3 space-y-1.5">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className="flex items-center justify-between p-2 rounded bg-[#0d1117] border border-[#30363d] text-xs"
              >
                <div className="flex items-center space-x-2">
                  <Bell className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  <span className="text-gray-300 text-[11px]">{notif.message}</span>
                </div>
                <button
                  onClick={() => handleDismissNotification(notif.id)}
                  className="text-gray-500 hover:text-gray-300 p-0.5 ml-2"
                  title="Dismiss notification"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Schedule Slots Horizontal/Grid Scroll */}
        <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 pt-3 border-t border-[#30363d]">
          {timetable.map((slot) => (
            <div
              key={slot.id}
              className={`p-2.5 rounded-md border text-xs flex flex-col justify-between ${
                slot.status === 'Completed'
                  ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                  : slot.status === 'In Progress'
                  ? 'bg-sky-950/25 border-sky-500/40 text-sky-200 shadow-xs'
                  : 'bg-[#0d1117] border-[#30363d] text-gray-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                  <span className="text-gray-400">{slot.time}</span>
                  <span
                    className={`px-1 rounded font-semibold ${
                      slot.status === 'Completed'
                        ? 'text-emerald-400 bg-emerald-500/10'
                        : slot.status === 'In Progress'
                        ? 'text-sky-400 bg-sky-500/10 animate-pulse'
                        : 'text-gray-500 bg-slate-800'
                    }`}
                  >
                    {slot.status}
                  </span>
                </div>
                <p className="font-semibold text-xs text-[#e6edf3] line-clamp-1">{slot.subject}</p>
                <p className="text-[11px] text-gray-400 line-clamp-2 mt-0.5 leading-snug">{slot.topic}</p>
              </div>
              <div className="mt-2 pt-1.5 border-t border-slate-700/50 flex items-center justify-between text-[10px] font-mono text-gray-400">
                <span>{slot.duration}</span>
                <span className="text-sky-400">{slot.badge}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Diagnostic & Readiness Widget */}
      <div className="rounded-lg border border-[#30363d] bg-[#161b22] p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-[#e6edf3]">
              Progress Diagnostic & Readiness Index
            </h3>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <div className="flex items-center space-x-1.5 font-mono">
              <span className="text-gray-400">Weekly Study:</span>
              <span className="font-bold text-sky-400">
                {studyBuddyData.weeklyStudyHours} / {studyBuddyData.targetWeeklyHours} hrs
              </span>
            </div>
            <div className="h-3 w-px bg-[#30363d]" />
            <div className="flex items-center space-x-1.5 font-mono">
              <span className="text-gray-400">Overall Readiness:</span>
              <span className="font-bold text-emerald-400 text-sm">
                {studyBuddyData.overallReadiness}%
              </span>
            </div>
          </div>
        </div>

        {/* Progress Bars per Subject */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {studyBuddyData.subjectReadiness.map((subj) => (
            <div
              key={subj.subject}
              className="p-3 rounded-md bg-[#0d1117] border border-[#30363d] space-y-2"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-gray-200">{subj.subject}</span>
                <span
                  className={`font-mono font-bold text-xs ${
                    subj.score >= 85
                      ? 'text-emerald-400'
                      : subj.score >= 78
                      ? 'text-sky-400'
                      : 'text-amber-400'
                  }`}
                >
                  {subj.score}%
                </span>
              </div>

              {/* Progress Track */}
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div
                  className={`h-full rounded-full ${
                    subj.score >= 85
                      ? 'bg-emerald-500'
                      : subj.score >= 78
                      ? 'bg-sky-500'
                      : 'bg-amber-500'
                  }`}
                  style={{ width: `${subj.score}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-gray-500">
                <span>{subj.totalSolved} MCQs</span>
                <span
                  className={
                    subj.status === 'Critical Delta'
                      ? 'text-amber-400 font-semibold'
                      : 'text-gray-400'
                  }
                >
                  {subj.status}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Weak Topic Alerts */}
        <div className="mt-3 pt-3 border-t border-[#30363d] flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
          <div className="flex items-center space-x-2 text-xs">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-gray-300 font-medium">Weak Topic Alerts:</span>
            <span className="text-amber-300 text-[11px]">
              Tabular D-I Integration (Math) & Solenoid End-Effects (Physics)
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => handleSendPrompt("Explain Bernoulli's Principle simply and solve a sample numerical")}
              className="text-[11px] text-sky-400 hover:text-sky-300 font-medium hover:underline"
            >
              Ask AI to Explain Gaps →
            </button>
          </div>
        </div>
      </div>

      {/* 3. Interactive Chat Interface with LaTeX & OCR */}
      <div className="rounded-lg border border-[#30363d] bg-[#161b22] flex flex-col overflow-hidden flex-1">
        {/* Chat Header */}
        <div className="px-4 py-3 border-b border-[#30363d] bg-[#0d1117] flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="h-6 w-6 rounded bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold text-xs">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-[#e6edf3]">
                DeltaPrep AI Tutor & LaTeX Solver
              </h4>
              <p className="text-[10px] text-gray-400">
                Step-by-step numerical derivations, Socratic hints, and speed exam shortcuts.
              </p>
            </div>
          </div>

          <button
            id="btn-open-ocr-modal"
            onClick={() => setIsOcrModalOpen(true)}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 border border-slate-700 text-xs font-medium transition-colors"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Snap Question (OCR)</span>
          </button>
        </div>

        {/* Quick Prompt Pills */}
        <div className="px-4 py-2 bg-[#161b22] border-b border-[#30363d] flex items-center space-x-1.5 overflow-x-auto scrollbar-none">
          <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider shrink-0">
            Pills:
          </span>
          {[
            'Solve a Physics Numerical',
            "Generate Today's Study Plan",
            "Explain Bernoulli's Principle simply",
            'Check my NUST Readiness',
          ].map((pill) => (
            <button
              key={pill}
              onClick={() => handleSendPrompt(pill)}
              className="px-2.5 py-1 rounded-full bg-[#0d1117] hover:bg-slate-800 border border-[#30363d] text-[11px] text-gray-300 hover:text-white transition-colors whitespace-nowrap font-medium"
            >
              {pill}
            </button>
          ))}
        </div>

        {/* Chat Messages Log */}
        <div className="p-4 space-y-4 max-h-[420px] overflow-y-auto bg-[#0a0c10]/70 flex-1">
          {messages.map((msg) => {
            const isAssistant = msg.sender === 'assistant';
            const hintsExpanded = expandedHints[msg.id] ?? false;

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isAssistant ? 'items-start' : 'items-end'}`}
              >
                <div
                  className={`max-w-2xl rounded-lg p-3.5 text-xs leading-relaxed ${
                    isAssistant
                      ? 'bg-[#161b22] border border-[#30363d] text-[#e6edf3]'
                      : 'bg-sky-600 text-white shadow-sm'
                  }`}
                >
                  {/* Sender & Timestamp Header */}
                  <div className="flex items-center justify-between mb-1.5 text-[10px] opacity-75 font-mono">
                    <span>{isAssistant ? 'DeltaPrep Study Buddy' : 'You'}</span>
                    <span>{msg.timestamp}</span>
                  </div>

                  {/* Attachment indicator if OCR */}
                  {msg.attachmentName && (
                    <div className="mb-2 p-2 rounded bg-sky-950/40 border border-sky-500/30 flex items-center space-x-2 text-[11px] text-sky-200">
                      <FileText className="w-3.5 h-3.5 text-sky-400" />
                      <span>Attached: {msg.attachmentName}</span>
                    </div>
                  )}

                  {/* Message body text */}
                  <p className="whitespace-pre-line text-xs">{msg.text}</p>

                  {/* LaTeX Equation Box */}
                  {msg.latexSnippet && (
                    <div className="my-2.5 p-2.5 rounded bg-[#0d1117] border border-[#30363d] text-center overflow-x-auto text-[#e6edf3]">
                      <MathView math={msg.latexSnippet} block />
                    </div>
                  )}

                  {/* Step-by-step breakdown */}
                  {msg.steps && (
                    <div className="mt-3 space-y-2 pt-2 border-t border-[#30363d]/60">
                      {msg.steps.map((step) => (
                        <div
                          key={step.stepNumber}
                          className="p-2.5 rounded bg-[#0d1117]/80 border border-[#30363d]/70 text-xs space-y-1"
                        >
                          <div className="flex items-center space-x-1.5 font-semibold text-sky-400 text-xs">
                            <span className="h-4 w-4 rounded-full bg-sky-500/20 flex items-center justify-center text-[10px] font-mono">
                              {step.stepNumber}
                            </span>
                            <span>{step.title}</span>
                          </div>
                          <p className="text-gray-300 text-[11px] leading-relaxed">
                            {step.explanation}
                          </p>
                          {step.math && (
                            <div className="pt-1 text-center overflow-x-auto text-sky-200">
                              <MathView math={step.math} block />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Socratic Hints Collapsible */}
                  {msg.hints && msg.hints.length > 0 && (
                    <div className="mt-2.5 pt-2 border-t border-slate-700/60">
                      <button
                        onClick={() => toggleHint(msg.id)}
                        className="flex items-center space-x-1 text-[11px] text-amber-400 hover:text-amber-300 font-medium"
                      >
                        <Lightbulb className="w-3 h-3" />
                        <span>
                          {hintsExpanded ? 'Hide Socratic Hints' : 'Reveal Socratic Hints'}
                        </span>
                        {hintsExpanded ? (
                          <ChevronUp className="w-3 h-3" />
                        ) : (
                          <ChevronDown className="w-3 h-3" />
                        )}
                      </button>

                      {hintsExpanded && (
                        <ul className="mt-1.5 space-y-1 pl-3 list-disc text-[11px] text-amber-200/90 leading-relaxed">
                          {msg.hints.map((hint, idx) => (
                            <li key={idx}>{hint}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex items-center space-x-2 text-xs text-gray-400 p-2">
              <Sparkles className="w-3.5 h-3.5 text-sky-400 animate-spin" />
              <span>Study Buddy is deriving solution in LaTeX...</span>
            </div>
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Input Bar */}
        <div className="p-3 border-t border-[#30363d] bg-[#161b22]">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendPrompt(inputValue);
            }}
            className="flex items-center space-x-2"
          >
            <input
              id="ai-chat-input"
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask a numerical question, request a concept, or type a formula..."
              className="flex-1 bg-[#0d1117] border border-[#30363d] rounded-md px-3 py-2 text-xs text-[#e6edf3] placeholder:text-gray-500 focus:outline-none focus:border-sky-500"
            />
            <button
              id="btn-send-ai-chat"
              type="submit"
              disabled={!inputValue.trim()}
              className="px-3.5 py-2 rounded-md bg-sky-500 hover:bg-sky-600 disabled:opacity-40 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              <span>Send</span>
              <Send className="w-3 h-3" />
            </button>
          </form>
        </div>
      </div>

      {/* OCR Question Parsing Modal */}
      {isOcrModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div
            id="ocr-modal"
            className="w-full max-w-lg bg-[#161b22] border border-[#30363d] rounded-lg shadow-2xl overflow-hidden"
          >
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-[#30363d] bg-[#0d1117]">
              <div className="flex items-center space-x-2">
                <Camera className="w-4 h-4 text-sky-400" />
                <h4 className="text-sm font-semibold text-[#e6edf3]">
                  Snap Question / OCR Textbook Parser
                </h4>
              </div>
              <button
                onClick={() => setIsOcrModalOpen(false)}
                className="text-gray-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              <p className="text-xs text-gray-400">
                Upload a photo or textbook snapshot of any Physics/Math problem. The OCR engine parses mathematical symbols and renders step-by-step derivations.
              </p>

              {/* Preset Sample Problems for Quick Testing */}
              <div className="space-y-2">
                <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">
                  Test with Sample Exam Snapshots:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={() =>
                      handleSimulateOcr(
                        'Kinematics Curvature Problem',
                        'A particle moves with position vector r(t) = 3t î + 4t² ĵ. Find the radius of curvature at t = 0.'
                      )
                    }
                    className="p-2.5 rounded border border-[#30363d] bg-[#0d1117] hover:bg-slate-800 text-left transition-colors space-y-1"
                  >
                    <span className="font-semibold text-xs text-sky-300 block">
                      📷 Physics Kinematics
                    </span>
                    <span className="text-[11px] text-gray-400 block truncate">
                      r(t) = 3t î + 4t² ĵ ... find curvature
                    </span>
                  </button>

                  <button
                    onClick={() =>
                      handleSimulateOcr(
                        'Solenoid Aperture Diagram',
                        'Calculate the magnetic flux density at the exact end aperture of a semi-infinite solenoid carrying current I.'
                      )
                    }
                    className="p-2.5 rounded border border-[#30363d] bg-[#0d1117] hover:bg-slate-800 text-left transition-colors space-y-1"
                  >
                    <span className="font-semibold text-xs text-emerald-300 block">
                      📷 Federal Biot-Savart
                    </span>
                    <span className="text-[11px] text-gray-400 block truncate">
                      B_end = 1/2 μ₀ n I end aperture
                    </span>
                  </button>
                </div>
              </div>

              {/* Upload Drag/Drop zone */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[#30363d] hover:border-sky-500 rounded-lg p-5 text-center cursor-pointer bg-[#0d1117] transition-colors"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileUpload}
                />
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-xs font-medium text-gray-200">
                  Drop your question photo here, or click to browse
                </p>
                <p className="text-[10px] text-gray-500 mt-1 font-mono">
                  Supports PNG, JPG, WEBP (Powered by Gemini Vision)
                </p>
              </div>

              {uploadedImagePreview && (
                <div className="p-3 rounded-lg border border-[#30363d] bg-[#0d1117] space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-300 font-medium truncate max-w-[200px]">
                      📷 {uploadedFileName || 'Selected Snapshot'}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setUploadedImagePreview(null);
                        setUploadedFileName('');
                      }}
                      className="text-red-400 hover:text-red-300 text-[11px]"
                    >
                      Remove
                    </button>
                  </div>
                  <img
                    src={uploadedImagePreview}
                    alt="Upload preview"
                    className="max-h-48 w-auto mx-auto rounded border border-[#30363d] object-contain"
                  />
                  <button
                    type="button"
                    onClick={handleProcessUploadedImage}
                    disabled={ocrProcessing}
                    className="w-full py-2 px-3 rounded bg-sky-500 hover:bg-sky-600 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{ocrProcessing ? 'Analyzing Problem...' : 'Solve with AI Vision'}</span>
                  </button>
                </div>
              )}

              {ocrProcessing && !uploadedImagePreview && (
                <div className="p-3 rounded bg-sky-950/30 border border-sky-500/30 text-sky-200 text-xs flex items-center space-x-2">
                  <Sparkles className="w-4 h-4 text-sky-400 animate-spin shrink-0" />
                  <span>Scanning textbook page with OCR vision... Extracting equations...</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
