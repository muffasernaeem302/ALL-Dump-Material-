import React, { useState, useEffect, useCallback } from 'react';
import { History, Play, Sparkles } from 'lucide-react';
import { RecordSummaryData, TestRecordItem } from '../../types';
import { RecordSummary } from './RecordSummary';
import { RecordFilters } from './RecordFilters';
import { RecordTable } from './RecordTable';
import { RecordDetails } from './RecordDetails';

interface RecordsPageProps {
  onStartPractice: () => void;
  onAskStudyBuddy?: (context: string) => void;
}

export const RecordsPage: React.FC<RecordsPageProps> = ({
  onStartPractice,
  onAskStudyBuddy,
}) => {
  const [summary, setSummary] = useState<RecordSummaryData | null>(null);
  const [summaryLoading, setSummaryLoading] = useState<boolean>(true);

  const [records, setRecords] = useState<TestRecordItem[]>([]);
  const [tableLoading, setTableLoading] = useState<boolean>(true);

  const [selectedType, setSelectedType] = useState<string>('ALL');
  const [selectedSubject, setSelectedSubject] = useState<string>('All Subjects');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [page, setPage] = useState<number>(1);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    total: 0,
    totalPages: 1,
  });

  const [activeRecordId, setActiveRecordId] = useState<string | null>(null);

  // Fetch summary
  const fetchSummary = useCallback(async () => {
    setSummaryLoading(true);
    try {
      const res = await fetch('/api/records/summary');
      if (res.ok) {
        const data = await res.json();
        setSummary(data);
      }
    } catch (e) {
      console.error('Failed to fetch records summary:', e);
    } finally {
      setSummaryLoading(false);
    }
  }, []);

  // Fetch paginated records
  const fetchRecords = useCallback(async () => {
    setTableLoading(true);
    try {
      const params = new URLSearchParams();
      params.append('page', String(page));
      params.append('limit', '20');
      if (selectedType !== 'ALL') params.append('type', selectedType);
      if (selectedSubject !== 'All Subjects') params.append('subject', selectedSubject);

      const res = await fetch(`/api/records?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        let list: TestRecordItem[] = data.records || [];

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          list = list.filter(
            (r) =>
              r.testName.toLowerCase().includes(q) ||
              (r.subject && r.subject.toLowerCase().includes(q))
          );
        }

        setRecords(list);
        setPagination(data.pagination || { page, limit: 20, total: list.length, totalPages: 1 });
      }
    } catch (e) {
      console.error('Failed to fetch records:', e);
    } finally {
      setTableLoading(false);
    }
  }, [page, selectedType, selectedSubject, searchQuery]);

  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);

  useEffect(() => {
    fetchRecords();
  }, [fetchRecords]);

  return (
    <div className="space-y-5 max-w-7xl mx-auto px-2 sm:px-4 py-4">
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="p-1.5 rounded-md bg-sky-500/20 text-sky-400">
              <History className="w-4 h-4" />
            </span>
            <h1 className="text-base sm:text-lg font-bold text-[#e6edf3]">
              Test History & Records Archive
            </h1>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              Persistent DB Storage
            </span>
          </div>
          <p className="text-xs text-gray-400 mt-1 max-w-2xl">
            Track your preparation journey with full diagnostic histories, penalty avoidance statistics, and step-by-step solutions for missed entrance test questions.
          </p>
        </div>

        <button
          type="button"
          onClick={onStartPractice}
          className="flex items-center justify-center space-x-2 px-4 py-2 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold shadow transition-colors cursor-pointer shrink-0"
        >
          <Play className="w-3.5 h-3.5 fill-white" />
          <span>Launch Practice Drill</span>
        </button>
      </div>

      {/* 1. Summary Cards */}
      <RecordSummary summary={summary} loading={summaryLoading} />

      {/* 2. Filter Bar */}
      <RecordFilters
        selectedType={selectedType}
        onSelectType={(type) => {
          setSelectedType(type);
          setPage(1);
        }}
        selectedSubject={selectedSubject}
        onSelectSubject={(subject) => {
          setSelectedSubject(subject);
          setPage(1);
        }}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
      />

      {/* 3. Paginated History Table */}
      <RecordTable
        records={records}
        loading={tableLoading}
        pagination={pagination}
        onPageChange={(newPage) => setPage(newPage)}
        onViewDetails={(id) => setActiveRecordId(id)}
      />

      {/* 4. Detailed Test Review Modal */}
      {activeRecordId && (
        <RecordDetails
          recordId={activeRecordId}
          onClose={() => setActiveRecordId(null)}
          onAskStudyBuddy={onAskStudyBuddy}
        />
      )}
    </div>
  );
};
