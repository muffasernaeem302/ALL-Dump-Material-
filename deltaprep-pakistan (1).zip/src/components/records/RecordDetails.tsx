import React, { useState, useEffect } from 'react';
import {
  X,
  CheckCircle2,
  XCircle,
  Clock,
  Calendar,
  AlertCircle,
  HelpCircle,
  Sparkles,
  BookOpen,
  Filter,
} from 'lucide-react';
import { TestRecordItem, TestAnswerItem } from '../../types';
import { MathView } from '../MathView';

interface RecordDetailsProps {
  recordId: string;
  onClose: () => void;
  onAskStudyBuddy?: (context: string) => void;
}

export const RecordDetails: React.FC<RecordDetailsProps> = ({
  recordId,
  onClose,
  onAskStudyBuddy,
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [record, setRecord] = useState<TestRecordItem | null>(null);
  const [answers, setAnswers] = useState<TestAnswerItem[]>([]);
  const [filterMode, setFilterMode] = useState<'incorrect' | 'all'>('incorrect');

  useEffect(() => {
    let isMounted = true;
    async function fetchDetails() {
      setLoading(true);
      try {
        const res = await fetch(`/api/records/${recordId}`);
        if (!res.ok) throw new Error('Failed to fetch record');
        const data = await res.json();
        if (isMounted) {
          setRecord(data.record);
          setAnswers(data.answers || []);
        }
      } catch (e) {
        console.error('Error fetching record details:', e);
      } finally {
        if (isMounted) setLoading(false);
      }
    }
    fetchDetails();
    return () => {
      isMounted = false;
    };
  }, [recordId]);

  if (loading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
        <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-8 max-w-lg w-full flex flex-col items-center justify-center space-y-4">
          <div className="w-8 h-8 border-2 border-sky-400 border-t-transparent rounded-full animate-spin" />
          <span className="text-xs text-gray-300 font-mono">Loading Test Diagnostics & Answers...</span>
        </div>
      </div>
    );
  }

  if (!record) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
        <div className="bg-[#161b22] border border-[#30363d] rounded-xl p-6 max-w-md w-full space-y-4 text-center">
          <AlertCircle className="w-10 h-10 text-red-400 mx-auto" />
          <h3 className="text-base font-bold text-[#e6edf3]">Record Not Found</h3>
          <p className="text-xs text-gray-400">Could not retrieve detailed answer history for this test attempt.</p>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-md bg-slate-800 text-white text-xs font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  const incorrectAnswers = answers.filter((a) => !a.isCorrect && !a.isSkipped);
  const displayedAnswers = filterMode === 'incorrect' ? incorrectAnswers : answers;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-5 overflow-y-auto">
      <div className="bg-[#161b22] border border-[#30363d] rounded-xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-[#30363d] flex items-center justify-between bg-[#0d1117]">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/40">
                {record.testType}
              </span>
              <h2 className="text-base sm:text-lg font-bold text-[#e6edf3]">{record.testName}</h2>
            </div>
            <div className="flex flex-wrap items-center gap-3 text-xs text-gray-400 mt-1">
              <span className="flex items-center space-x-1">
                <Calendar className="w-3 h-3 text-gray-500" />
                <span>{new Date(record.attemptedAt).toLocaleString()}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Clock className="w-3 h-3 text-gray-500" />
                <span>{Math.round(record.timeTaken / 60)} minutes</span>
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-gray-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Quick Metrics Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
              <span className="text-[10px] uppercase font-mono text-gray-400">Score</span>
              <div className="text-xl font-bold font-mono text-[#e6edf3] mt-0.5">
                {record.score} <span className="text-xs text-gray-500">/ {record.totalQuestions}</span>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
              <span className="text-[10px] uppercase font-mono text-gray-400">Accuracy</span>
              <div
                className={`text-xl font-bold font-mono mt-0.5 ${
                  record.accuracy >= 80 ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {record.accuracy}%
              </div>
            </div>
            <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
              <span className="text-[10px] uppercase font-mono text-gray-400">Correct / Wrong</span>
              <div className="text-xl font-bold font-mono text-emerald-400 mt-0.5">
                {record.correctAnswers} <span className="text-xs text-red-400">/ {record.incorrectAnswers}</span>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-[#0d1117] border border-[#30363d]">
              <span className="text-[10px] uppercase font-mono text-gray-400">XP Earned</span>
              <div className="text-xl font-bold font-mono text-amber-300 mt-0.5 flex items-center space-x-1">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>+{record.xpEarned}</span>
              </div>
            </div>
          </div>

          {/* Topic Performance Breakdown */}
          {record.topicBreakdown && Object.keys(record.topicBreakdown).length > 0 && (
            <div className="p-4 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-3">
              <h3 className="text-xs font-bold uppercase font-mono tracking-wider text-gray-300">
                Topic Performance Breakdown
              </h3>
              <div className="space-y-2.5">
                {Object.entries(record.topicBreakdown).map(([topicName, stats]: [string, { total: number; correct: number; accuracy: number }]) => (
                  <div key={topicName} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-300 font-medium">{topicName}</span>
                      <span className="font-mono text-gray-400">
                        <span
                          className={`font-semibold ${
                            stats.accuracy >= 80 ? 'text-emerald-400' : 'text-amber-400'
                          }`}
                        >
                          {stats.accuracy}%
                        </span>{' '}
                        ({stats.correct}/{stats.total})
                      </span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          stats.accuracy >= 80 ? 'bg-emerald-500' : 'bg-amber-500'
                        }`}
                        style={{ width: `${Math.min(100, stats.accuracy)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Missed Questions & Solutions Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <BookOpen className="w-4 h-4 text-sky-400" />
                <h3 className="text-sm font-bold text-[#e6edf3]">
                  {filterMode === 'incorrect' ? 'Missed Questions Review' : 'All Question Solutions'}
                </h3>
              </div>

              {/* View Toggle */}
              <div className="flex items-center space-x-1 p-0.5 rounded bg-[#0d1117] border border-[#30363d] text-xs">
                <button
                  type="button"
                  onClick={() => setFilterMode('incorrect')}
                  className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                    filterMode === 'incorrect'
                      ? 'bg-red-500/20 text-red-300 font-semibold'
                      : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  Incorrect Only ({incorrectAnswers.length})
                </button>
                <button
                  type="button"
                  onClick={() => setFilterMode('all')}
                  className={`px-2.5 py-1 rounded cursor-pointer transition-colors ${
                    filterMode === 'all'
                      ? 'bg-slate-700 text-[#e6edf3] font-semibold'
                      : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  All Questions ({answers.length})
                </button>
              </div>
            </div>

            {displayedAnswers.length === 0 ? (
              <div className="p-8 rounded-lg bg-[#0d1117] border border-[#30363d] text-center space-y-2">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
                <h4 className="text-sm font-semibold text-[#e6edf3]">Zero Incorrect Questions!</h4>
                <p className="text-xs text-gray-400">
                  Flawless accuracy on this attempt. All answers were mathematically and factually verified.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {displayedAnswers.map((ans, idx) => (
                  <div
                    key={ans.id || idx}
                    className={`p-4 rounded-lg border text-xs space-y-3 ${
                      ans.isCorrect
                        ? 'bg-emerald-950/10 border-emerald-900/40'
                        : ans.isSkipped
                        ? 'bg-amber-950/10 border-amber-900/40'
                        : 'bg-red-950/15 border-red-900/50'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono px-2 py-0.5 rounded bg-slate-800 text-gray-300 text-[10px] font-bold">
                          Q{idx + 1}
                        </span>
                        {ans.isCorrect ? (
                          <span className="flex items-center space-x-1 text-emerald-400 font-semibold text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Correct</span>
                          </span>
                        ) : ans.isSkipped ? (
                          <span className="flex items-center space-x-1 text-amber-400 font-semibold text-[11px]">
                            <HelpCircle className="w-3.5 h-3.5" />
                            <span>Skipped</span>
                          </span>
                        ) : (
                          <span className="flex items-center space-x-1 text-red-400 font-semibold text-[11px]">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Incorrect</span>
                          </span>
                        )}
                      </div>

                      {ans.boardOrigin && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-gray-400">
                          {ans.boardOrigin}
                        </span>
                      )}
                    </div>

                    {/* Question Statement */}
                    <div className="text-sm text-[#e6edf3] font-medium leading-relaxed">
                      <MathView math={ans.question} />
                    </div>

                    {/* Answers Comparison */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      <div className="p-2.5 rounded bg-[#0d1117] border border-[#30363d] space-y-0.5">
                        <span className="text-[10px] font-mono uppercase text-gray-400">Your Answer:</span>
                        <div
                          className={`font-semibold ${
                            ans.isCorrect ? 'text-emerald-400' : 'text-red-400'
                          }`}
                        >
                          {ans.selectedAnswer || (ans.isSkipped ? 'Deliberately Skipped' : 'None Selected')}
                        </div>
                      </div>

                      <div className="p-2.5 rounded bg-[#0d1117] border border-[#30363d] space-y-0.5">
                        <span className="text-[10px] font-mono uppercase text-gray-400">Correct Answer:</span>
                        <div className="text-emerald-400 font-semibold">{ans.correctAnswer}</div>
                      </div>
                    </div>

                    {/* Detailed KaTeX Explanation */}
                    {ans.explanation && (
                      <div className="p-3 rounded bg-[#0d1117]/80 border border-[#30363d]/80 text-gray-300 space-y-1.5">
                        <span className="text-[10px] font-mono uppercase text-sky-400 font-bold block">
                          Step-by-Step Mathematical Explanation:
                        </span>
                        <div className="text-xs leading-relaxed">
                          <MathView math={ans.explanation} />
                        </div>
                      </div>
                    )}

                    {onAskStudyBuddy && !ans.isCorrect && (
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onAskStudyBuddy(
                            `Can you explain this problem step-by-step with formulas and shortcuts?\nQuestion: ${ans.question}\nCorrect Answer: ${ans.correctAnswer}\nMy Missed Answer: ${ans.selectedAnswer}`
                          );
                        }}
                        className="inline-flex items-center space-x-1.5 text-xs text-sky-400 hover:text-sky-300 font-medium cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Ask Study Buddy why this is correct</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-[#30363d] bg-[#0d1117] flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold cursor-pointer transition-colors"
          >
            Done Reviewing
          </button>
        </div>
      </div>
    </div>
  );
};
