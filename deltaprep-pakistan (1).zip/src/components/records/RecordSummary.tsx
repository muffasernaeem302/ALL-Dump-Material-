import React from 'react';
import { Award, CheckCircle2, Clock, FileText, Target } from 'lucide-react';
import { RecordSummaryData } from '../../types';

interface RecordSummaryProps {
  summary: RecordSummaryData | null;
  loading: boolean;
}

export const RecordSummary: React.FC<RecordSummaryProps> = ({ summary, loading }) => {
  const formatTime = (seconds: number) => {
    if (!seconds || seconds <= 0) return '0m';
    const mins = Math.floor(seconds / 60);
    if (mins < 60) return `${mins}m`;
    const hrs = Math.floor(mins / 60);
    const remMins = mins % 60;
    return `${hrs}h ${remMins}m`;
  };

  if (loading && !summary) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 animate-pulse">
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-24 rounded-lg bg-[#161b22] border border-[#30363d]" />
        ))}
      </div>
    );
  }

  const data = summary || {
    testsCompleted: 0,
    averageScore: 0,
    accuracy: 0,
    bestScore: 0,
    totalTime: 0,
  };

  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
      {/* 1. Average Score */}
      <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span className="font-mono uppercase tracking-wider text-[10px]">Average Score</span>
          <Target className="w-3.5 h-3.5 text-sky-400" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1.5">
          <span className="text-2xl font-bold font-mono text-[#e6edf3]">{data.averageScore}%</span>
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
          <div
            className="bg-sky-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, data.averageScore)}%` }}
          />
        </div>
      </div>

      {/* 2. Accuracy */}
      <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span className="font-mono uppercase tracking-wider text-[10px]">Accuracy</span>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1.5">
          <span
            className={`text-2xl font-bold font-mono ${
              data.accuracy >= 80 ? 'text-emerald-400' : 'text-amber-400'
            }`}
          >
            {data.accuracy}%
          </span>
        </div>
        <div className="w-full bg-slate-800 h-1.5 rounded-full mt-2 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              data.accuracy >= 80 ? 'bg-emerald-500' : 'bg-amber-500'
            }`}
            style={{ width: `${Math.min(100, data.accuracy)}%` }}
          />
        </div>
      </div>

      {/* 3. Tests Completed */}
      <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span className="font-mono uppercase tracking-wider text-[10px]">Tests Completed</span>
          <FileText className="w-3.5 h-3.5 text-indigo-400" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1.5">
          <span className="text-2xl font-bold font-mono text-[#e6edf3]">{data.testsCompleted}</span>
          <span className="text-xs text-gray-500">attempts</span>
        </div>
        <span className="text-[10px] text-gray-400 mt-1">Permanently logged in DB</span>
      </div>

      {/* 4. Best Score */}
      <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span className="font-mono uppercase tracking-wider text-[10px]">Best Score</span>
          <Award className="w-3.5 h-3.5 text-amber-400" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1.5">
          <span className="text-2xl font-bold font-mono text-amber-300">{data.bestScore}%</span>
        </div>
        <span className="text-[10px] text-emerald-400 mt-1">Personal record</span>
      </div>

      {/* 5. Total Study Time */}
      <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] flex flex-col justify-between col-span-2 lg:col-span-1">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <span className="font-mono uppercase tracking-wider text-[10px]">Total Time</span>
          <Clock className="w-3.5 h-3.5 text-purple-400" />
        </div>
        <div className="mt-2 flex items-baseline space-x-1.5">
          <span className="text-2xl font-bold font-mono text-purple-300">{formatTime(data.totalTime)}</span>
        </div>
        <span className="text-[10px] text-gray-400 mt-1">Under exam speed timers</span>
      </div>
    </div>
  );
};
