import React from 'react';
import { Calendar, ChevronRight, Clock, Sparkles } from 'lucide-react';
import { TestRecordItem } from '../../types';

interface RecordRowProps {
  record: TestRecordItem;
  onViewDetails: (recordId: string) => void;
}

export const RecordRow: React.FC<RecordRowProps> = ({ record, onViewDetails }) => {
  const formatTime = (seconds: number) => {
    if (!seconds || seconds <= 0) return '0s';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins === 0) return `${secs}s`;
    return `${mins}m`;
  };

  const formatDate = (isoStr: string) => {
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return isoStr;
    }
  };

  const getTypeBadge = (type: string) => {
    switch (type) {
      case 'MOCK':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/40">
            MOCK EXAM
          </span>
        );
      case 'SUBJECT':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/40">
            SUBJECT TEST
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            PRACTICE
          </span>
        );
    }
  };

  return (
    <tr className="border-b border-[#30363d]/60 hover:bg-[#161b22]/70 transition-colors group">
      {/* Test Name & Badge */}
      <td className="py-3 px-4">
        <div className="flex flex-col">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-xs sm:text-sm text-[#e6edf3] group-hover:text-sky-300 transition-colors">
              {record.testName}
            </span>
            {getTypeBadge(record.testType)}
          </div>
          <div className="flex items-center space-x-2 text-[11px] text-gray-400 mt-0.5">
            <span>{record.subject || 'All Subjects'}</span>
            {record.xpEarned > 0 && (
              <span className="flex items-center space-x-0.5 text-amber-400 text-[10px] font-mono">
                <Sparkles className="w-2.5 h-2.5" />
                <span>+{record.xpEarned} XP</span>
              </span>
            )}
            {record.unlockedLevelsCount > 0 && (
              <span className="text-emerald-400 text-[10px] font-mono">
                · {record.unlockedLevelsCount} Level Unlocked
              </span>
            )}
          </div>
        </div>
      </td>

      {/* Score */}
      <td className="py-3 px-4 font-mono text-xs sm:text-sm text-[#e6edf3]">
        <span className="font-bold text-sky-400">{record.score}</span>
        <span className="text-gray-500"> / {record.totalQuestions}</span>
      </td>

      {/* Accuracy */}
      <td className="py-3 px-4 font-mono text-xs sm:text-sm">
        <span
          className={`font-semibold ${
            record.accuracy >= 80
              ? 'text-emerald-400'
              : record.accuracy >= 65
              ? 'text-sky-400'
              : 'text-amber-400'
          }`}
        >
          {record.accuracy}%
        </span>
      </td>

      {/* Time Taken */}
      <td className="py-3 px-4 text-xs font-mono text-gray-300 whitespace-nowrap">
        <div className="flex items-center space-x-1">
          <Clock className="w-3 h-3 text-gray-500" />
          <span>{formatTime(record.timeTaken)}</span>
        </div>
      </td>

      {/* Date */}
      <td className="py-3 px-4 text-xs text-gray-400 whitespace-nowrap">
        <div className="flex items-center space-x-1">
          <Calendar className="w-3 h-3 text-gray-500" />
          <span>{formatDate(record.attemptedAt)}</span>
        </div>
      </td>

      {/* Action */}
      <td className="py-3 px-4 text-right">
        <button
          type="button"
          onClick={() => onViewDetails(record.id)}
          className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-sky-600 text-gray-300 hover:text-white text-xs font-medium transition-colors cursor-pointer border border-slate-700 hover:border-sky-500"
        >
          <span>Review</span>
          <ChevronRight className="w-3 h-3" />
        </button>
      </td>
    </tr>
  );
};
