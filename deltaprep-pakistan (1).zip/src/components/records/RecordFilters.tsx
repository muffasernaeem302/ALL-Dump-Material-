import React from 'react';
import { Filter, Search } from 'lucide-react';
import { BackendTestType } from '../../types';

interface RecordFiltersProps {
  selectedType: string;
  onSelectType: (type: string) => void;
  selectedSubject: string;
  onSelectSubject: (subject: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const RecordFilters: React.FC<RecordFiltersProps> = ({
  selectedType,
  onSelectType,
  selectedSubject,
  onSelectSubject,
  searchQuery,
  onSearchChange,
}) => {
  const testTypes: { id: string; label: string }[] = [
    { id: 'ALL', label: 'All Tests' },
    { id: 'MOCK', label: 'Mock Exams' },
    { id: 'SUBJECT', label: 'Subject Tests' },
    { id: 'PRACTICE', label: 'Practice Quizzes' },
  ];

  const subjects = [
    'All Subjects',
    'Physics',
    'Mathematics',
    'Chemistry',
    'Biology',
    'Analytical & IQ',
  ];

  return (
    <div className="p-3.5 rounded-lg bg-[#161b22] border border-[#30363d] space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        {/* Type Filter Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 sm:pb-0">
          {testTypes.map((t) => {
            const isActive = selectedType === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => onSelectType(t.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-semibold'
                    : 'text-gray-400 hover:text-[#e6edf3] bg-[#0d1117] border border-[#30363d]'
                }`}
              >
                {t.label}
              </button>
            );
          })}
        </div>

        {/* Search Input */}
        <div className="relative min-w-[200px] sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search test name or topic..."
            className="w-full bg-[#0d1117] border border-[#30363d] rounded-md pl-8 pr-3 py-1.5 text-xs text-[#e6edf3] placeholder-gray-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Subject Filter Bar */}
      <div className="flex items-center space-x-2 pt-2 border-t border-[#30363d]/60 overflow-x-auto">
        <span className="text-[11px] text-gray-400 flex items-center space-x-1 shrink-0">
          <Filter className="w-3 h-3 text-sky-400" />
          <span>Subject:</span>
        </span>
        <div className="flex items-center space-x-1.5">
          {subjects.map((s) => {
            const isActive = selectedSubject === s;
            return (
              <button
                key={s}
                type="button"
                onClick={() => onSelectSubject(s)}
                className={`px-2.5 py-1 rounded text-xs transition-colors whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-slate-700 text-[#e6edf3] font-semibold border border-slate-600'
                    : 'text-gray-400 hover:text-gray-200 hover:bg-slate-800'
                }`}
              >
                {s}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
