import React from 'react';
import { ChevronLeft, ChevronRight, Inbox } from 'lucide-react';
import { TestRecordItem } from '../../types';
import { RecordRow } from './RecordRow';

interface RecordTableProps {
  records: TestRecordItem[];
  loading: boolean;
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
  onPageChange: (newPage: number) => void;
  onViewDetails: (recordId: string) => void;
}

export const RecordTable: React.FC<RecordTableProps> = ({
  records,
  loading,
  pagination,
  onPageChange,
  onViewDetails,
}) => {
  return (
    <div className="rounded-lg bg-[#161b22] border border-[#30363d] overflow-hidden">
      <div className="p-4 border-b border-[#30363d] flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-[#e6edf3]">Attempt History</h3>
          <p className="text-xs text-gray-400 mt-0.5">
            Full diagnostic breakdown of all completed mocks, chapter drills, and speed quizzes.
          </p>
        </div>
        <span className="text-xs font-mono text-gray-400">
          Showing {records.length} of {pagination.total} records
        </span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-[#30363d] bg-[#0d1117]/80 text-[10px] font-mono uppercase tracking-wider text-gray-400">
              <th className="py-2.5 px-4 font-semibold">Test Name</th>
              <th className="py-2.5 px-4 font-semibold">Score</th>
              <th className="py-2.5 px-4 font-semibold">Accuracy</th>
              <th className="py-2.5 px-4 font-semibold">Time</th>
              <th className="py-2.5 px-4 font-semibold">Date</th>
              <th className="py-2.5 px-4 font-semibold text-right">Details</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              [...Array(4)].map((_, i) => (
                <tr key={i} className="border-b border-[#30363d]/40 animate-pulse">
                  <td colSpan={6} className="py-4 px-4">
                    <div className="h-5 bg-slate-800/60 rounded w-full" />
                  </td>
                </tr>
              ))
            ) : records.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-gray-400">
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <Inbox className="w-8 h-8 text-gray-500" />
                    <span className="text-sm font-medium text-gray-300">No test records found</span>
                    <p className="text-xs text-gray-500 max-w-sm">
                      Complete your first practice drill or full-length mock exam to start logging your historical progression.
                    </p>
                  </div>
                </td>
              </tr>
            ) : (
              records.map((r) => (
                <RecordRow key={r.id} record={r} onViewDetails={onViewDetails} />
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      {pagination.totalPages > 1 && (
        <div className="p-3 border-t border-[#30363d] flex items-center justify-between text-xs text-gray-400">
          <div>
            Page <span className="font-mono text-[#e6edf3]">{pagination.page}</span> of{' '}
            <span className="font-mono text-[#e6edf3]">{pagination.totalPages}</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="button"
              disabled={pagination.page <= 1}
              onClick={() => onPageChange(pagination.page - 1)}
              className="px-2.5 py-1 rounded bg-[#0d1117] border border-[#30363d] text-gray-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center space-x-1 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              <span>Previous</span>
            </button>
            <button
              type="button"
              disabled={pagination.page >= pagination.totalPages}
              onClick={() => onPageChange(pagination.page + 1)}
              className="px-2.5 py-1 rounded bg-[#0d1117] border border-[#30363d] text-gray-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed flex items-center space-x-1 cursor-pointer"
            >
              <span>Next</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
