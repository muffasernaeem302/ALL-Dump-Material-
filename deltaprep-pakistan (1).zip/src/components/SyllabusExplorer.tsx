import React, { useState, useMemo } from 'react';
import {
  Layers,
  BookOpen,
  Search,
  Sparkles,
  CheckCircle2,
  Circle,
  Flame,
  ArrowRight,
  GraduationCap,
  ChevronRight,
  ChevronDown,
  Info,
  SlidersHorizontal,
  Copy,
  Check,
  Printer,
  Target,
  ShieldAlert,
  ListChecks,
  Compass,
} from 'lucide-react';
import { BoardId, Subject, NavTab, ExamId, SyllabusChapter } from '../types';
import { syllabusData, examSyllabusData, BOARDS, EXAMS } from '../data';

interface SyllabusExplorerProps {
  homeBoard: BoardId;
  targetExam: ExamId;
  onNavigateTab: (tab: NavTab) => void;
  onAskStudyBuddy: (query: string) => void;
  onStartTopicPractice: (subject: Subject, topicTitle: string) => void;
}

export const SyllabusExplorer: React.FC<SyllabusExplorerProps> = ({
  homeBoard,
  targetExam,
  onNavigateTab,
  onAskStudyBuddy,
  onStartTopicPractice,
}) => {
  // Navigation View Mode: 'exam' (Official University Blueprints) or 'board' (Provincial Textbooks)
  const [viewMode, setViewMode] = useState<'exam' | 'board'>('exam');

  // Exam blueprint selection
  const [selectedExamId, setSelectedExamId] = useState<ExamId>(targetExam);
  const [selectedNatCategory, setSelectedNatCategory] = useState<string>('NAT-ICS');

  // Board selection for provincial textbook mode
  const [selectedBoardId, setSelectedBoardId] = useState<BoardId>(homeBoard);

  // Filters
  const [selectedSubject, setSelectedSubject] = useState<Subject | 'All'>('All');
  const [selectedGrade, setSelectedGrade] = useState<'All' | 'Class 11' | 'Class 12'>('All');
  const [onlyDeltaTopics, setOnlyDeltaTopics] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Chapter collapse/expand state
  const [expandedChapterIds, setExpandedChapterIds] = useState<Record<string, boolean>>({});

  // Topic mastery persistence
  const [completedTopicIds, setCompletedTopicIds] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('deltaprep_completed_topics');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [copiedChecklist, setCopiedChecklist] = useState<boolean>(false);

  // Active Exam Blueprint
  const activeExamBlueprint = useMemo(() => {
    return (
      examSyllabusData.find((e) => e.examId === selectedExamId) ||
      examSyllabusData[0]
    );
  }, [selectedExamId]);

  // Active Board Data
  const activeBoardData = useMemo(() => {
    return (
      syllabusData.find((b) => b.boardId === selectedBoardId) ||
      syllabusData[0]
    );
  }, [selectedBoardId]);

  // Combined chapters based on viewMode
  const allCurrentChapters: SyllabusChapter[] = useMemo(() => {
    if (viewMode === 'exam') {
      return activeExamBlueprint.sections.flatMap((s) => s.chapters);
    } else {
      return activeBoardData.chapters;
    }
  }, [viewMode, activeExamBlueprint, activeBoardData]);

  // Filtered chapters with matching topics
  const filteredChapters = useMemo(() => {
    return allCurrentChapters
      .filter((ch) => {
        if (selectedSubject !== 'All' && ch.subject !== selectedSubject) return false;
        if (selectedGrade !== 'All' && ch.grade !== selectedGrade) return false;
        return true;
      })
      .map((ch) => {
        const matchingTopics = ch.topics.filter((topic) => {
          if (onlyDeltaTopics && !topic.isDelta) return false;
          if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase();
            const matchTitle = topic.title.toLowerCase().includes(q);
            const matchNotes = topic.highYieldNotes?.toLowerCase().includes(q);
            const matchChapter = ch.title.toLowerCase().includes(q);
            const matchBadge = topic.deltaBadge?.toLowerCase().includes(q);
            if (!matchTitle && !matchNotes && !matchChapter && !matchBadge) return false;
          }
          return true;
        });

        return {
          ...ch,
          topics: matchingTopics,
        };
      })
      .filter((ch) => ch.topics.length > 0);
  }, [allCurrentChapters, selectedSubject, selectedGrade, onlyDeltaTopics, searchQuery]);

  // Metrics
  const totalTopicsCount = useMemo(() => {
    return allCurrentChapters.reduce((acc, ch) => acc + ch.topics.length, 0);
  }, [allCurrentChapters]);

  const totalDeltaCount = useMemo(() => {
    return allCurrentChapters.reduce(
      (acc, ch) => acc + ch.topics.filter((t) => t.isDelta).length,
      0
    );
  }, [allCurrentChapters]);

  const completedCount = useMemo(() => {
    const allTopicIds = allCurrentChapters.flatMap((c) => c.topics.map((t) => t.id));
    return allTopicIds.filter((id) => completedTopicIds[id]).length;
  }, [allCurrentChapters, completedTopicIds]);

  const completionPct = totalTopicsCount > 0
    ? Math.round((completedCount / totalTopicsCount) * 100)
    : 0;

  // Available subjects in current scope
  const availableSubjects = useMemo(() => {
    const subjs = new Set<Subject>();
    allCurrentChapters.forEach((ch) => subjs.add(ch.subject));
    return Array.from(subjs);
  }, [allCurrentChapters]);

  // Handlers
  const toggleTopicCompletion = (topicId: string) => {
    setCompletedTopicIds((prev) => {
      const updated = { ...prev, [topicId]: !prev[topicId] };
      try {
        localStorage.setItem('deltaprep_completed_topics', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const toggleExpandChapter = (chapterId: string) => {
    setExpandedChapterIds((prev) => ({
      ...prev,
      [chapterId]: prev[chapterId] === false ? true : false,
    }));
  };

  const handleExpandAll = () => {
    const updated: Record<string, boolean> = {};
    filteredChapters.forEach((ch) => {
      updated[ch.id] = true;
    });
    setExpandedChapterIds(updated);
  };

  const handleCollapseAll = () => {
    const updated: Record<string, boolean> = {};
    filteredChapters.forEach((ch) => {
      updated[ch.id] = false;
    });
    setExpandedChapterIds(updated);
  };

  const handleCopyChecklist = () => {
    const lines: string[] = [];
    lines.push(`# ${viewMode === 'exam' ? activeExamBlueprint.examName : activeBoardData.boardName} Syllabus Checklist`);
    lines.push(`Total Topics: ${totalTopicsCount} | Completed: ${completedCount} (${completionPct}%)`);
    lines.push('');

    filteredChapters.forEach((ch) => {
      lines.push(`## Chapter ${ch.chapterNumber}: ${ch.title} (${ch.subject} · ${ch.grade})`);
      ch.topics.forEach((t) => {
        const checkMark = completedTopicIds[t.id] ? '[x]' : '[ ]';
        const deltaMark = t.isDelta ? ` [DELTA: ${t.deltaBadge || 'Gap'}]` : '';
        lines.push(`- ${checkMark} ${t.title} (${t.examWeightagePct}% weight)${deltaMark}`);
      });
      lines.push('');
    });

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedChecklist(true);
    setTimeout(() => setCopiedChecklist(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Header Card */}
      <div className="rounded-xl border border-[#30363d] bg-linear-to-r from-[#161b22] via-[#0d1117] to-[#161b22] p-4 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2.5">
              <span className="p-2 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-400">
                <Layers className="w-5 h-5" />
              </span>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                Comprehensive Syllabus Explorer & Chapter Blueprint
              </h2>
            </div>
            <p className="mt-1 text-xs sm:text-sm text-gray-400 max-w-3xl leading-relaxed">
              Explore the entire preparation syllabus with official test weightings, recommended chapter mappings,
              and cross-board delta gap alerts for Pakistani university entrance tests and provincial boards.
            </p>
          </div>

          {/* Real-Time Progress Tracker */}
          <div className="flex items-center space-x-3 self-start md:self-auto bg-[#0d1117] border border-[#30363d] rounded-lg p-3">
            <div className="text-center px-2 border-r border-[#30363d]">
              <div className="text-base font-bold text-sky-400 font-mono">{completionPct}%</div>
              <div className="text-[10px] text-gray-400">Mastered</div>
            </div>
            <div className="text-center px-2 border-r border-[#30363d]">
              <div className="text-base font-bold text-amber-400 font-mono">{totalDeltaCount}</div>
              <div className="text-[10px] text-gray-400">Delta Traps</div>
            </div>
            <div className="text-center px-2">
              <div className="text-base font-bold text-emerald-400 font-mono">
                {completedCount}/{totalTopicsCount}
              </div>
              <div className="text-[10px] text-gray-400">Topics Done</div>
            </div>
          </div>
        </div>

        {/* Global Progress Bar */}
        <div className="mt-4 w-full bg-slate-800 rounded-full h-2 overflow-hidden">
          <div
            className="bg-linear-to-r from-sky-500 via-indigo-400 to-emerald-400 h-2 rounded-full transition-all duration-300"
            style={{ width: `${Math.max(completionPct, 3)}%` }}
          />
        </div>
      </div>

      {/* Main View Mode Selector: University Entrance Test vs Provincial Textbooks */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-1.5 bg-[#161b22] border border-[#30363d] rounded-xl">
        <div className="flex items-center space-x-1.5 w-full sm:w-auto">
          <button
            id="syllabus-mode-exam"
            onClick={() => setViewMode('exam')}
            className={`flex-1 sm:flex-initial flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'exam'
                ? 'bg-sky-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <GraduationCap className="w-4 h-4" />
            <span>University Entry Test Blueprints</span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-white/20 text-white">
              NET · FAST · NAT · MDCAT
            </span>
          </button>

          <button
            id="syllabus-mode-board"
            onClick={() => setViewMode('board')}
            className={`flex-1 sm:flex-initial flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'board'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-gray-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>Provincial Textbook Boards</span>
            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-white/20 text-white">
              FBISE · Punjab · Sindh · KPK
            </span>
          </button>
        </div>

        {/* Action Controls: Copy Checklist & Print */}
        <div className="flex items-center space-x-2 self-end sm:self-auto">
          <button
            onClick={handleCopyChecklist}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-[#0d1117] border border-[#30363d] hover:bg-slate-800 text-xs text-gray-300 hover:text-white transition-colors cursor-pointer"
            title="Copy syllabus topics as study checklist to clipboard"
          >
            {copiedChecklist ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-sky-400" />}
            <span>{copiedChecklist ? 'Checklist Copied!' : 'Copy Checklist'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-md bg-[#0d1117] border border-[#30363d] hover:bg-slate-800 text-xs text-gray-300 hover:text-white transition-colors cursor-pointer"
            title="Print syllabus overview"
          >
            <Printer className="w-3.5 h-3.5 text-gray-400" />
            <span>Print</span>
          </button>
        </div>
      </div>

      {/* Primary Selector Bar (Exams or Boards) */}
      <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-4 space-y-4">
        {viewMode === 'exam' ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400 font-mono uppercase tracking-wider">Select University Entrance Exam:</span>
              <span className="text-[11px] text-sky-400 font-mono">Official Weightings & Chapter Tree</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {examSyllabusData.map((ex) => {
                const isSelected = selectedExamId === ex.examId;
                return (
                  <button
                    key={ex.examId}
                    onClick={() => setSelectedExamId(ex.examId)}
                    className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-sky-950/40 border-sky-500 shadow-sm'
                        : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{ex.shortName}</span>
                        {isSelected && <span className="h-2 w-2 rounded-full bg-sky-400" />}
                      </div>
                      <p className="text-[11px] text-gray-400 mt-1 line-clamp-1">{ex.examName}</p>
                    </div>
                    <div className="mt-2 text-[10px] font-mono text-sky-300/90 truncate">
                      {ex.patternName}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* If COMSATS NAT is selected, show NAT Category selector (NAT-ICS, NAT-IE, NAT-IM, NAT-IA) */}
            {selectedExamId === 'comsats_nat' && activeExamBlueprint.categoryVariants && (
              <div className="mt-3 p-3 rounded-lg bg-[#0d1117] border border-[#30363d] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-gray-300">NTS NAT Category Overview:</span>
                  <span className="text-gray-400 font-mono">90 Total MCQs</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {activeExamBlueprint.categoryVariants.map((cat) => (
                    <button
                      key={cat.categoryCode}
                      onClick={() => setSelectedNatCategory(cat.categoryCode)}
                      className={`p-2 rounded text-left border transition-colors cursor-pointer ${
                        selectedNatCategory === cat.categoryCode
                          ? 'bg-indigo-950/50 border-indigo-500 text-white'
                          : 'bg-[#161b22] border-[#30363d] text-gray-400 hover:text-gray-200'
                      }`}
                    >
                      <div className="text-xs font-bold font-mono">{cat.categoryCode}</div>
                      <div className="text-[10px] text-gray-400 truncate">{cat.targetGroup}</div>
                      <div className="text-[9px] text-indigo-300/80 mt-1 leading-tight">{cat.subjectBreakdown}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs text-gray-400 font-mono uppercase tracking-wider">Select Provincial Textbook Board:</span>
              <span className="text-[11px] text-indigo-400 font-mono">Curriculum Chapter Comparison</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {BOARDS.map((b) => {
                const isSelected = selectedBoardId === b.id;
                return (
                  <button
                    key={b.id}
                    onClick={() => setSelectedBoardId(b.id)}
                    className={`p-3 rounded-lg border text-left transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-indigo-950/40 border-indigo-500 shadow-sm'
                        : 'bg-[#0d1117] border-[#30363d] hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{b.name}</span>
                      {isSelected && <span className="h-2 w-2 rounded-full bg-indigo-400" />}
                    </div>
                    <div className="text-[11px] text-gray-400 mt-1 font-mono">{b.shortCode}</div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Official Weightings Banner (For Exam Mode) */}
        {viewMode === 'exam' && (
          <div className="mt-4 pt-3 border-t border-[#30363d]/80 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center space-x-2">
                <Target className="w-4 h-4 text-sky-400" />
                <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Official Section Weightings
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/10 border border-sky-500/20 text-sky-300 font-mono">
                  Official Pattern
                </span>
              </div>
              <span className="text-[11px] text-gray-400">
                100% Total Syllabus Coverage
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {activeExamBlueprint.officialWeightages.map((weight, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-lg bg-[#0d1117] border border-[#30363d] flex items-center justify-between"
                >
                  <div>
                    <div className="text-xs font-semibold text-gray-200">{weight.sectionName}</div>
                    {weight.questionCount && (
                      <div className="text-[10px] text-gray-400 font-mono">{weight.questionCount} Questions</div>
                    )}
                  </div>
                  <div className="text-right">
                    <span className="text-base font-bold font-mono text-sky-400">
                      {weight.weightagePct}%
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Academic Guidance Notice as recommended on PDF Page 5 */}
            <div className="p-3 rounded-lg bg-sky-950/20 border border-sky-800/30 flex items-start space-x-2 text-[11px] text-gray-300 leading-relaxed">
              <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-sky-300">Preparation Blueprint Map: </span>
                <span>{activeExamBlueprint.officialNotice}</span>
              </div>
            </div>
          </div>
        )}

        {/* Filter Controls: Search, Subject Pills, Grade Selector, Delta Toggle, Expand All */}
        <div className="pt-3 border-t border-[#30363d]/80 space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            {/* Real-time Search Input */}
            <div className="relative flex-1 min-w-[220px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-gray-400" />
              <input
                id="syllabus-search-input"
                type="text"
                placeholder="Search chapters, topics, formulas, or high-yield tricks..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-[#0d1117] border border-[#30363d] rounded-md text-xs text-white placeholder-gray-500 focus:outline-none focus:border-sky-500"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-2 text-[10px] text-gray-400 hover:text-white font-mono"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Expand / Collapse All Controls */}
            <div className="flex items-center space-x-2 shrink-0">
              <button
                onClick={handleExpandAll}
                className="px-2.5 py-1 rounded bg-[#0d1117] hover:bg-slate-800 border border-[#30363d] text-xs text-gray-300 hover:text-white transition-colors cursor-pointer"
              >
                Expand All
              </button>
              <button
                onClick={handleCollapseAll}
                className="px-2.5 py-1 rounded bg-[#0d1117] hover:bg-slate-800 border border-[#30363d] text-xs text-gray-300 hover:text-white transition-colors cursor-pointer"
              >
                Collapse All
              </button>
            </div>
          </div>

          {/* Subject Pills, Grade Selector, and Delta Filter */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1 text-xs">
            {/* Subject Selector */}
            <div className="flex items-center space-x-1 overflow-x-auto pb-1 scrollbar-none">
              <span className="text-gray-400 font-mono text-[11px] mr-1">Subject:</span>
              <button
                onClick={() => setSelectedSubject('All')}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  selectedSubject === 'All'
                    ? 'bg-sky-500 text-white font-medium'
                    : 'bg-[#0d1117] text-gray-300 hover:text-white border border-[#30363d]'
                }`}
              >
                All Subjects
              </button>
              {availableSubjects.map((subj) => (
                <button
                  key={subj}
                  onClick={() => setSelectedSubject(subj)}
                  className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer whitespace-nowrap ${
                    selectedSubject === subj
                      ? 'bg-sky-500 text-white font-medium'
                      : 'bg-[#0d1117] text-gray-300 hover:text-white border border-[#30363d]'
                  }`}
                >
                  {subj}
                </button>
              ))}
            </div>

            {/* Grade & Delta Toggle */}
            <div className="flex items-center space-x-2">
              <div className="flex items-center space-x-1 bg-[#0d1117] p-0.5 rounded border border-[#30363d]">
                {(['All', 'Class 11', 'Class 12'] as const).map((grade) => (
                  <button
                    key={grade}
                    onClick={() => setSelectedGrade(grade)}
                    className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                      selectedGrade === grade
                        ? 'bg-slate-700 text-white'
                        : 'text-gray-400 hover:text-gray-200'
                    }`}
                  >
                    {grade}
                  </button>
                ))}
              </div>

              {/* Delta Gaps Only Switch */}
              <button
                onClick={() => setOnlyDeltaTopics(!onlyDeltaTopics)}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded text-xs border transition-colors cursor-pointer ${
                  onlyDeltaTopics
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 font-medium'
                    : 'bg-[#0d1117] border-[#30363d] text-gray-400 hover:text-gray-300'
                }`}
              >
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>Delta / Traps Only</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Chapters & Topics Section */}
      <div className="space-y-4">
        {filteredChapters.length === 0 ? (
          <div className="rounded-xl border border-dashed border-[#30363d] p-10 text-center bg-[#161b22]/50">
            <Info className="w-8 h-8 text-gray-500 mx-auto mb-2" />
            <p className="text-sm text-gray-300 font-medium">No syllabus topics match the selected filters</p>
            <p className="text-xs text-gray-500 mt-1">Try resetting the search query or switching subject filters.</p>
            <button
              onClick={() => {
                setSelectedSubject('All');
                setSelectedGrade('All');
                setOnlyDeltaTopics(false);
                setSearchQuery('');
              }}
              className="mt-4 px-3.5 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          filteredChapters.map((chapter) => {
            const isCollapsed = expandedChapterIds[chapter.id] === false;
            const chapterCompletedCount = chapter.topics.filter((t) => completedTopicIds[t.id]).length;
            const chapterProgressPct = Math.round((chapterCompletedCount / chapter.topics.length) * 100);

            return (
              <div
                key={chapter.id}
                id={`chapter-${chapter.id}`}
                className="rounded-xl border border-[#30363d] bg-[#161b22] overflow-hidden shadow-xs transition-colors"
              >
                {/* Chapter Header Card */}
                <div
                  onClick={() => toggleExpandChapter(chapter.id)}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-[#1c2128] hover:bg-[#21262d] cursor-pointer transition-colors border-b border-[#30363d]"
                >
                  <div className="flex items-center space-x-3">
                    <button className="text-gray-400 hover:text-white transition-colors">
                      {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-sky-950/70 border border-sky-800/60 text-sky-300">
                          {chapter.subject} · {chapter.grade}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">
                          Chapter {chapter.chapterNumber}
                        </span>
                        {chapter.deltaTopicsCount > 0 && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-amber-500/15 border border-amber-500/30 text-amber-300">
                            {chapter.deltaTopicsCount} High-Yield Gaps
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-white mt-0.5">
                        {chapter.title}
                      </h3>
                    </div>
                  </div>

                  {/* Chapter Completion Bar & Quick Practice Action */}
                  <div className="mt-3 sm:mt-0 flex items-center space-x-3 self-end sm:self-auto">
                    <div className="text-right">
                      <div className="text-xs font-mono font-semibold text-gray-300">
                        {chapterCompletedCount}/{chapter.topics.length} Mastered
                      </div>
                      <div className="w-24 bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
                        <div
                          className="bg-emerald-400 h-1.5 rounded-full"
                          style={{ width: `${chapterProgressPct}%` }}
                        />
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onStartTopicPractice(chapter.subject, chapter.title);
                      }}
                      className="px-2.5 py-1.5 rounded bg-sky-600/90 hover:bg-sky-500 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition-colors"
                      title="Practice this chapter in Practice Engine"
                    >
                      <span>Practice</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Topics List */}
                {!isCollapsed && (
                  <div className="divide-y divide-[#30363d]/60">
                    {chapter.topics.map((topic) => {
                      const isCompleted = !!completedTopicIds[topic.id];

                      return (
                        <div
                          key={topic.id}
                          id={`topic-${topic.id}`}
                          className={`p-3 sm:p-4 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                            isCompleted ? 'bg-[#0d1117]/60 opacity-80' : 'hover:bg-slate-800/40'
                          }`}
                        >
                          {/* Checkbox and Topic Details */}
                          <div className="flex items-start space-x-3">
                            <button
                              onClick={() => toggleTopicCompletion(topic.id)}
                              className="mt-0.5 text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer"
                              title={isCompleted ? 'Mark as Incomplete' : 'Mark as Mastered'}
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                              ) : (
                                <Circle className="w-4 h-4 text-gray-500" />
                              )}
                            </button>

                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span
                                  className={`text-sm font-semibold ${
                                    isCompleted ? 'line-through text-gray-400' : 'text-[#e6edf3]'
                                  }`}
                                >
                                  {topic.title}
                                </span>

                                {/* Badges: Weightage, Difficulty, Delta */}
                                <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-sky-500/10 text-sky-400 border border-sky-500/20">
                                  {topic.examWeightagePct}% Exam Weight
                                </span>

                                <span
                                  className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                                    topic.conceptDifficulty === 'Hard' || topic.conceptDifficulty === 'Trick'
                                      ? 'bg-red-500/15 text-red-300 border border-red-500/30'
                                      : topic.conceptDifficulty === 'Medium'
                                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                      : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                  }`}
                                >
                                  {topic.conceptDifficulty}
                                </span>

                                {topic.isDelta && (
                                  <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center space-x-1">
                                    <Flame className="w-3 h-3 text-amber-400" />
                                    <span>{topic.deltaBadge || 'Cross-Board Delta Gap'}</span>
                                  </span>
                                )}
                              </div>

                              {/* High-yield tip / notes */}
                              {topic.highYieldNotes && (
                                <p className="text-xs text-gray-400 leading-relaxed max-w-2xl">
                                  <span className="text-sky-400/90 font-medium">Exam Tip: </span>
                                  {topic.highYieldNotes}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons: Ask AI Buddy & Practice MCQs */}
                          <div className="flex items-center space-x-2 self-end md:self-auto shrink-0">
                            <button
                              onClick={() => {
                                onAskStudyBuddy(
                                  `Explain the entry test high-yield concepts and common tricks for: "${topic.title}" from ${chapter.subject} Chapter ${chapter.chapterNumber} (${viewMode === 'exam' ? activeExamBlueprint.shortName : activeBoardData.boardName}). Give me 2 sample MCQs with step-by-step LaTeX solutions.`
                                );
                              }}
                              className="px-2.5 py-1 rounded bg-[#0d1117] hover:bg-slate-700 text-sky-300 hover:text-white border border-[#30363d] text-xs font-medium flex items-center space-x-1 cursor-pointer transition-colors"
                              title="Ask AI Study Buddy about this topic"
                            >
                              <Sparkles className="w-3 h-3 text-sky-400" />
                              <span>Ask AI Buddy</span>
                            </button>

                            <button
                              onClick={() => {
                                onStartTopicPractice(chapter.subject, topic.title);
                              }}
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-gray-200 text-xs font-medium flex items-center space-x-1 border border-[#30363d] cursor-pointer transition-colors"
                              title="Practice MCQs for this topic"
                            >
                              <BookOpen className="w-3 h-3 text-indigo-400" />
                              <span>Practice MCQs</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
