import React, { useState, useMemo } from 'react';
import {
  Layers,
  BookOpen,
  Search,
  Filter,
  Sparkles,
  CheckCircle2,
  Circle,
  AlertTriangle,
  Flame,
  ArrowRight,
  GraduationCap,
  ChevronRight,
  ChevronDown,
  Info,
  SlidersHorizontal,
} from 'lucide-react';
import { BoardId, Subject, NavTab, ExamId } from '../types';
import { syllabusData } from '../data';
import { BOARDS } from '../data';

interface SyllabusExplorerProps {
  homeBoard: BoardId;
  targetExam: ExamId;
  onNavigateTab: (tab: NavTab) => void;
  onAskStudyBuddy: (query: string) => void;
  onStartTopicPractice: (subject: Subject, topicTitle: string) => void;
}

export const SyllabusExplorer: React.FC<SyllabusExplorerProps> = ({
  homeBoard,
  targetExam,
  onNavigateTab,
  onAskStudyBuddy,
  onStartTopicPractice,
}) => {
  const [selectedBoard, setSelectedBoard] = useState<BoardId>(homeBoard);
  const [selectedSubject, setSelectedSubject] = useState<Subject | 'All'>('All');
  const [selectedGrade, setSelectedGrade] = useState<'All' | 'Class 11' | 'Class 12'>('All');
  const [onlyDeltaTopics, setOnlyDeltaTopics] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedChapterIds, setExpandedChapterIds] = useState<Record<string, boolean>>({});
  const [completedTopicIds, setCompletedTopicIds] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('deltaprep_completed_topics');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const activeBoardData = useMemo(() => {
    return (
      syllabusData.find((b) => b.boardId === selectedBoard) ||
      syllabusData.find((b) => b.boardId === 'federal') ||
      syllabusData[0]
    );
  }, [selectedBoard]);

  const filteredChapters = useMemo(() => {
    if (!activeBoardData) return [];

    return activeBoardData.chapters
      .filter((ch) => {
        if (selectedSubject !== 'All' && ch.subject !== selectedSubject) return false;
        if (selectedGrade !== 'All' && ch.grade !== selectedGrade) return false;
        return true;
      })
      .map((ch) => {
        const matchingTopics = ch.topics.filter((topic) => {
          if (onlyDeltaTopics && !topic.isDelta) return false;
          if (searchQuery.trim()) {
            const q = searchQuery.toLowerCase();
            const matchTitle = topic.title.toLowerCase().includes(q);
            const matchNotes = topic.highYieldNotes?.toLowerCase().includes(q);
            const matchChapter = ch.title.toLowerCase().includes(q);
            if (!matchTitle && !matchNotes && !matchChapter) return false;
          }
          return true;
        });

        return {
          ...ch,
          topics: matchingTopics,
        };
      })
      .filter((ch) => ch.topics.length > 0);
  }, [activeBoardData, selectedSubject, selectedGrade, onlyDeltaTopics, searchQuery]);

  const toggleTopicCompletion = (topicId: string) => {
    setCompletedTopicIds((prev) => {
      const updated = { ...prev, [topicId]: !prev[topicId] };
      try {
        localStorage.setItem('deltaprep_completed_topics', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const toggleExpandChapter = (chapterId: string) => {
    setExpandedChapterIds((prev) => ({
      ...prev,
      [chapterId]: prev[chapterId] === undefined ? false : !prev[chapterId],
    }));
  };

  // Metrics
  const totalTopicsInActiveBoard = useMemo(() => {
    return activeBoardData?.chapters.reduce((acc, ch) => acc + ch.topics.length, 0) || 0;
  }, [activeBoardData]);

  const totalDeltaCount = useMemo(() => {
    return (
      activeBoardData?.chapters.reduce(
        (acc, ch) => acc + ch.topics.filter((t) => t.isDelta).length,
        0
      ) || 0
    );
  }, [activeBoardData]);

  const completedCount = useMemo(() => {
    if (!activeBoardData) return 0;
    const allTopics = activeBoardData.chapters.flatMap((c) => c.topics.map((t) => t.id));
    return allTopics.filter((id) => completedTopicIds[id]).length;
  }, [activeBoardData, completedTopicIds]);

  const completionPct = totalTopicsInActiveBoard > 0
    ? Math.round((completedCount / totalTopicsInActiveBoard) * 100)
    : 0;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      {/* Top Banner / Hero */}
      <div className="rounded-xl border border-[#30363d] bg-linear-to-r from-[#161b22] via-[#0d1117] to-[#161b22] p-4 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                <Layers className="w-5 h-5" />
              </span>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                Multi-Board Syllabus Explorer & Topic Tree
              </h2>
            </div>
            <p className="mt-1 text-xs sm:text-sm text-gray-400 max-w-2xl leading-relaxed">
              Compare Punjab (PTB), Federal (FBISE), Sindh, and KPK textbooks side-by-side. Isolate high-yield
              chapters and identify cross-board gap topics tested in NUST NET, FAST NU-Test, COMSATS NAT, and MDCAT.
            </p>
          </div>

          {/* Quick Stats Pill */}
          <div className="flex items-center space-x-3 self-start md:self-auto bg-[#0d1117] border border-[#30363d] rounded-lg p-3">
            <div className="text-center px-2 border-r border-[#30363d]">
              <div className="text-base font-bold text-sky-400 font-mono">{completionPct}%</div>
              <div className="text-[10px] text-gray-400">Covered</div>
            </div>
            <div className="text-center px-2 border-r border-[#30363d]">
              <div className="text-base font-bold text-amber-400 font-mono">{totalDeltaCount}</div>
              <div className="text-[10px] text-gray-400">Delta Topics</div>
            </div>
            <div className="text-center px-2">
              <div className="text-base font-bold text-emerald-400 font-mono">{completedCount}/{totalTopicsInActiveBoard}</div>
              <div className="text-[10px] text-gray-400">Mastered</div>
            </div>
          </div>
        </div>

        {/* Progress bar */}
        <div className="mt-4 w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
          <div
            className="bg-linear-to-r from-sky-500 to-emerald-400 h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${Math.max(completionPct, 4)}%` }}
          />
        </div>
      </div>

      {/* Filter and Board Control Bar */}
      <div className="rounded-xl border border-[#30363d] bg-[#161b22] p-4 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          {/* Board Selector Pills */}
          <div className="flex items-center space-x-1.5 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs text-gray-400 font-mono mr-1">Board:</span>
            {BOARDS.map((b) => (
              <button
                key={b.id}
                onClick={() => setSelectedBoard(b.id)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  selectedBoard === b.id
                    ? 'bg-sky-500 text-white shadow-xs font-semibold'
                    : 'bg-[#0d1117] text-gray-300 hover:bg-slate-800 border border-[#30363d]'
                }`}
              >
                {b.name}
              </button>
            ))}
          </div>

          {/* Search Field */}
          <div className="relative min-w-[240px]">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-gray-400" />
            <input
              type="text"
              placeholder="Search topics, equations, keywords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-[#0d1117] border border-[#30363d] rounded-md text-xs text-white placeholder-gray-500 focus:outline-none focus:border-sky-500"
            />
          </div>
        </div>

        {/* Subject, Grade, and Delta Toggles */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#30363d]/60 text-xs">
          {/* Subject Pills */}
          <div className="flex items-center space-x-1.5 overflow-x-auto">
            <span className="text-gray-400 font-mono text-[11px]">Subject:</span>
            {(['All', 'Physics', 'Mathematics', 'Chemistry', 'Biology'] as const).map((subj) => (
              <button
                key={subj}
                onClick={() => setSelectedSubject(subj)}
                className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                  selectedSubject === subj
                    ? 'bg-indigo-600 text-white font-medium'
                    : 'bg-[#0d1117] text-gray-300 hover:text-white border border-[#30363d]'
                }`}
              >
                {subj}
              </button>
            ))}
          </div>

          {/* Grade Selector & Delta Only Switch */}
          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-1 bg-[#0d1117] p-0.5 rounded border border-[#30363d]">
              {(['All', 'Class 11', 'Class 12'] as const).map((grade) => (
                <button
                  key={grade}
                  onClick={() => setSelectedGrade(grade)}
                  className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                    selectedGrade === grade
                      ? 'bg-slate-700 text-white'
                      : 'text-gray-400 hover:text-gray-200'
                  }`}
                >
                  {grade}
                </button>
              ))}
            </div>

            {/* Delta Gaps Only Toggle */}
            <button
              onClick={() => setOnlyDeltaTopics(!onlyDeltaTopics)}
              className={`flex items-center space-x-1.5 px-2.5 py-1 rounded text-xs border transition-colors cursor-pointer ${
                onlyDeltaTopics
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 font-medium'
                  : 'bg-[#0d1117] border-[#30363d] text-gray-400 hover:text-gray-300'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>Delta Gaps Only</span>
            </button>
          </div>
        </div>
      </div>

      {/* Chapters & Topic Trees */}
      <div className="space-y-4">
        {filteredChapters.length === 0 ? (
          <div className="rounded-xl border border-dashed border-[#30363d] p-10 text-center bg-[#161b22]/50">
            <Info className="w-8 h-8 text-gray-500 mx-auto mb-2" />
            <p className="text-sm text-gray-300 font-medium">No syllabus topics match the selected filters</p>
            <p className="text-xs text-gray-500 mt-1">Try resetting the search query or switching the subject/board filter.</p>
            <button
              onClick={() => {
                setSelectedSubject('All');
                setSelectedGrade('All');
                setOnlyDeltaTopics(false);
                setSearchQuery('');
              }}
              className="mt-4 px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          filteredChapters.map((chapter) => {
            const isCollapsed = expandedChapterIds[chapter.id] === false;
            const chapterCompletedCount = chapter.topics.filter((t) => completedTopicIds[t.id]).length;
            const chapterProgressPct = Math.round((chapterCompletedCount / chapter.topics.length) * 100);

            return (
              <div
                key={chapter.id}
                id={`chapter-${chapter.id}`}
                className="rounded-xl border border-[#30363d] bg-[#161b22] overflow-hidden shadow-xs transition-colors"
              >
                {/* Chapter Header Card */}
                <div
                  onClick={() => toggleExpandChapter(chapter.id)}
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-[#1c2128] hover:bg-[#21262d] cursor-pointer transition-colors border-b border-[#30363d]"
                >
                  <div className="flex items-center space-x-3">
                    <button className="text-gray-400 hover:text-white transition-colors">
                      {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-sky-950/70 border border-sky-800/60 text-sky-300">
                          {chapter.subject} · {chapter.grade}
                        </span>
                        <span className="text-xs text-gray-400 font-mono">
                          Chapter {chapter.chapterNumber}
                        </span>
                        {chapter.deltaTopicsCount > 0 && (
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-amber-500/15 border border-amber-500/30 text-amber-300">
                            {chapter.deltaTopicsCount} Delta Gaps
                          </span>
                        )}
                      </div>

                      <h3 className="text-base font-bold text-white mt-0.5">
                        {chapter.title}
                      </h3>
                    </div>
                  </div>

                  {/* Chapter Completion Bar & Quick Actions */}
                  <div className="mt-3 sm:mt-0 flex items-center space-x-3 self-end sm:self-auto">
                    <div className="text-right">
                      <div className="text-xs font-mono font-semibold text-gray-300">
                        {chapterCompletedCount}/{chapter.topics.length} Mastered
                      </div>
                      <div className="w-24 bg-slate-800 rounded-full h-1.5 mt-1 overflow-hidden">
                        <div
                          className="bg-emerald-400 h-1.5 rounded-full"
                          style={{ width: `${chapterProgressPct}%` }}
                        />
                      </div>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onStartTopicPractice(chapter.subject, chapter.title);
                      }}
                      className="px-2.5 py-1.5 rounded bg-sky-600/90 hover:bg-sky-500 text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer transition-colors"
                      title="Practice this chapter in Practice Engine"
                    >
                      <span>Practice</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                {/* Topics List */}
                {!isCollapsed && (
                  <div className="divide-y divide-[#30363d]/60">
                    {chapter.topics.map((topic) => {
                      const isCompleted = !!completedTopicIds[topic.id];

                      return (
                        <div
                          key={topic.id}
                          id={`topic-${topic.id}`}
                          className={`p-3 sm:p-4 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                            isCompleted ? 'bg-[#0d1117]/60 opacity-80' : 'hover:bg-slate-800/40'
                          }`}
                        >
                          {/* Checkbox and Topic Details */}
                          <div className="flex items-start space-x-3">
                            <button
                              onClick={() => toggleTopicCompletion(topic.id)}
                              className="mt-0.5 text-gray-400 hover:text-emerald-400 transition-colors cursor-pointer"
                              title={isCompleted ? 'Mark as Incomplete' : 'Mark as Mastered'}
                            >
                              {isCompleted ? (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 fill-emerald-400/20" />
                              ) : (
                                <Circle className="w-4 h-4 text-gray-500" />
                              )}
                            </button>

                            <div className="space-y-1">
                              <div className="flex flex-wrap items-center gap-2">
                                <span
                                  className={`text-sm font-semibold ${
                                    isCompleted ? 'line-through text-gray-400' : 'text-[#e6edf3]'
                                  }`}
                                >
                                  {topic.title}
                                </span>

                                {/* Badges: Weightage, Difficulty, Delta */}
                                <span className="px-1.5 py-0.2 rounded text-[10px] font-mono bg-sky-500/10 text-sky-400 border border-sky-500/20">
                                  {topic.examWeightagePct}% Exam Weight
                                </span>

                                <span
                                  className={`px-1.5 py-0.2 rounded text-[10px] font-mono ${
                                    topic.conceptDifficulty === 'Hard' || topic.conceptDifficulty === 'Trick'
                                      ? 'bg-red-500/15 text-red-300 border border-red-500/30'
                                      : topic.conceptDifficulty === 'Medium'
                                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                                      : 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                  }`}
                                >
                                  {topic.conceptDifficulty}
                                </span>

                                {topic.isDelta && (
                                  <span className="px-1.5 py-0.2 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center space-x-1">
                                    <Flame className="w-3 h-3 text-amber-400" />
                                    <span>{topic.deltaBadge || 'Cross-Board Delta Gap'}</span>
                                  </span>
                                )}
                              </div>

                              {/* High-yield tip / notes */}
                              {topic.highYieldNotes && (
                                <p className="text-xs text-gray-400 leading-relaxed max-w-2xl">
                                  <span className="text-sky-400/90 font-medium">Exam Tip: </span>
                                  {topic.highYieldNotes}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center space-x-2 self-end md:self-auto shrink-0">
                            <button
                              onClick={() => {
                                onAskStudyBuddy(
                                  `Explain the entry test high-yield concepts and common tricks for: "${topic.title}" from ${chapter.subject} Chapter ${chapter.chapterNumber} (${activeBoardData.boardName}). Give me 2 sample MCQs with step-by-step LaTeX solutions.`
                                );
                              }}
                              className="px-2.5 py-1 rounded bg-[#0d1117] hover:bg-slate-700 text-sky-300 hover:text-white border border-[#30363d] text-xs font-medium flex items-center space-x-1 cursor-pointer transition-colors"
                              title="Ask AI Study Buddy about this topic"
                            >
                              <Sparkles className="w-3 h-3 text-sky-400" />
                              <span>Ask AI Buddy</span>
                            </button>

                            <button
                              onClick={() => {
                                onStartTopicPractice(chapter.subject, topic.title);
                              }}
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-gray-200 text-xs font-medium flex items-center space-x-1 border border-[#30363d] cursor-pointer transition-colors"
                              title="Practice MCQs for this topic"
                            >
                              <BookOpen className="w-3 h-3 text-indigo-400" />
                              <span>Practice MCQs</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
