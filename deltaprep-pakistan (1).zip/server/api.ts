import { Request, Response, Router } from 'express';
import {
  loadDatabase,
  withTransaction,
  calculateXP,
  calculateRollingAccuracy,
  TestRecordModel,
  TestAnswerModel,
  TestType,
  TopicProgressModel,
} from './db';

const router = Router();

// Helper to get authenticated user ID (from header, query, body, or fallback to default user)
function getAuthUserId(req: Request): string {
  const headerUser = req.headers['x-user-id'] as string;
  if (headerUser) return headerUser;

  const headerEmail = req.headers['x-user-email'] as string;
  if (headerEmail) {
    const db = loadDatabase();
    const user = db.users.find((u) => u.email.toLowerCase() === headerEmail.toLowerCase());
    if (user) return user.id;
  }

  if (req.body?.userId) return req.body.userId;
  if (req.query?.userId) return req.query.userId as string;

  return 'usr_default';
}

// ==========================================
// 1. RECORDS API
// ==========================================

/**
 * GET /api/records/summary
 * Returns overall statistics for the authenticated user from real database records.
 */
router.get('/records/summary', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const db = loadDatabase();
    const userRecords = db.testRecords.filter((r) => r.userId === userId);

    if (userRecords.length === 0) {
      res.json({
        testsCompleted: 0,
        averageScore: 0,
        accuracy: 0,
        bestScore: 0,
        totalTime: 0,
      });
      return;
    }

    const testsCompleted = userRecords.length;
    const totalScore = userRecords.reduce((acc, r) => acc + r.score, 0);
    const totalAccuracy = userRecords.reduce((acc, r) => acc + r.accuracy, 0);
    const bestScore = Math.max(...userRecords.map((r) => r.score));
    const totalTime = userRecords.reduce((acc, r) => acc + r.timeTaken, 0);

    res.json({
      testsCompleted,
      averageScore: Math.round((totalScore / testsCompleted) * 10) / 10,
      accuracy: Math.round((totalAccuracy / testsCompleted) * 10) / 10,
      bestScore,
      totalTime,
    });
  } catch (error: any) {
    console.error('Error fetching records summary:', error);
    res.status(500).json({ error: 'Failed to fetch records summary' });
  }
});

/**
 * GET /api/records
 * Returns paginated and filtered records for authenticated user.
 */
router.get('/records', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const db = loadDatabase();

    const page = Math.max(1, parseInt(req.query.page as string) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit as string) || 20));
    const type = req.query.type as TestType | undefined;
    const subject = req.query.subject as string | undefined;
    const fromDate = req.query.from as string | undefined;
    const toDate = req.query.to as string | undefined;

    let userRecords = db.testRecords.filter((r) => r.userId === userId);

    if (type && type !== ('ALL' as any)) {
      userRecords = userRecords.filter((r) => r.testType === type);
    }

    if (subject && subject !== 'All' && subject !== 'All Subjects') {
      userRecords = userRecords.filter(
        (r) => r.subject?.toLowerCase() === subject.toLowerCase()
      );
    }

    if (fromDate) {
      const fromTime = new Date(fromDate).getTime();
      userRecords = userRecords.filter((r) => new Date(r.attemptedAt).getTime() >= fromTime);
    }

    if (toDate) {
      const toTime = new Date(toDate).getTime();
      userRecords = userRecords.filter((r) => new Date(r.attemptedAt).getTime() <= toTime);
    }

    // Sort descending by date
    userRecords.sort(
      (a, b) => new Date(b.attemptedAt).getTime() - new Date(a.attemptedAt).getTime()
    );

    const total = userRecords.length;
    const totalPages = Math.ceil(total / limit) || 1;
    const startIndex = (page - 1) * limit;
    const paginatedRecords = userRecords.slice(startIndex, startIndex + limit);

    res.json({
      records: paginatedRecords,
      pagination: {
        page,
        limit,
        total,
        totalPages,
      },
    });
  } catch (error: any) {
    console.error('Error fetching records:', error);
    res.status(500).json({ error: 'Failed to fetch records' });
  }
});

/**
 * GET /api/records/:id
 * Detailed test record with answers breakdown and topic performance.
 */
router.get('/records/:id', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const recordId = req.params.id;
    const db = loadDatabase();

    const record = db.testRecords.find((r) => r.id === recordId);
    if (!record) {
      res.status(404).json({ error: 'Record not found' });
      return;
    }

    // User ownership check
    if (record.userId !== userId) {
      res.status(403).json({ error: 'Unauthorized to access this record' });
      return;
    }

    const answers = db.testAnswers.filter((a) => a.recordId === recordId);

    res.json({
      record,
      answers,
    });
  } catch (error: any) {
    console.error('Error fetching record detail:', error);
    res.status(500).json({ error: 'Failed to fetch record detail' });
  }
});

/**
 * DELETE /api/records/:id
 */
router.delete('/records/:id', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const recordId = req.params.id;

    withTransaction((db) => {
      const index = db.testRecords.findIndex((r) => r.id === recordId);
      if (index === -1) {
        res.status(404).json({ error: 'Record not found' });
        return;
      }

      if (db.testRecords[index].userId !== userId) {
        res.status(403).json({ error: 'Unauthorized to delete this record' });
        return;
      }

      db.testRecords.splice(index, 1);
      db.testAnswers = db.testAnswers.filter((a) => a.recordId !== recordId);
      res.json({ success: true, message: 'Record removed successfully' });
    });
  } catch (error: any) {
    console.error('Error deleting record:', error);
    res.status(500).json({ error: 'Failed to delete record' });
  }
});

/**
 * POST /api/records
 * Core test submission endpoint.
 * Validates, calculates score/accuracy, records answers, updates TopicProgress,
 * computes server-side XP, verifies level unlock requirements, and executes in an atomic transaction.
 */
router.post('/records', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const {
      testId = `test_${Date.now()}`,
      testName = 'Practice Session',
      testType = 'PRACTICE',
      subject = 'General',
      answers = [],
      timeTaken = 0,
      topicId,
      level,
    } = req.body;

    if (!Array.isArray(answers) || answers.length === 0) {
      res.status(400).json({ error: 'A test submission must contain at least one question answer.' });
      return;
    }

    const result = withTransaction((db) => {
      // 1. Calculate Score, Correct, Incorrect, and Skipped
      let correctAnswers = 0;
      let incorrectAnswers = 0;
      let skippedAnswers = 0;
      const topicBreakdown: Record<string, { total: number; correct: number; accuracy: number }> = {};

      const recordId = `rec_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
      const savedAnswers: TestAnswerModel[] = [];

      answers.forEach((ans: any, idx: number) => {
        const isSkipped = ans.isSkipped || ans.selectedOptionIndex === null || ans.selectedOptionIndex === undefined;
        let isCorrect = false;

        if (isSkipped) {
          skippedAnswers++;
        } else if (
          ans.selectedOptionIndex === ans.correctIndex ||
          ans.selectedAnswer === ans.correctAnswer
        ) {
          isCorrect = true;
          correctAnswers++;
        } else {
          incorrectAnswers++;
        }

        // Topic breakdown accounting
        const tName = ans.topicName || ans.topic || 'General';
        if (!topicBreakdown[tName]) {
          topicBreakdown[tName] = { total: 0, correct: 0, accuracy: 0 };
        }
        topicBreakdown[tName].total += 1;
        if (isCorrect) topicBreakdown[tName].correct += 1;

        savedAnswers.push({
          id: `ans_${recordId}_${idx}`,
          recordId,
          questionId: ans.questionId || `q_${idx}`,
          question: ans.question || '',
          options: ans.options || [],
          selectedAnswer: ans.selectedAnswer || null,
          selectedOptionIndex: ans.selectedOptionIndex ?? null,
          correctAnswer: ans.correctAnswer || '',
          correctIndex: ans.correctIndex ?? 0,
          isCorrect,
          isSkipped,
          timeTaken: ans.timeTaken || 0,
          explanation: ans.explanation || '',
          boardOrigin: ans.boardOrigin || 'Exam Standard',
        });
      });

      // Calculate topic accuracies
      Object.keys(topicBreakdown).forEach((k) => {
        const item = topicBreakdown[k];
        item.accuracy = item.total > 0 ? Math.round((item.correct / item.total) * 1000) / 10 : 0;
      });

      const totalQuestions = answers.length;
      // Formula: accuracy = (correctAnswers / totalQuestions) * 100 (Safe division by zero handled)
      const accuracy = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 1000) / 10 : 0;
      const score = correctAnswers;

      // 2. Progressive Server-Side XP Calculation
      const targetLevel = Number(level) || 1;
      const xpEarned = calculateXP({
        accuracy,
        questions: totalQuestions,
        level: targetLevel,
      });

      // 3. Update User XP
      let user = db.users.find((u) => u.id === userId);
      if (!user) {
        user = {
          id: userId,
          name: 'Student',
          email: `${userId}@student.deltaprep.pk`,
          streakDays: 1,
          xp: 0,
          createdAt: new Date().toISOString(),
        };
        db.users.push(user);
      }
      user.xp += xpEarned;

      // 4. Update Topic Mastery & Granular Levels
      const newlyUnlockedLevels: string[] = [];
      const affectedTopicId = topicId || (db.topics.length > 0 ? db.topics[0].id : null);

      if (affectedTopicId) {
        const currentLevelId = `lvl_${affectedTopicId}_${targetLevel}`;
        let progress = db.topicProgress.find(
          (p) => p.userId === userId && p.levelId === currentLevelId
        );

        if (!progress) {
          progress = {
            id: `prog_${userId}_${currentLevelId}`,
            userId,
            levelId: currentLevelId,
            topicId: affectedTopicId,
            subjectId: db.topics.find((t) => t.id === affectedTopicId)?.subjectId || 'subj_physics',
            level: targetLevel,
            attempts: 0,
            correct: 0,
            accuracy: 0,
            xp: 0,
            completed: false,
            unlocked: targetLevel === 1,
            lastAttemptedAt: null,
          };
          db.topicProgress.push(progress);
        }

        // Apply rolling/cumulative accuracy
        const previousCorrect = progress.correct;
        const previousQuestions = progress.attempts;
        progress.attempts += totalQuestions;
        progress.correct += correctAnswers;
        progress.accuracy = calculateRollingAccuracy(
          previousCorrect,
          previousQuestions,
          correctAnswers,
          totalQuestions
        );
        progress.xp += xpEarned;
        progress.lastAttemptedAt = new Date().toISOString();

        // Level Completion Check: accuracy >= 80% AND minimum 10 questions attempted
        const levelConfig = db.topicLevels.find((l) => l.id === currentLevelId);
        const requiredAccuracy = levelConfig?.unlockAccuracy || 80;
        const minQuestions = levelConfig?.minQuestionsRequired || 10;

        if (progress.accuracy >= requiredAccuracy && progress.attempts >= minQuestions) {
          progress.completed = true;

          // Check if sequential next level exists and unlock it
          if (targetLevel < 3) {
            const nextLevelNumber = targetLevel + 1;
            const nextLevelId = `lvl_${affectedTopicId}_${nextLevelNumber}`;
            let nextProgress = db.topicProgress.find(
              (p) => p.userId === userId && p.levelId === nextLevelId
            );

            if (!nextProgress) {
              nextProgress = {
                id: `prog_${userId}_${nextLevelId}`,
                userId,
                levelId: nextLevelId,
                topicId: affectedTopicId,
                subjectId: progress.subjectId,
                level: nextLevelNumber,
                attempts: 0,
                correct: 0,
                accuracy: 0,
                xp: 0,
                completed: false,
                unlocked: true,
                lastAttemptedAt: null,
              };
              db.topicProgress.push(nextProgress);
              newlyUnlockedLevels.push(nextLevelId);
            } else if (!nextProgress.unlocked) {
              nextProgress.unlocked = true;
              newlyUnlockedLevels.push(nextLevelId);
            }
          }
        }
      }

      // 5. Save TestRecord
      const newRecord: TestRecordModel = {
        id: recordId,
        userId,
        testId,
        testName,
        testType: testType as TestType,
        subject,
        score,
        totalQuestions,
        correctAnswers,
        incorrectAnswers,
        skippedAnswers,
        accuracy,
        timeTaken,
        topicBreakdown,
        xpEarned,
        unlockedLevelsCount: newlyUnlockedLevels.length,
        attemptedAt: new Date().toISOString(),
      };

      db.testRecords.push(newRecord);
      db.testAnswers.push(...savedAnswers);

      return {
        record: newRecord,
        answers: savedAnswers,
        xpAwarded: xpEarned,
        newlyUnlockedLevels,
        userTotalXp: user.xp,
      };
    });

    res.status(201).json({
      success: true,
      ...result,
    });
  } catch (error: any) {
    console.error('Error submitting test record:', error);
    res.status(500).json({ error: 'Failed to process and record test submission' });
  }
});

// ==========================================
// 2. QUESTION BANK SCALABILITY API
// ==========================================

/**
 * GET /api/questions
 * Server-side pagination with cursor support and granular filtering.
 * Prevents huge payloads from overloading React state.
 */
router.get('/questions', (req: Request, res: Response) => {
  try {
    const db = loadDatabase();
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit as string) || 20));
    const cursor = req.query.cursor as string | undefined;
    const page = req.query.page ? parseInt(req.query.page as string) : undefined;
    const subject = req.query.subject as string | undefined;
    const topic = req.query.topic as string | undefined;
    const level = req.query.level ? parseInt(req.query.level as string) : undefined;
    const difficulty = req.query.difficulty as string | undefined;

    let filtered = [...db.questions];

    if (subject && subject !== 'All') {
      const matchedSubj = db.subjects.find(
        (s) => s.name.toLowerCase() === subject.toLowerCase() || s.id === subject
      );
      if (matchedSubj) {
        filtered = filtered.filter((q) => q.subjectId === matchedSubj.id);
      }
    }

    if (topic && topic !== 'All') {
      const matchedTopic = db.topics.find(
        (t) =>
          t.slug.toLowerCase() === topic.toLowerCase() ||
          t.name.toLowerCase() === topic.toLowerCase() ||
          t.id === topic
      );
      if (matchedTopic) {
        filtered = filtered.filter((q) => q.topicId === matchedTopic.id);
      }
    }

    if (level) {
      filtered = filtered.filter((q) => q.level === level);
    }

    if (difficulty && difficulty !== 'All') {
      filtered = filtered.filter((q) => q.difficulty.toLowerCase() === difficulty.toLowerCase());
    }

    let startIndex = 0;
    if (cursor) {
      const cursorIndex = filtered.findIndex((q) => q.id === cursor);
      if (cursorIndex !== -1) {
        startIndex = cursorIndex + 1;
      }
    } else if (page) {
      startIndex = (page - 1) * limit;
    }

    const sliced = filtered.slice(startIndex, startIndex + limit);
    const hasMore = startIndex + limit < filtered.length;
    const nextCursor = hasMore && sliced.length > 0 ? sliced[sliced.length - 1].id : null;

    res.json({
      questions: sliced,
      total: filtered.length,
      hasMore,
      nextCursor,
    });
  } catch (error: any) {
    console.error('Error fetching questions:', error);
    res.status(500).json({ error: 'Failed to fetch questions' });
  }
});

/**
 * GET /api/questions/random
 * Fetch a random selection of questions for quick drills or mocks without dumping all data.
 */
router.get('/questions/random', (req: Request, res: Response) => {
  try {
    const db = loadDatabase();
    const count = Math.min(50, Math.max(1, parseInt(req.query.count as string) || 10));
    const subject = req.query.subject as string | undefined;
    const topic = req.query.topic as string | undefined;
    const level = req.query.level ? parseInt(req.query.level as string) : undefined;

    let pool = [...db.questions];

    if (subject && subject !== 'All') {
      const matched = db.subjects.find((s) => s.name.toLowerCase() === subject.toLowerCase() || s.id === subject);
      if (matched) pool = pool.filter((q) => q.subjectId === matched.id);
    }

    if (topic && topic !== 'All') {
      const matched = db.topics.find((t) => t.slug === topic || t.name === topic || t.id === topic);
      if (matched) pool = pool.filter((q) => q.topicId === matched.id);
    }

    if (level) {
      pool = pool.filter((q) => q.level === level);
    }

    // Fisher-Yates shuffle
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }

    res.json({
      questions: pool.slice(0, count),
      totalAvailable: pool.length,
    });
  } catch (error: any) {
    console.error('Error fetching random questions:', error);
    res.status(500).json({ error: 'Failed to fetch random questions' });
  }
});

/**
 * GET /api/questions/:id
 */
router.get('/questions/:id', (req: Request, res: Response) => {
  try {
    const db = loadDatabase();
    const question = db.questions.find((q) => q.id === req.params.id);
    if (!question) {
      res.status(404).json({ error: 'Question not found' });
      return;
    }
    res.json(question);
  } catch (error: any) {
    console.error('Error fetching question:', error);
    res.status(500).json({ error: 'Failed to fetch question' });
  }
});

// ==========================================
// 3. SUBJECTS & TOPICS ARCHITECTURE API
// ==========================================

router.get('/subjects', (req: Request, res: Response) => {
  const db = loadDatabase();
  res.json(db.subjects);
});

router.get('/subjects/:id/topics', (req: Request, res: Response) => {
  const db = loadDatabase();
  const topics = db.topics.filter((t) => t.subjectId === req.params.id);
  res.json(topics);
});

router.get('/topics/:id/levels', (req: Request, res: Response) => {
  const db = loadDatabase();
  const levels = db.topicLevels.filter((l) => l.topicId === req.params.id);
  levels.sort((a, b) => a.level - b.level);
  res.json(levels);
});

// ==========================================
// 4. PROGRESSIVE TOPIC MASTERY API
// ==========================================

/**
 * GET /api/mastery
 * Returns comprehensive topic mastery, overall subject percentages, and level unlocking state.
 */
router.get('/mastery', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const db = loadDatabase();

    const userProgress = db.topicProgress.filter((p) => p.userId === userId);

    // Compute subject summaries
    const subjectMastery: Record<
      string,
      {
        subject: any;
        overallMastery: number;
        totalXP: number;
        unlockedCount: number;
        totalLevels: number;
        topics: any[];
      }
    > = {};

    db.subjects.forEach((subj) => {
      const subjTopics = db.topics.filter((t) => t.subjectId === subj.id);
      let totalLevelsInSubj = 0;
      let unlockedLevelsInSubj = 0;
      let totalSubjAccuracy = 0;
      let evaluatedCount = 0;
      let totalSubjXP = 0;

      const topicDetails = subjTopics.map((top) => {
        const levels = db.topicLevels.filter((l) => l.topicId === top.id).sort((a, b) => a.level - b.level);
        totalLevelsInSubj += levels.length;

        let topicAccuracySum = 0;
        let topicAttemptsSum = 0;
        let topicCorrectSum = 0;

        const levelStates = levels.map((lvl) => {
          const prog = userProgress.find((p) => p.levelId === lvl.id);
          const isUnlocked = prog ? prog.unlocked : lvl.level === 1;
          const accuracy = prog ? prog.accuracy : 0;
          const attempts = prog ? prog.attempts : 0;
          const correct = prog ? prog.correct : 0;
          const xp = prog ? prog.xp : 0;
          const completed = prog ? prog.completed : false;

          if (isUnlocked) unlockedLevelsInSubj++;
          totalSubjXP += xp;
          topicAttemptsSum += attempts;
          topicCorrectSum += correct;

          if (attempts > 0) {
            totalSubjAccuracy += accuracy;
            evaluatedCount++;
          }

          return {
            ...lvl,
            unlocked: isUnlocked,
            accuracy,
            attempts,
            correct,
            xp,
            completed,
            lastAttemptedAt: prog?.lastAttemptedAt || null,
          };
        });

        // Granular Topic Mastery calculation
        const topicOverallMastery =
          topicAttemptsSum > 0
            ? Math.round((topicCorrectSum / topicAttemptsSum) * 1000) / 10
            : 0;

        return {
          ...top,
          overallMastery: topicOverallMastery,
          levels: levelStates,
        };
      });

      const overallMastery =
        evaluatedCount > 0 ? Math.round((totalSubjAccuracy / evaluatedCount) * 10) / 10 : 0;

      subjectMastery[subj.id] = {
        subject: subj,
        overallMastery,
        totalXP: totalSubjXP,
        unlockedCount: unlockedLevelsInSubj,
        totalLevels: totalLevelsInSubj,
        topics: topicDetails,
      };
    });

    res.json({
      subjects: subjectMastery,
      userTotalXP: db.users.find((u) => u.id === userId)?.xp || 0,
    });
  } catch (error: any) {
    console.error('Error fetching mastery:', error);
    res.status(500).json({ error: 'Failed to fetch topic mastery' });
  }
});

/**
 * GET /api/mastery/:topicId
 */
router.get('/mastery/:topicId', (req: Request, res: Response) => {
  try {
    const userId = getAuthUserId(req);
    const topicId = req.params.topicId;
    const db = loadDatabase();

    const topic = db.topics.find((t) => t.id === topicId);
    if (!topic) {
      res.status(404).json({ error: 'Topic not found' });
      return;
    }

    const levels = db.topicLevels.filter((l) => l.topicId === topicId).sort((a, b) => a.level - b.level);
    const userProgress = db.topicProgress.filter((p) => p.userId === userId && p.topicId === topicId);

    const detailedLevels = levels.map((lvl) => {
      const prog = userProgress.find((p) => p.levelId === lvl.id);
      return {
        ...lvl,
        unlocked: prog ? prog.unlocked : lvl.level === 1,
        accuracy: prog ? prog.accuracy : 0,
        attempts: prog ? prog.attempts : 0,
        correct: prog ? prog.correct : 0,
        xp: prog ? prog.xp : 0,
        completed: prog ? prog.completed : false,
      };
    });

    res.json({
      topic,
      levels: detailedLevels,
    });
  } catch (error: any) {
    console.error('Error fetching topic mastery:', error);
    res.status(500).json({ error: 'Failed to fetch topic mastery' });
  }
});

export default router;
