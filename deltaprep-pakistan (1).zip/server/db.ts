import fs from 'fs';
import path from 'path';

// --- Types & Interfaces for Database Models ---

export type TestType = 'MOCK' | 'SUBJECT' | 'PRACTICE';

export interface SubjectModel {
  id: string;
  name: string;
  code: string;
  icon?: string;
}

export interface TopicModel {
  id: string;
  subjectId: string;
  name: string;
  slug: string;
}

export interface TopicLevelModel {
  id: string;
  topicId: string;
  level: number; // 1, 2, 3
  name: string; // e.g. "Level 1 — Basic Formulas", "Level 2 — Applied Dynamics", "Level 3 — Advanced Entrance Mock"
  xpReward: number;
  unlockAccuracy: number; // default 80
  minQuestionsRequired: number; // default 10
}

export interface QuestionModel {
  id: string;
  subjectId: string;
  topicId: string;
  level: number; // 1, 2, 3
  difficulty: 'Easy' | 'Medium' | 'Hard';
  question: string;
  options: string[];
  correctAnswer: string; // "A) ..." or option text
  correctIndex: number; // 0, 1, 2, 3
  explanation: string;
  boardOrigin: string;
  timeTargetSeconds: number;
  deltaTagged?: boolean;
  createdAt: string;
}

export interface TopicProgressModel {
  id: string;
  userId: string;
  levelId: string;
  topicId: string;
  subjectId: string;
  level: number;
  attempts: number;
  correct: number;
  accuracy: number;
  xp: number;
  completed: boolean;
  unlocked: boolean;
  lastAttemptedAt: string | null;
}

export interface TestRecordModel {
  id: string;
  userId: string;
  testId: string;
  testName: string;
  testType: TestType;
  subject?: string;
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  skippedAnswers: number;
  accuracy: number;
  timeTaken: number; // in seconds
  topicBreakdown: Record<string, { total: number; correct: number; accuracy: number }>;
  xpEarned: number;
  unlockedLevelsCount: number;
  attemptedAt: string;
}

export interface TestAnswerModel {
  id: string;
  recordId: string;
  questionId: string;
  question: string;
  options: string[];
  selectedAnswer: string | null;
  selectedOptionIndex: number | null;
  correctAnswer: string;
  correctIndex: number;
  isCorrect: boolean;
  isSkipped: boolean;
  timeTaken: number;
  explanation: string;
  boardOrigin: string;
}

export interface UserModel {
  id: string;
  name: string;
  email: string;
  streakDays: number;
  xp: number;
  createdAt: string;
}

interface DatabaseSchema {
  users: UserModel[];
  subjects: SubjectModel[];
  topics: TopicModel[];
  topicLevels: TopicLevelModel[];
  questions: QuestionModel[];
  topicProgress: TopicProgressModel[];
  testRecords: TestRecordModel[];
  testAnswers: TestAnswerModel[];
}

// Database storage file path
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

// Memory cache
let dbCache: DatabaseSchema | null = null;

// Ensure database directory exists
function ensureDbDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

// Load database from disk
export function loadDatabase(): DatabaseSchema {
  if (dbCache) return dbCache;

  ensureDbDir();
  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(content);
      return dbCache!;
    } catch (e) {
      console.error('Failed to parse database file, re-initializing seed data:', e);
    }
  }

  // Seed default dataset
  dbCache = getInitialSeedData();
  saveDatabase(dbCache);
  return dbCache;
}

// Save database to disk atomically
export function saveDatabase(data: DatabaseSchema): void {
  ensureDbDir();
  dbCache = data;
  const tempPath = `${DB_FILE}.tmp`;
  fs.writeFileSync(tempPath, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tempPath, DB_FILE);
}

// Transaction helper to safely mutate DB
export function withTransaction<T>(callback: (db: DatabaseSchema) => T): T {
  const db = loadDatabase();
  const result = callback(db);
  saveDatabase(db);
  return result;
}

// --- Initial Seed Generator ---
function getInitialSeedData(): DatabaseSchema {
  const defaultUser: UserModel = {
    id: 'usr_default',
    name: 'Hamza Malik',
    email: 'hamza.malik@student.nust.edu.pk',
    streakDays: 14,
    xp: 850,
    createdAt: new Date().toISOString(),
  };

  const subjects: SubjectModel[] = [
    { id: 'subj_physics', name: 'Physics', code: 'PHY', icon: 'Atom' },
    { id: 'subj_math', name: 'Mathematics', code: 'MATH', icon: 'Calculator' },
    { id: 'subj_chemistry', name: 'Chemistry', code: 'CHEM', icon: 'FlaskConical' },
    { id: 'subj_biology', name: 'Biology', code: 'BIO', icon: 'Dna' },
    { id: 'subj_analytical', name: 'Analytical & IQ', code: 'IQ', icon: 'Brain' },
    { id: 'subj_english', name: 'English', code: 'ENG', icon: 'BookOpen' },
  ];

  const topics: TopicModel[] = [
    // Physics Topics
    { id: 'top_phy_work_energy', subjectId: 'subj_physics', name: 'Work & Energy', slug: 'work-energy' },
    { id: 'top_phy_mechanics', subjectId: 'subj_physics', name: 'Mechanics & Circular Motion', slug: 'mechanics' },
    { id: 'top_phy_electromagnetism', subjectId: 'subj_physics', name: 'Electromagnetism & Induction', slug: 'electromagnetism' },
    { id: 'top_phy_modern', subjectId: 'subj_physics', name: 'Modern Physics & Quantum', slug: 'modern-physics' },
    { id: 'top_phy_thermodynamics', subjectId: 'subj_physics', name: 'Thermodynamics & Heat', slug: 'thermodynamics' },

    // Math Topics
    { id: 'top_math_calculus', subjectId: 'subj_math', name: 'Calculus, Limits & Series', slug: 'calculus-limits' },
    { id: 'top_math_integration', subjectId: 'subj_math', name: 'Techniques of Integration', slug: 'integration' },
    { id: 'top_math_conics', subjectId: 'subj_math', name: 'Conic Sections & Geometry', slug: 'conic-sections' },
    { id: 'top_math_algebra', subjectId: 'subj_math', name: 'Complex Numbers & Polynomials', slug: 'algebra-complex' },
    { id: 'top_math_permutations', subjectId: 'subj_math', name: 'Permutations & Combinations', slug: 'permutations' },

    // Chemistry Topics
    { id: 'top_chem_carbonyl', subjectId: 'subj_chemistry', name: 'Carbonyl Compounds & Aldehydes', slug: 'carbonyl-compounds' },
    { id: 'top_chem_equilibrium', subjectId: 'subj_chemistry', name: 'Chemical Equilibrium & Kinetics', slug: 'equilibrium' },
    { id: 'top_chem_electrochemistry', subjectId: 'subj_chemistry', name: 'Electrochemistry & Cells', slug: 'electrochemistry' },

    // Biology Topics
    { id: 'top_bio_bioenergetics', subjectId: 'subj_biology', name: 'Bioenergetics & Respiration', slug: 'bioenergetics' },
    { id: 'top_bio_genetics', subjectId: 'subj_biology', name: 'Genetics & Mendelian Inheritance', slug: 'genetics' },
    { id: 'top_bio_physiology', subjectId: 'subj_biology', name: 'Endocrine & Human Physiology', slug: 'endocrine-physiology' },

    // Analytical & English Topics
    { id: 'top_iq_deduction', subjectId: 'subj_analytical', name: 'Logical Deduction & Syllogisms', slug: 'logical-deduction' },
    { id: 'top_iq_sequences', subjectId: 'subj_analytical', name: 'Number & Letter Sequences', slug: 'number-sequences' },
    { id: 'top_eng_grammar', subjectId: 'subj_english', name: 'Grammar & Subjunctive Mood', slug: 'grammar-syntax' },
  ];

  // Generate 3 sequential levels for each topic
  const topicLevels: TopicLevelModel[] = [];
  topics.forEach((topic) => {
    topicLevels.push(
      {
        id: `lvl_${topic.id}_1`,
        topicId: topic.id,
        level: 1,
        name: 'Level 1 — Basic Formulas',
        xpReward: 60,
        unlockAccuracy: 80,
        minQuestionsRequired: 10,
      },
      {
        id: `lvl_${topic.id}_2`,
        topicId: topic.id,
        level: 2,
        name: 'Level 2 — Applied Dynamics',
        xpReward: 120,
        unlockAccuracy: 80,
        minQuestionsRequired: 10,
      },
      {
        id: `lvl_${topic.id}_3`,
        topicId: topic.id,
        level: 3,
        name: 'Level 3 — Advanced Entrance Mock',
        xpReward: 200,
        unlockAccuracy: 80,
        minQuestionsRequired: 10,
      }
    );
  });

  // Comprehensive verified questions dataset
  const questions: QuestionModel[] = [
    // Work & Energy
    {
      id: 'q_we_1',
      subjectId: 'subj_physics',
      topicId: 'top_phy_work_energy',
      level: 1,
      difficulty: 'Easy',
      question: 'A body of mass $2\\text{ kg}$ is dropped from a height of $10\\text{ m}$. What is its kinetic energy just before hitting the ground? (Assume $g = 9.8\\text{ m/s}^2$)',
      options: ['A) $196\\text{ J}$', 'B) $98\\text{ J}$', 'C) $49\\text{ J}$', 'D) $392\\text{ J}$'],
      correctAnswer: 'A) $196\\text{ J}$',
      correctIndex: 0,
      explanation: 'By conservation of mechanical energy: $KE = mgh = (2)(9.8)(10) = 196\\text{ J}$.',
      boardOrigin: 'MDCAT Physics Core',
      timeTargetSeconds: 20,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_we_2',
      subjectId: 'subj_physics',
      topicId: 'top_phy_work_energy',
      level: 1,
      difficulty: 'Easy',
      question: 'Work done by a centripetal force acting on a particle executing uniform circular motion during one complete revolution is:',
      options: ['A) $0\\text{ J}$', 'B) $2\\pi F r$', 'C) $\\pi F r$', 'D) $\\frac{1}{2} F r$'],
      correctAnswer: 'A) $0\\text{ J}$',
      correctIndex: 0,
      explanation: 'Because the centripetal force is always perpendicular to the instantaneous displacement vector ($\\cos 90^\\circ = 0$), work done is identically zero.',
      boardOrigin: 'Federal FBISE Physics Ch 4',
      timeTargetSeconds: 15,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_we_3',
      subjectId: 'subj_physics',
      topicId: 'top_phy_work_energy',
      level: 2,
      difficulty: 'Medium',
      question: 'A variable force $F(x) = (3x^2 + 2x)\\text{ N}$ acts on a body moving along the x-axis from $x = 1\\text{ m}$ to $x = 3\\text{ m}$. What is the total work done?',
      options: ['A) $34\\text{ J}$', 'B) $28\\text{ J}$', 'C) $42\\text{ J}$', 'D) $18\\text{ J}$'],
      correctAnswer: 'A) $34\\text{ J}$',
      correctIndex: 0,
      explanation: '$W = \\int_{1}^{3} (3x^2 + 2x)\\,dx = [x^3 + x^2]_{1}^{3} = (27 + 9) - (1 + 1) = 36 - 2 = 34\\text{ J}$.',
      boardOrigin: 'NUST NET Mechanics',
      timeTargetSeconds: 30,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_we_4',
      subjectId: 'subj_physics',
      topicId: 'top_phy_work_energy',
      level: 2,
      difficulty: 'Medium',
      question: 'A spring of force constant $k = 400\\text{ N/m}$ is compressed by $0.1\\text{ m}$. How much potential energy is stored in the compressed spring?',
      options: ['A) $2.0\\text{ J}$', 'B) $4.0\\text{ J}$', 'C) $20\\text{ J}$', 'D) $0.2\\text{ J}$'],
      correctAnswer: 'A) $2.0\\text{ J}$',
      correctIndex: 0,
      explanation: '$PE = \\frac{1}{2}kx^2 = \\frac{1}{2}(400)(0.1)^2 = 200 \\times 0.01 = 2.0\\text{ J}$.',
      boardOrigin: 'FAST NU-Test Numerical Speed',
      timeTargetSeconds: 20,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_we_5',
      subjectId: 'subj_physics',
      topicId: 'top_phy_work_energy',
      level: 3,
      difficulty: 'Hard',
      question: 'A block slides down an inclined plane of angle $\\theta = 30^\\circ$ with constant velocity. What is the coefficient of kinetic friction $\\mu_k$ between the block and the plane?',
      options: ['A) $\\frac{1}{\\sqrt{3}} \\approx 0.577$', 'B) $\\sqrt{3} \\approx 1.732$', 'C) $0.5$', 'D) $0.866$'],
      correctAnswer: 'A) $\\frac{1}{\\sqrt{3}} \\approx 0.577$',
      correctIndex: 0,
      explanation: 'At constant velocity $a = 0$, the parallel gravity component balances friction: $mg\\sin\\theta = \\mu_k mg\\cos\\theta \\implies \\mu_k = \\tan\\theta = \\tan(30^\\circ) = \\frac{1}{\\sqrt{3}}$.',
      boardOrigin: 'NUST NET Advanced Mechanics',
      timeTargetSeconds: 25,
      createdAt: new Date('2026-09-01').toISOString(),
    },

    // Electromagnetism
    {
      id: 'q_em_1',
      subjectId: 'subj_physics',
      topicId: 'top_phy_electromagnetism',
      level: 1,
      difficulty: 'Easy',
      question: 'A proton moves with velocity $v = 10^6\\text{ m/s}$ parallel to a uniform magnetic field $B = 0.5\\text{ T}$. What is the magnetic force experienced by the proton?',
      options: ['A) $0\\text{ N}$', 'B) $8 \\times 10^{-14}\\text{ N}$', 'C) $1.6 \\times 10^{-13}\\text{ N}$', 'D) $5 \\times 10^{-14}\\text{ N}$'],
      correctAnswer: 'A) $0\\text{ N}$',
      correctIndex: 0,
      explanation: 'Magnetic Lorentz force is $\\vec{F} = q(\\vec{v} \\times \\vec{B}) = qvB\\sin\\theta$. When moving parallel, $\\theta = 0^\\circ$, so $\\sin 0^\\circ = 0$, making $F = 0$.',
      boardOrigin: 'MDCAT Physics Ch 14',
      timeTargetSeconds: 15,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_em_2',
      subjectId: 'subj_physics',
      topicId: 'top_phy_electromagnetism',
      level: 2,
      difficulty: 'Medium',
      question: 'A long solenoid with $n = 1000\\text{ turns/m}$ carries current $I = 2\\text{ A}$. What is the magnetic field $B_0$ inside the solenoid? (Take $\\mu_0 = 4\\pi \\times 10^{-7}\\text{ T}\\cdot\\text{m/A}$)',
      options: ['A) $8\\pi \\times 10^{-4}\\text{ T}$', 'B) $4\\pi \\times 10^{-4}\\text{ T}$', 'C) $2\\pi \\times 10^{-3}\\text{ T}$', 'D) $1.6 \\times 10^{-3}\\text{ T}$'],
      correctAnswer: 'A) $8\\pi \\times 10^{-4}\\text{ T}$',
      correctIndex: 0,
      explanation: '$B = \\mu_0 n I = (4\\pi \\times 10^{-7})(1000)(2) = 8\\pi \\times 10^{-4}\\text{ T}$.',
      boardOrigin: 'Federal FBISE Physics',
      timeTargetSeconds: 25,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_em_3',
      subjectId: 'subj_physics',
      topicId: 'top_phy_electromagnetism',
      level: 3,
      difficulty: 'Hard',
      question: 'A long solenoid has magnetic flux density $B_0$ at its center. What is the magnetic field density at the aperture of either end along the central axis?',
      options: ['A) $\\frac{1}{2} B_0$', 'B) $B_0$', 'C) $\\frac{1}{4} B_0$', 'D) $2 B_0$'],
      correctAnswer: 'A) $\\frac{1}{2} B_0$',
      correctIndex: 0,
      explanation: 'For a semi-infinite solenoid, the solid angle subtended at the end aperture is $2\\pi$ steradians vs $4\\pi$ in the interior, giving exactly $B_{\\text{end}} = \\frac{1}{2}\\mu_0 n I = \\frac{1}{2}B_0$.',
      boardOrigin: 'Federal Board vs Punjab Delta Trap',
      timeTargetSeconds: 25,
      deltaTagged: true,
      createdAt: new Date('2026-09-01').toISOString(),
    },

    // Mathematics - Calculus
    {
      id: 'q_calc_1',
      subjectId: 'subj_math',
      topicId: 'top_math_calculus',
      level: 1,
      difficulty: 'Easy',
      question: 'Evaluate the standard derivative $$\\frac{d}{dx} [\\ln(\\cos x)]$$:',
      options: ['A) $-\\tan x$', 'B) $\\tan x$', 'C) $-\\cot x$', 'D) $\\sec x$'],
      correctAnswer: 'A) $-\\tan x$',
      correctIndex: 0,
      explanation: '$\\frac{d}{dx}[\\ln(\\cos x)] = \\frac{1}{\\cos x} \\cdot (-\\sin x) = -\\tan x$.',
      boardOrigin: 'FSc Part 2 Mathematics Ch 2',
      timeTargetSeconds: 15,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_calc_2',
      subjectId: 'subj_math',
      topicId: 'top_math_calculus',
      level: 2,
      difficulty: 'Medium',
      question: 'Evaluate the limit without prolonged L\'Hopital iterations: $$\\lim_{x \\to 0} \\frac{\\sin(3x) - 3x}{x^3}$$',
      options: ['A) $-\\frac{9}{2}$', 'B) $-\\frac{27}{6}$', 'C) $\\frac{9}{2}$', 'D) $0$'],
      correctAnswer: 'A) $-\\frac{9}{2}$',
      correctIndex: 0,
      explanation: 'Maclaurin expansion: $\\sin(3x) = 3x - \\frac{(3x)^3}{6} + \\mathcal{O}(x^5)$. Thus $\\frac{(3x - \\frac{27x^3}{6}) - 3x}{x^3} = -\\frac{27}{6} = -\\frac{9}{2}$.',
      boardOrigin: 'NUST NET Math Speed Trap',
      timeTargetSeconds: 30,
      deltaTagged: true,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_calc_3',
      subjectId: 'subj_math',
      topicId: 'top_math_integration',
      level: 3,
      difficulty: 'Hard',
      question: 'Evaluate the definite integral using Walli\'s formula shortcut: $$\\int_{0}^{\\frac{\\pi}{2}} \\sin^6(x) \\, dx$$',
      options: ['A) $\\frac{5\\pi}{32}$', 'B) $\\frac{5}{16}$', 'C) $\\frac{15\\pi}{64}$', 'D) $\\frac{3\\pi}{16}$'],
      correctAnswer: 'A) $\\frac{5\\pi}{32}$',
      correctIndex: 0,
      explanation: 'Walli formula for $n=6$: $\\frac{5}{6} \\times \\frac{3}{4} \\times \\frac{1}{2} \\times \\frac{\\pi}{2} = \\frac{5}{16} \\times \\frac{\\pi}{2} = \\frac{5\\pi}{32}$.',
      boardOrigin: 'FAST NU-Test Advanced Integration',
      timeTargetSeconds: 30,
      deltaTagged: true,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_conic_1',
      subjectId: 'subj_math',
      topicId: 'top_math_conics',
      level: 1,
      difficulty: 'Easy',
      question: 'What is the length of the latus rectum of the parabola defined by $y^2 - 4y - 8x + 28 = 0$?',
      options: ['A) $8$', 'B) $4$', 'C) $2$', 'D) $16$'],
      correctAnswer: 'A) $8$',
      correctIndex: 0,
      explanation: '$(y - 2)^2 = 8(x - 3)$. Comparing with standard form $(y-k)^2 = 4a(x-h)$, length of latus rectum is $4a = 8$.',
      boardOrigin: 'NUST NET Analytical Geometry',
      timeTargetSeconds: 20,
      createdAt: new Date('2026-09-01').toISOString(),
    },

    // Chemistry
    {
      id: 'q_chem_1',
      subjectId: 'subj_chemistry',
      topicId: 'top_chem_carbonyl',
      level: 1,
      difficulty: 'Easy',
      question: 'Which reagent gives a bright brick-red precipitate of $\\text{Cu}_2\\text{O}$ when heated with aliphatic aldehydes?',
      options: ['A) Fehling\'s Solution', 'B) Tollen\'s Reagent', 'C) Lucas Reagent', 'D) 2,4-DNPH'],
      correctAnswer: 'A) Fehling\'s Solution',
      correctIndex: 0,
      explanation: 'Fehling\'s solution contains $\\text{Cu}^{2+}$ complexed with tartrate; it oxidizes aliphatic aldehydes and precipitates red $\\text{Cu}_2\\text{O}$.',
      boardOrigin: 'MDCAT Chemistry Ch 19',
      timeTargetSeconds: 15,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_chem_2',
      subjectId: 'subj_chemistry',
      topicId: 'top_chem_carbonyl',
      level: 2,
      difficulty: 'Medium',
      question: 'Which of the following organic carbonyl compounds will undergo a self-redox Cannizzaro reaction in $50\\%$ aqueous $\\text{NaOH}$?',
      options: ['A) 2,2-Dimethylpropanal (Pivalaldehyde)', 'B) Ethanal (Acetaldehyde)', 'C) Propanal', 'D) 2-Methylpropanal'],
      correctAnswer: 'A) 2,2-Dimethylpropanal (Pivalaldehyde)',
      correctIndex: 0,
      explanation: 'Cannizzaro reaction requires aldehydes completely devoid of $\\alpha$-hydrogens. Pivalaldehyde has a quaternary $\\alpha$-carbon, hence disproportionates into neopentyl alcohol and sodium pivalate.',
      boardOrigin: 'MDCAT & Federal Board Ch 19',
      timeTargetSeconds: 25,
      deltaTagged: true,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_chem_3',
      subjectId: 'subj_chemistry',
      topicId: 'top_chem_equilibrium',
      level: 2,
      difficulty: 'Medium',
      question: 'For the dissociation $\\text{PCl}_5(g) \\rightleftharpoons \\text{PCl}_3(g) + \\text{Cl}_2(g)$, what is the relationship between $K_p$ and $K_c$?',
      options: ['A) $K_p = K_c(RT)$', 'B) $K_p = K_c(RT)^2$', 'C) $K_p = K_c(RT)^{-1}$', 'D) $K_p = K_c$'],
      correctAnswer: 'A) $K_p = K_c(RT)$',
      correctIndex: 0,
      explanation: '$\\Delta n_g = (1 + 1) - 1 = 1$. Since $K_p = K_c(RT)^{\\Delta n_g}$, we have $K_p = K_c(RT)$.',
      boardOrigin: 'COMSATS & MDCAT Equilibrium',
      timeTargetSeconds: 20,
      createdAt: new Date('2026-09-01').toISOString(),
    },

    // Biology
    {
      id: 'q_bio_1',
      subjectId: 'subj_biology',
      topicId: 'top_bio_bioenergetics',
      level: 1,
      difficulty: 'Easy',
      question: 'What is the net gain of ATP molecules produced directly by substrate-level phosphorylation during glycolysis of 1 mole of glucose?',
      options: ['A) 2 ATP', 'B) 4 ATP', 'C) 36 ATP', 'D) 38 ATP'],
      correctAnswer: 'A) 2 ATP',
      correctIndex: 0,
      explanation: 'Glycolysis consumes 2 ATP in the preparatory phase and produces 4 ATP in the payoff phase, resulting in a net yield of 2 ATP.',
      boardOrigin: 'MDCAT PMDC Core Biology',
      timeTargetSeconds: 15,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_bio_2',
      subjectId: 'subj_biology',
      topicId: 'top_bio_bioenergetics',
      level: 2,
      difficulty: 'Medium',
      question: 'Which complex in the inner mitochondrial electron transport chain does NOT pump protons ($H^+$) into the intermembrane space?',
      options: ['A) Complex II (Succinate dehydrogenase)', 'B) Complex I (NADH dehydrogenase)', 'C) Complex III (Cytochrome bc1)', 'D) Complex IV (Cytochrome c oxidase)'],
      correctAnswer: 'A) Complex II (Succinate dehydrogenase)',
      correctIndex: 0,
      explanation: 'Complex II transfers electrons from succinate to ubiquinone without spanning across the membrane, so it does not contribute to the proton gradient.',
      boardOrigin: 'MDCAT Cellular Respiration',
      timeTargetSeconds: 20,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_bio_3',
      subjectId: 'subj_biology',
      topicId: 'top_bio_genetics',
      level: 3,
      difficulty: 'Hard',
      question: 'A woman who is a heterozygous carrier for X-linked recessive color blindness marries a normal vision man. What is the probability that their first male child will be color blind?',
      options: ['A) $50\\%$', 'B) $25\\%$', 'C) $0\\%$', 'D) $100\\%$'],
      correctAnswer: 'A) $50\\%$',
      correctIndex: 0,
      explanation: 'Mother is $X^B X^b$, Father is $X^B Y$. For sons, father gives $Y$ and mother gives $X^B$ ($50\\%$) or $X^b$ ($50\\%$). Hence, the probability given the child is male is $50\\%$.',
      boardOrigin: 'MDCAT Genetics & Heredity',
      timeTargetSeconds: 25,
      createdAt: new Date('2026-09-01').toISOString(),
    },

    // Analytical
    {
      id: 'q_iq_1',
      subjectId: 'subj_analytical',
      topicId: 'top_iq_sequences',
      level: 1,
      difficulty: 'Easy',
      question: 'Find the next number in the sequence: $3, \\; 7, \\; 15, \\; 31, \\; 63, \\; ?$',
      options: ['A) 127', 'B) 126', 'C) 125', 'D) 128'],
      correctAnswer: 'A) 127',
      correctIndex: 0,
      explanation: 'Pattern: $2x + 1 \\implies 63 \\times 2 + 1 = 127$.',
      boardOrigin: 'NUST NET & NTS-NAT Analytical',
      timeTargetSeconds: 20,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_iq_2',
      subjectId: 'subj_analytical',
      topicId: 'top_iq_sequences',
      level: 2,
      difficulty: 'Medium',
      question: 'Determine the missing number in the sequence: $$2, \\; 12, \\; 36, \\; 80, \\; 150, \\; ?$$',
      options: ['A) 252', 'B) 240', 'C) 260', 'D) 272'],
      correctAnswer: 'A) 252',
      correctIndex: 0,
      explanation: 'Pattern is $n^3 + n^2$: for $n=6$, $6^3 + 6^2 = 216 + 36 = 252$.',
      boardOrigin: 'FAST NU-Test Analytical Speed',
      timeTargetSeconds: 30,
      createdAt: new Date('2026-09-01').toISOString(),
    },
    {
      id: 'q_iq_3',
      subjectId: 'subj_analytical',
      topicId: 'top_iq_deduction',
      level: 3,
      difficulty: 'Hard',
      question: 'Premises:\n1. All algorithms that terminate in polynomial time are tractable.\n2. Some tractable algorithms require exponential auxiliary memory.\n\nWhich conclusion necessarily follows?',
      options: [
        'A) Some algorithms requiring exponential auxiliary memory are tractable.',
        'B) All algorithms requiring exponential auxiliary memory terminate in polynomial time.',
        'C) No algorithm terminating in polynomial time requires exponential memory.',
        'D) All tractable algorithms terminate in polynomial time.',
      ],
      correctAnswer: 'A) Some algorithms requiring exponential auxiliary memory are tractable.',
      correctIndex: 0,
      explanation: 'By standard immediate inference (conversion of I-type propositions), "Some A are B" logically converts to "Some B are A".',
      boardOrigin: 'FAST NU-Test Logical Deduction',
      timeTargetSeconds: 35,
      createdAt: new Date('2026-09-01').toISOString(),
    },
  ];

  // Initialize topic progress for default user:
  // Rule: Level 1 is always unlocked by default! Level 2 and 3 start locked.
  const topicProgress: TopicProgressModel[] = [];
  topicLevels.forEach((lvl) => {
    // Seed sample progress for Work & Energy and Calculus so student sees initial progress
    let attempts = 0;
    let correct = 0;
    let accuracy = 0;
    let xp = 0;
    let completed = false;
    let unlocked = lvl.level === 1; // Level 1 is unlocked by default

    if (lvl.topicId === 'top_phy_work_energy' && lvl.level === 1) {
      attempts = 12;
      correct = 12;
      accuracy = 100;
      xp = 120;
      completed = true;
      unlocked = true;
    } else if (lvl.topicId === 'top_phy_work_energy' && lvl.level === 2) {
      attempts = 11;
      correct = 9;
      accuracy = 81.8;
      xp = 140;
      completed = true;
      unlocked = true; // Unlocked because Level 1 had 100% accuracy and 12 >= 10 attempts!
    } else if (lvl.topicId === 'top_math_calculus' && lvl.level === 1) {
      attempts = 10;
      correct = 9;
      accuracy = 90;
      xp = 90;
      completed = true;
      unlocked = true;
    } else if (lvl.topicId === 'top_math_calculus' && lvl.level === 2) {
      // Level 2 unlocked because level 1 is 90% and 10 attempts
      unlocked = true;
      attempts = 5;
      correct = 3;
      accuracy = 60;
      xp = 40;
      completed = false;
    }

    topicProgress.push({
      id: `prog_${defaultUser.id}_${lvl.id}`,
      userId: defaultUser.id,
      levelId: lvl.id,
      topicId: lvl.topicId,
      subjectId: lvl.id.includes('phy')
        ? 'subj_physics'
        : lvl.id.includes('math')
        ? 'subj_math'
        : lvl.id.includes('chem')
        ? 'subj_chemistry'
        : lvl.id.includes('bio')
        ? 'subj_biology'
        : 'subj_analytical',
      level: lvl.level,
      attempts,
      correct,
      accuracy: Math.round(accuracy * 10) / 10,
      xp,
      completed,
      unlocked,
      lastAttemptedAt: attempts > 0 ? new Date('2026-09-08T14:30:00Z').toISOString() : null,
    });
  });

  // Seed initial realistic test records for authenticated history
  const testRecords: TestRecordModel[] = [
    {
      id: 'rec_101',
      userId: defaultUser.id,
      testId: 'test_nust_net_1',
      testName: 'NUST NET Full Simulation #1',
      testType: 'MOCK',
      subject: 'All Subjects',
      score: 82,
      totalQuestions: 100,
      correctAnswers: 82,
      incorrectAnswers: 14,
      skippedAnswers: 4,
      accuracy: 82.0,
      timeTaken: 2520, // 42 minutes
      topicBreakdown: {
        'Work & Energy': { total: 20, correct: 18, accuracy: 90 },
        'Electromagnetism': { total: 25, correct: 20, accuracy: 80 },
        'Calculus & Integration': { total: 30, correct: 25, accuracy: 83.3 },
        'Equilibrium & Acids': { total: 25, correct: 19, accuracy: 76 },
      },
      xpEarned: 240,
      unlockedLevelsCount: 1,
      attemptedAt: new Date('2026-09-09T04:15:00Z').toISOString(),
    },
    {
      id: 'rec_102',
      userId: defaultUser.id,
      testId: 'test_mdcat_bio',
      testName: 'MDCAT Biology & Physiology Drill',
      testType: 'SUBJECT',
      subject: 'Biology',
      score: 91,
      totalQuestions: 100,
      correctAnswers: 91,
      incorrectAnswers: 8,
      skippedAnswers: 1,
      accuracy: 91.0,
      timeTaken: 2280, // 38 minutes
      topicBreakdown: {
        'Bioenergetics & Respiration': { total: 40, correct: 38, accuracy: 95 },
        'Genetics & Mendelian Inheritance': { total: 35, correct: 31, accuracy: 88.5 },
        'Human Physiology': { total: 25, correct: 22, accuracy: 88 },
      },
      xpEarned: 290,
      unlockedLevelsCount: 1,
      attemptedAt: new Date('2026-09-08T11:20:00Z').toISOString(),
    },
    {
      id: 'rec_103',
      userId: defaultUser.id,
      testId: 'test_chem_quiz',
      testName: 'Organic Chemistry Functional Groups Quiz',
      testType: 'PRACTICE',
      subject: 'Chemistry',
      score: 76,
      totalQuestions: 100,
      correctAnswers: 76,
      incorrectAnswers: 20,
      skippedAnswers: 4,
      accuracy: 76.0,
      timeTaken: 1500, // 25 minutes
      topicBreakdown: {
        'Carbonyl Compounds & Aldehydes': { total: 50, correct: 40, accuracy: 80 },
        'Chemical Equilibrium': { total: 50, correct: 36, accuracy: 72 },
      },
      xpEarned: 180,
      unlockedLevelsCount: 0,
      attemptedAt: new Date('2026-09-07T16:45:00Z').toISOString(),
    },
  ];

  // Seed sample answers for rec_101
  const testAnswers: TestAnswerModel[] = [
    {
      id: 'ans_1',
      recordId: 'rec_101',
      questionId: 'q_em_3',
      question: 'A long solenoid has magnetic flux density $B_0$ at its center. What is the magnetic field density at the aperture of either end along the central axis?',
      options: ['A) $\\frac{1}{2} B_0$', 'B) $B_0$', 'C) $\\frac{1}{4} B_0$', 'D) $2 B_0$'],
      selectedAnswer: 'B) $B_0$',
      selectedOptionIndex: 1,
      correctAnswer: 'A) $\\frac{1}{2} B_0$',
      correctIndex: 0,
      isCorrect: false,
      isSkipped: false,
      timeTaken: 42,
      explanation: 'At the end aperture of an ideal solenoid, the solid angle subtended is $2\\pi$ steradians instead of $4\\pi$, so $B_{\\text{end}} = \\frac{1}{2}\\mu_0 n I = \\frac{1}{2}B_0$.',
      boardOrigin: 'Federal Board vs Punjab Delta Trap',
    },
    {
      id: 'ans_2',
      recordId: 'rec_101',
      questionId: 'q_calc_2',
      question: 'Evaluate the limit without prolonged L\'Hopital iterations: $$\\lim_{x \\to 0} \\frac{\\sin(3x) - 3x}{x^3}$$',
      options: ['A) $-\\frac{9}{2}$', 'B) $-\\frac{27}{6}$', 'C) $\\frac{9}{2}$', 'D) $0$'],
      selectedAnswer: 'A) $-\\frac{9}{2}$',
      selectedOptionIndex: 0,
      correctAnswer: 'A) $-\\frac{9}{2}$',
      correctIndex: 0,
      isCorrect: true,
      isSkipped: false,
      timeTaken: 28,
      explanation: 'Maclaurin expansion of $\\sin(3x) = 3x - \\frac{27x^3}{6} + \\mathcal{O}(x^5)$ yields $-\\frac{27}{6} = -\\frac{9}{2}$.',
      boardOrigin: 'NUST NET Math Speed Trap',
    },
    {
      id: 'ans_3',
      recordId: 'rec_101',
      questionId: 'q_we_5',
      question: 'A block slides down an inclined plane of angle $\\theta = 30^\\circ$ with constant velocity. What is the coefficient of kinetic friction $\\mu_k$?',
      options: ['A) $\\frac{1}{\\sqrt{3}} \\approx 0.577$', 'B) $\\sqrt{3} \\approx 1.732$', 'C) $0.5$', 'D) $0.866$'],
      selectedAnswer: 'C) $0.5$',
      selectedOptionIndex: 2,
      correctAnswer: 'A) $\\frac{1}{\\sqrt{3}} \\approx 0.577$',
      correctIndex: 0,
      isCorrect: false,
      isSkipped: false,
      timeTaken: 55,
      explanation: 'At constant velocity, $mg\\sin\\theta = \\mu_k mg\\cos\\theta \\implies \\mu_k = \\tan\\theta = \\tan(30^\\circ) = \\frac{1}{\\sqrt{3}} \\approx 0.577$.',
      boardOrigin: 'NUST NET Advanced Mechanics',
    },
  ];

  return {
    users: [defaultUser],
    subjects,
    topics,
    topicLevels,
    questions,
    topicProgress,
    testRecords,
    testAnswers,
  };
}

// --- Progression & Mastery Algorithms ---

/**
 * Progressive XP algorithm adhering strictly to:
 * baseXP = 50; levelMultiplier = 1 + (level - 1) * 0.5; accuracyMultiplier = accuracy / 100;
 * questionMultiplier = Math.min(questions / 10, 2);
 */
export function calculateXP({
  accuracy,
  questions,
  level,
}: {
  accuracy: number;
  questions: number;
  level: number;
}): number {
  const baseXP = 50;
  const levelMultiplier = 1 + (level - 1) * 0.5;
  const accuracyMultiplier = Math.max(0, Math.min(1, accuracy / 100));
  const questionMultiplier = Math.min(Math.max(questions, 1) / 10, 2);

  return Math.round(baseXP * levelMultiplier * accuracyMultiplier * questionMultiplier);
}

/**
 * Cumulative / rolling accuracy calculation:
 * Prevents 1 question 1 correct from skewing mastery.
 */
export function calculateRollingAccuracy(
  previousCorrect: number,
  previousQuestions: number,
  newCorrect: number,
  newQuestions: number
): number {
  const totalCorrect = previousCorrect + newCorrect;
  const totalQuestions = previousQuestions + newQuestions;
  if (totalQuestions === 0) return 0;
  return Math.round((totalCorrect / totalQuestions) * 1000) / 10;
}
