#include <iostream>
#include <string>

using namespace std;


struct node {
    int id;
    string name;
    int age;
    string disease;
    node* next;
};

// 1. Add patient in the end :

void addPatientEnd(node*& head, int id, string name, int age, string disease) {
    node* newNode = new node();

    newNode->id = id;
    newNode->name = name;
    newNode->age = age;

    newNode->disease = disease;
    newNode->next = nullptr;

    if (head == nullptr) {
        head = newNode;
    } else
    {
        node* temp = head;
        while (temp->next != nullptr)
            {
            temp = temp->next;
        }
        temp->next = newNode;
    }
    cout << "Patient added successfully at the end!" << endl;
}

// 2. Emergency patient in the start :

void addPatientStart(node*& head, int id, string name, int age, string disease)
 {
    node* newNode = new node();

    newNode->id = id;
    newNode->name = name;
    newNode->age = age;

    newNode->disease = disease;
    newNode->next = head;
    head = newNode;

    cout << "Emergency patient added successfully at the start!\n";
}

// 3. Search patient by their ID:

void searchPatient(node* head, int id)
{
    node* temp = head;

    while (temp != nullptr) {
        if (temp->id == id) {
            cout << "\n--- Patient Found ---\n";
            cout << "ID: " << temp->id << "\n";
            cout << "Name: " << temp->name << "\n";
            cout << "Age: " << temp->age << "\n";
            cout << "Disease: " << temp->disease << "\n";
            return;
        }
        temp = temp->next;
    }
    cout << "Patient with ID " << id << " not found.\n";
}

// 4 Update the patient details:


void updatePatient(node* head, int id)
 {
    node* temp = head;

    while (temp != nullptr) {
        if (temp->id == id) {
            cout << "\nPatient found. Enter new details:\n";
            cout << "Enter Name: ";
            cin >> temp->name;
            cout << "Enter Age: ";

            cin >> temp->age;
            cout << "Enter Disease: ";
            cin >> temp->disease;
            cout << "Patient details updated successfully!\n";
            return;
        }

        temp = temp->next;
    }
    cout << "Patient with ID " << id << " not found for updating.\n";
}

// 5  Remove patient if treatment complete:


void removePatient(node*& head, int id)
{
    if (head == nullptr)
    {
        cout << "No patients in the record.\n";
        return;
    }

    node* temp = head;
    node* prev = nullptr;

    if (temp != nullptr && temp->id == id) {
        head = temp->next;
        delete temp;
        cout << "Treatment complete. Patient removed successfully!\n";
        return;
    }


    while (temp != nullptr && temp->id != id) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == nullptr) {
        cout << "Patient with ID " << id << " not found.\n";
        return;
    }


    prev->next = temp->next;
    delete temp;
    cout << "Treatment complete. Patient removed successfully!\n";
}

 // Show all patients:

void displayPatients(node* head)
 {
    if (head == nullptr) {
        cout << "\nNo patients currently admitted." << endl;
        return;
    }

    node* temp = head;
    cout << " Current Patient Records \n";
    while (temp != nullptr) {
        cout << "ID: " << temp->id
             << " | Name: " << temp->name
             << " | Age: " << temp->age
             << " | Disease: " << temp->disease << "" << endl;
        temp = temp->next;
    }
    cout << "------------------------------" << endl;
}

int main() {
    node* head = nullptr;

    int choice, id, age;

    string name, disease;

    do {
        cout << "\n===== Hospital System ==== " << endl;
        cout << "1. Add Patient (End)"  << endl;
        cout << "2. Emergency Patient (Start)" << endl;
        cout << "3. Search Patient by ID " << endl;
        cout << "4. Update Patient Details " << endl;
        cout << "5. Remove Patient (Treatment Complete)" << endl;
        cout << "6. Show All Patients" << endl;
        cout << "7. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
                            // Here WE'll Add patient  by yourself :
            case 1:
                cout << "Enter ID: ";
                 cin >> id;
                cout << "Enter Name: ";
                 cin >> name;
                cout << "Enter Age: ";
                    cin >> age;
                cout << "Enter Disease: ";
                 cin >> disease;
            addPatientEnd(head, id, name, age, disease);
                break;

                        // Here WE'll Add  emergency - patient by yourself :
            case 2:
                cout << "Enter ID: ";
                 cin >> id;
                cout << "Enter Name: ";
                   cin >> name;
                cout << "Enter Age: ";
                 cin >> age;
                cout << "Enter Disease: ";
                    cin >> disease;
        addPatientStart(head, id, name, age, disease);
                break;

                        // Here WE'll Search the Patient  by yourself :
            case 3:
                cout << "Enter ID to search: ";
                cin >> id;
                searchPatient(head, id);
                break;

                    // Here WE'll Update the  patient details by yourself :

            case 4:
                cout << "Enter ID to update: ";
                 cin >> id;
                updatePatient(head, id);
                break;
                        // here we'll Remove the Details of patient
            case 5:
                cout << "Enter ID to remove: ";
                cin >> id;
                removePatient(head, id);
                break;


                // Here WE'll Display  patient  by yourself :
            case 6:
                displayPatients(head);
                break;
                        // Here WE had completed the task and program Over here !!! :
            case 7:
                cout << "Exiting program...\n";
                break;
            default:
                cout << "Invalid choice! Try again.\n";
        }
    } while (choice != 7);

    return 0;
}
