#include <iostream>
#include <stack>
#include <string>

using namespace std;


bool checkParentheses(string expr) {
    stack<char> s;

    for (char ch : expr) {

        if (ch == '('|| ch == '[' || ch == '{') {
            s.push(ch);
        }

        else if (ch == ')'|| ch ==']' || ch == '}') {

            if (s.empty())
                return false;
            s.pop();
        }
    }


    return s.empty();
}

int main() {
    string expr;
    cout << "Enter expression: ";
    cin >> expr;

    if (checkParentheses(expr)) {
        cout << "Result: Balanced!" << endl;
    } else {
        cout << "Result: Not Balanced!" << endl;
    }

    return 0;
}



